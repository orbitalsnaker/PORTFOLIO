# domain/types.py
"""
Tipos de dominio: TypeAlias + Annotated con restricciones semánticas.
Garantía: ningún tipo primitivo sin contrato operativo.
"""

from typing import Annotated, TypeAlias
from decimal import Decimal
from pydantic import Field, StringConstraints
import re

# ============================================================================
# TIPOS PRIMITIVOS CON CONTRATO OPERATIVO
# ============================================================================

# Identificadores
RequestId: TypeAlias = Annotated[
    str,
    Field(
        pattern=r'^[a-f0-9]{32}$',  # UUID hex lowercase
        description="Request ID único (hex 32 caracteres)",
        json_schema_extra={"example": "a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6"},
    ),
]

ModelId: TypeAlias = Annotated[
    str,
    Field(
        pattern=r'^[a-zA-Z0-9._-]+/[a-zA-Z0-9._-]+$',  # namespace/name
        description="Model ID en formato namespace/name (HuggingFace style)",
        json_schema_extra={"example": "qwen/qwen2-72b-instruct"},
    ),
]

UserId: TypeAlias = Annotated[
    str,
    Field(
        min_length=8,
        max_length=64,
        pattern=r'^[a-zA-Z0-9._-]+$',
        description="Identificador de usuario único",
        json_schema_extra={"example": "org_acme_user_42"},
    ),
]

# Texto y prompts
Prompt: TypeAlias = Annotated[
    str,
    Field(
        min_length=1,
        max_length=32768,
        description="Texto del prompt (1-32K caracteres)",
    ),
]

ResponseText: TypeAlias = Annotated[
    str,
    Field(
        min_length=0,
        max_length=1048576,  # 1MB en caracteres
        description="Texto de respuesta del modelo",
    ),
]

# Tokens y contabilidad
TokenCount: TypeAlias = Annotated[
    int,
    Field(
        ge=0,
        le=2000000,  # 2M tokens max por request
        description="Conteo de tokens (0-2M)",
    ),
]

CostUSD: TypeAlias = Annotated[
    Decimal,
    Field(
        ge=Decimal('0'),
        le=Decimal('99999.99'),
        decimal_places=6,
        description="Coste en USD (precisión 6 decimales)",
        json_schema_extra={"unit": "USD"},
    ),
]

# Temperaturas y parámetros de muestreo
Temperature: TypeAlias = Annotated[
    float,
    Field(
        ge=0.0,
        le=2.0,
        description="Temperatura de muestreo (0.0-2.0)",
    ),
]

TopP: TypeAlias = Annotated[
    float,
    Field(
        ge=0.0,
        le=1.0,
        description="Top-p (nucleus sampling) 0.0-1.0",
    ),
]

TopK: TypeAlias = Annotated[
    int,
    Field(
        ge=1,
        le=100000,
        description="Top-k (1-100K)",
    ),
]

# Timestamps (naive → UTC siempre)
Timestamp: TypeAlias = Annotated[
    str,
    Field(
        pattern=r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$',
        description="Timestamp ISO 8601 UTC (YYYY-MM-DDTHH:MM:SSZ)",
        json_schema_extra={"example": "2026-05-23T14:30:00Z"},
    ),
]

# SHA-256 hashes (integridad de modelos)
SHA256Hash: TypeAlias = Annotated[
    str,
    Field(
        pattern=r'^[a-f0-9]{64}$',
        description="SHA-256 hash (64 caracteres hex lowercase)",
        json_schema_extra={"example": "aabbccddeeff00112233445566778899aabbccddeeff00112233445566778899"},
    ),
]

# Versiones semánticas
Version: TypeAlias = Annotated[
    str,
    Field(
        pattern=r'^\d+\.\d+\.\d+(-[a-zA-Z0-9.]+)?(\+[a-zA-Z0-9.]+)?$',
        description="Versión semántica (SemVer)",
        json_schema_extra={"example": "1.2.3"},
    ),
]

# Enumeraciones de dominio
ModelProvider: TypeAlias = Annotated[
    str,
    Field(
        pattern=r'^(qwen|deepseek|ollama)$',
        description="Proveedor de modelo: qwen | deepseek | ollama",
    ),
]

InferenceStatus: TypeAlias = Annotated[
    str,
    Field(
        pattern=r'^(pending|running|completed|failed)$',
        description="Estado de inferencia",
    ),
]

# ============================================================================
# TIPOS COMPLEJOS CON RESTRICCIONES
# ============================================================================

# Headers HTTP tipados
RequestHeaders: TypeAlias = Annotated[
    dict[str, str],
    Field(
        min_length=0,
        max_length=100,
        description="Headers HTTP (máx 100)",
    ),
]

# Metadata estructurada
ContextMetadata: TypeAlias = Annotated[
    dict[str, str],
    Field(
        min_length=0,
        max_length=50,
        description="Metadata de contexto (máx 50 pares)",
    ),
]

print(
    """
✓ domain/types.py: 20+ TypeAlias con contratos operativos
✓ Cada tipo primitivo → Annotated + Field con restricciones semánticas
✓ Patrones regex compilados (O(1) matching)
✓ Decimal para costes (no float)
✓ Timestamp ISO 8601 con Z (UTC, no naive)
✓ mypy --strict compatible: TypeAlias explícito, sin Any
"""
)
