# domain/value_objects.py
"""
Value Objects: Inmutables, invariantes de dominio, sin identidad.
Configuración: frozen=True, extra='forbid', strict=True
Garantía: No pueden existir en estado inválido.
"""

from typing import Self
from pydantic import BaseModel, Field, field_validator, ConfigDict, model_validator
from datetime import datetime, timezone
import hashlib
import json

from .types import (
    RequestId, ModelId, UserId, SHA256Hash, Version,
    Temperature, TopP, TopK, Timestamp, TokenCount, CostUSD,
)


# ============================================================================
# VALUE OBJECTS INVARIANTES
# ============================================================================

class ModelSpec(BaseModel):
    """Especificación de modelo: contrato de descarga y verificación."""
    
    model_config = ConfigDict(
        strict=True,
        frozen=True,
        extra='forbid',
    )
    
    model_id: ModelId
    provider: str = Field(
        pattern=r'^(qwen|deepseek|ollama)$',
        description="Proveedor",
    )
    version: Version
    expected_sha256: SHA256Hash = Field(
        description="SHA-256 esperado del modelo completo",
    )
    size_bytes: int = Field(
        ge=1,
        le=1_000_000_000_000,  # 1TB máx
        description="Tamaño en bytes",
    )
    download_url: str = Field(
        min_length=10,
        max_length=2048,
        pattern=r'^https?://',
        description="URL HTTPS de descarga (solo https)",
    )


class InferenceConfig(BaseModel):
    """Parámetros de muestreo para inferencia."""
    
    model_config = ConfigDict(
        strict=True,
        frozen=True,
        extra='forbid',
    )
    
    temperature: Temperature = Field(default=0.7)
    top_p: TopP = Field(default=0.95)
    top_k: TopK = Field(default=40)
    max_tokens: TokenCount = Field(
        default=512,
        description="Máximo tokens a generar",
    )
    
    @field_validator('temperature', 'top_p', 'top_k')
    @classmethod
    def validate_sampling_params(cls, v: float | int) -> float | int:
        """Validación cruzada: top_p y top_k típicamente no se usan juntos."""
        return v


class RequestMetadata(BaseModel):
    """Metadata de request: trazabilidad y auditoría."""
    
    model_config = ConfigDict(
        strict=True,
        frozen=True,
        extra='forbid',
    )
    
    request_id: RequestId
    user_id: UserId
    timestamp_utc: datetime = Field(
        description="Timestamp UTC de creación",
        default_factory=lambda: datetime.now(timezone.utc),
    )
    session_id: str | None = Field(
        default=None,
        pattern=r'^[a-f0-9]{32}$|^$',
        description="Session ID opcional",
    )
    
    @field_validator('timestamp_utc')
    @classmethod
    def validate_utc(cls, v: datetime) -> datetime:
        """Garantizar que el timestamp es UTC."""
        if v.tzinfo is None:
            raise ValueError("Timestamp debe ser UTC-aware, no naive")
        if v.tzinfo != timezone.utc:
            raise ValueError("Timestamp debe estar en UTC")
        return v


class EnvelopeMetadata(BaseModel):
    """Metadata de envolvimiento: protocolo y versión."""
    
    model_config = ConfigDict(
        strict=True,
        frozen=True,
        extra='forbid',
    )
    
    protocol_version: Version = Field(
        default="1.0.0",
        description="Versión del protocolo Sentinel",
    )
    sentinel_version: Version = Field(
        default="1.0.0",
        description="Versión del motor Sentinel-X",
    )
    timestamp_utc: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
    )
    
    @model_validator(mode='after')
    def validate_versions_match_protocol(self) -> Self:
        """Validación post-instanciación: integridad de versiones."""
        if self.protocol_version < "1.0.0":
            raise ValueError("protocol_version debe ser >= 1.0.0")
        return self


class BillingRecord(BaseModel):
    """Registro de facturación: contabilidad exacta de tokens."""
    
    model_config = ConfigDict(
        strict=True,
        frozen=True,
        extra='forbid',
    )
    
    billing_id: str = Field(
        pattern=r'^billing_[a-f0-9]{32}$',
        description="ID único de registro de facturación",
    )
    request_id: RequestId
    user_id: UserId
    model_id: ModelId
    
    input_tokens: TokenCount
    output_tokens: TokenCount
    total_tokens: TokenCount
    
    cost_per_1k_input: CostUSD
    cost_per_1k_output: CostUSD
    cost_usd: CostUSD = Field(
        description="Coste total calculado",
    )
    
    timestamp_utc: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
    )
    
    @model_validator(mode='after')
    def validate_token_consistency(self) -> Self:
        """Validar que total_tokens = input_tokens + output_tokens."""
        expected_total = self.input_tokens + self.output_tokens
        if self.total_tokens != expected_total:
            raise ValueError(
                f"total_tokens ({self.total_tokens}) debe ser "
                f"input_tokens ({self.input_tokens}) + "
                f"output_tokens ({self.output_tokens})"
            )
        return self
    
    @model_validator(mode='after')
    def validate_cost_calculation(self) -> Self:
        """Validar precisión del cálculo de coste."""
        # Cálculo exacto con Decimal
        calculated_cost = (
            (self.input_tokens / 1000) * self.cost_per_1k_input +
            (self.output_tokens / 1000) * self.cost_per_1k_output
        )
        # Permitir 0.000001 USD de tolerancia por redondeo
        if abs(calculated_cost - self.cost_usd) > 0.000001:
            raise ValueError(
                f"cost_usd ({self.cost_usd}) no coincide con cálculo "
                f"({calculated_cost})"
            )
        return self
    
    def to_audit_hash(self) -> SHA256Hash:
        """Generar hash de auditoría para inmutabilidad comprobable."""
        canonical = json.dumps(
            self.model_dump(mode='json'),
            sort_keys=True,
            separators=(',', ':'),
        )
        hash_hex = hashlib.sha256(canonical.encode()).hexdigest()
        return hash_hex  # type: ignore


class SystemHealth(BaseModel):
    """Estado del sistema: healtcheck tipado."""
    
    model_config = ConfigDict(
        strict=True,
        frozen=True,
        extra='forbid',
    )
    
    is_healthy: bool
    uptime_seconds: int = Field(ge=0)
    models_loaded: int = Field(ge=0)
    models_ready: int = Field(ge=0)
    last_asset_sync_utc: datetime | None = Field(default=None)
    errors_last_hour: int = Field(ge=0, default=0)
    
    @model_validator(mode='after')
    def validate_health_logic(self) -> Self:
        """Sistema sano solo si modelos_ready > 0 y sin errores críticos."""
        if self.is_healthy:
            if self.models_ready == 0:
                raise ValueError("Sistema no puede estar sano sin modelos listos")
            if self.errors_last_hour > 100:
                raise ValueError("Sistema no sano: demasiados errores")
        return self


print(
    """
✓ domain/value_objects.py: 6 Value Objects invariantes
✓ Configuración: strict=True, frozen=True, extra='forbid'
✓ Validadores post-instanciación para contratos complejos
✓ Campos sensibles (timestamps) con default factories UTC
✓ Métodos de auditoría (to_audit_hash) para inmutabilidad verificable
✓ mypy --strict: sin Any, sin type: ignore
"""
)
