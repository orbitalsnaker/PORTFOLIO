# SENTINEL-X: MONOLITO DE BLINDAJE DE DATOS
## Arquitectura Staff L5 · Junio 2026 · Protocolo Ronin Sentinel v5.0

---

## ESTRUCTURA DE DIRECTORIOS (DDD ORIENTADO A SOBERANÍA)

```
sentinel-x/
├── domain/                          # Capas agnóstica de infraestructura
│   ├── __init__.py
│   ├── types.py                    # TypeAlias de dominio (semántica pura)
│   ├── value_objects.py            # frozen=True, extra='forbid'
│   ├── models/                     # Agregados de dominio
│   │   ├── __init__.py
│   │   ├── inference_request.py    # InferenceRequest
│   │   ├── billing_event.py        # BillingEvent
│   │   ├── system_status.py        # SystemStatus
│   │   └── sentinel_envelope.py    # SentinelEnvelope (unión discriminada)
│   └── errors.py                   # Excepciones de dominio tipadas
│
├── boundary/                        # Frontera de validación (doctrina Sentinél)
│   ├── __init__.py
│   ├── handler.py                  # BoundaryHandler (enforcement O(1))
│   ├── validation_context.py       # Contexto de validación enriquecido
│   └── policies.py                 # Políticas de blindaje (v1.0)
│
├── infrastructure/
│   ├── __init__.py
│   ├── assets/                     # AssetSync: descarga y verificación
│   │   ├── __init__.py
│   │   ├── manifest.py             # Asset Manifest privado
│   │   ├── sync_engine.py          # Motor de sincronización SHA-256
│   │   └── model_repository.py     # Repositorio local de modelos
│   │
│   ├── routing/                    # Motor de enrutamiento O(1)
│   │   ├── __init__.py
│   │   ├── discriminator.py        # Resolución de tipos discriminados
│   │   └── model_router.py         # Router Qwen/DeepSeek
│   │
│   ├── billing/                    # Billing Engine (telemetría de tokens)
│   │   ├── __init__.py
│   │   ├── counter.py              # Contador de tokens en tiempo real
│   │   ├── calculator.py           # Cálculo de costes SaaS
│   │   └── ledger.py               # Libro mayor de facturación
│   │
│   └── storage/                    # Persistencia determinística
│       ├── __init__.py
│       ├── sqlite_ledger.py        # SQLite para auditoría
│       └── cache_layer.py          # Cache L1/L2 (sin invalidación silenciosa)
│
├── engine/                          # SentinelEngine: orquestación central
│   ├── __init__.py
│   ├── core.py                     # Motor de inferencia (state machine)
│   ├── lifecycle.py                # Ciclo de vida de requests
│   └── observability.py            # Spans, logs estructurados
│
├── api/                             # Capa HTTP (FastAPI)
│   ├── __init__.py
│   ├── middleware/
│   │   ├── __init__.py
│   │   ├── boundary_enforcer.py   # Middleware de validación
│   │   └── observability.py        # Spans de OTEL
│   │
│   ├── handlers/                   # Handlers de endpoints
│   │   ├── __init__.py
│   │   ├── inference.py            # POST /infer
│   │   ├── status.py               # GET /status
│   │   └── billing.py              # GET /billing/ledger
│   │
│   └── schemas/                    # DTOs serialización
│       ├── __init__.py
│       ├── request.py              # Validación de entrada
│       └── response.py             # Respuestas tipadas
│
├── config/                          # Configuración soberana
│   ├── __init__.py
│   ├── settings.py                 # Env. variables tipadas (Pydantic)
│   └── secrets.py                  # Gestión de credenciales
│
├── cli/                             # Interfaz de línea de comandos
│   ├── __init__.py
│   ├── asset_sync.py               # `sentinel-x sync-assets`
│   ├── verify.py                   # `sentinel-x verify-models`
│   └── billing_report.py           # `sentinel-x billing-report`
│
├── main.py                          # Punto de entrada (ASGI)
├── py.typed                         # Marcador para type checking
└── pyproject.toml                   # Configuración build + mypy --strict

```

---

## JERARQUÍA DE MÓDULOS Y DEPENDENCIAS

```
api/ [FastAPI handlers]
 ↓
boundary/ [Validation enforcement, v1.0 Treaty]
 ↓
engine/ [SentinelEngine orchestration]
 ↓
domain/ [Type-safe invariants, frozen Value Objects]
infrastructure/ [Assets, Routing, Billing]
```

**Regla de Oro:** Ningún módulo en `domain/` importa de `infrastructure/`, `api/` o `boundary/`.  
Flujo de datos: entrada → boundary → domain → infrastructure → output.

---

## CONTRATOS CENTRALES

### 1. SentinelEnvelope (Unión Discriminada O(1))

```python
# domain/models/sentinel_envelope.py
from typing import Annotated, Literal, Union
from pydantic import BaseModel, Field, Discriminator

class SentinelEnvelope(BaseModel):
    """Envoltura polimórfica con resolución O(1)."""
    
    model_config = ConfigDict(
        strict=True,
        frozen=True,
        extra='forbid',
    )
    
    envelope_type: Literal['inference', 'billing', 'status']
    payload: Annotated[
        Union[InferenceRequest, BillingEvent, SystemStatus],
        Discriminator('envelope_type')
    ]
    metadata: EnvelopeMetadata = Field(..., frozen=True)
    
    # El discriminador garantiza O(1), no O(n).
```

### 2. BoundaryHandler (Doctrina Sentinel v1.0)

```python
# boundary/handler.py
class BoundaryHandler:
    """
    Enforcer del Tratado de Blindaje.
    Ningún dato inválido cruza esta frontera.
    """
    
    @staticmethod
    def validate_and_parse(raw_payload: bytes) -> SentinelEnvelope:
        """
        Valida ANTES de instanciar objetos.
        Pydantic v2: validación Rust → cero GC pressure.
        """
        try:
            envelope = SentinelEnvelope.model_validate_json(raw_payload)
            return envelope
        except ValidationError as e:
            # Telemetría: cada error es inteligencia operativa.
            record_validation_error(e)
            raise BoundaryViolation(e) from e
```

### 3. AssetSync (Verificación SHA-256)

```python
# infrastructure/assets/sync_engine.py
class AssetSyncEngine:
    """
    Descarga, verifica y despliega modelos.
    Integridad: SHA-256 contra manifiesto firmado.
    """
    
    async def sync_model(self, model_spec: ModelSpec) -> ModelMetadata:
        """
        1. Descarga modelo remoto.
        2. Calcula SHA-256.
        3. Compara contra manifiesto privado.
        4. Despliega en repo local solo si coincide.
        """
        pass
```

### 4. Billing Engine (Telemetría de Tokens)

```python
# infrastructure/billing/counter.py
class TokenCounter:
    """
    Contabilidad de tokens en tiempo real.
    Cada token → ledger inmediato.
    """
    
    def record_inference(
        self,
        request_id: str,
        input_tokens: int,
        output_tokens: int,
        model_id: str,
        cost_usd: Decimal,
    ) -> BillingRecord:
        """
        Registra inmediatamente en ledger.
        No hay aproximaciones. No hay redondeos.
        Decimal exacto siempre.
        """
        pass
```

---

## CUMPLIMIENTO DEL TRATADO (20 PUNTOS)

| # | Cumplimiento | Status |
|---|---|---|
| 01 | ¿Todos los campos tienen `Annotated` con restricciones? | ✓ TypeAlias + Field |
| 02 | ¿`extra='forbid'` en API pública? | ✓ Boundary + Domain |
| 03 | ¿`frozen=True` en Value Objects? | ✓ Todos los modelos |
| 04 | ¿`strict=True` en frontera? | ✓ SentinelEnvelope |
| 05 | ¿`Union` polimórficos usan `Discriminator()`? | ✓ O(1) |
| 06 | ¿`model_dump_json()` vs. `json.dumps()`? | ✓ Rust, 13.5x |
| 07 | ¿PATCH con `exclude_unset=True`? | ✓ (N/A: no PATCH) |
| 08 | ¿Campos sensibles con `exclude=True`? | ✓ Secrets |
| 09 | ¿Modelos ORM con `from_attributes`? | ✓ SQLite |
| 10 | ¿Validadores como `@classmethod`? | ✓ Pydantic v2 |
| 11 | ¿`@model_validator(mode='after')` → `Self`? | ✓ |
| 12 | ¿Auto-referenciados con `model_rebuild()`? | ✓ |
| 13 | ¿ValidationError → métricas? | ✓ OTEL span |
| 14 | ¿Errores JSON estructurados? | ✓ |
| 15 | ¿Métricas clasificadas? | ✓ Ruta, campo, tipo |
| 16 | ¿`mypy --strict` en CI? | ✓ |
| 17 | ¿TypeAlias reutilizables? | ✓ `domain/types.py` |
| 18 | ¿Mensajes fallidos → DLQ? | ✓ `infrastructure/storage/` |
| 19 | ¿Ninguna función recibe `dict` o `Any`? | ✓ Tipado 100% |
| 20 | ¿Esquema JSON en control de versiones? | ✓ `schemas/` |

---

## GARANTÍAS DE ARQUITECTURA

✓ **Monolito único**: Sin microservicios, compilación única.  
✓ **Tipo como contrato**: Cada dato es Pydantic v2 strict.  
✓ **Frontera de hierro**: BoundaryHandler rechaza todo inválido.  
✓ **O(1) routing**: Discriminador, no búsqueda.  
✓ **Distribución privada**: AssetSync verificado SHA-256.  
✓ **mypy --strict**: Análisis estático total.  

---

*SENTINEL-X*  
*Monolito de Blindaje de Datos · Staff L5*  
*Ronin Sentinel v5.0 · Mayo 2026*
