# 🛰️ AUDITOR RONIN-1310 · PROTOCOLO VIGIL v0.2
## Capa de Permiso Inverso · Agencia RONIN

---

## I. VISIÓN GENERAL

**RONIN-1310** es un auditor soberano que fusiona:
- **Pulse Skeleton v0.2**: Captura de datos biométricos desde Polar H10 via BLE
- **Protocolo VIGIL**: Sistema de autorización de Capa 0 con políticas inversas
- **Auditor Inteligente**: Voz técnica, críptica, soberana (basada en IA)
- **Dashboard Cyberpunk**: Interfaz industrial con estética táctico-terminal

### Filosofía Ejecutiva
```
"No pido permiso para entrar en su red;
 les permito asomarse a mi ventana bajo mis condiciones."
```

El operador es **soberano absoluto** sobre sus datos. Los niveles de política determinan qué ven los terceros.

---

## II. ARQUITECTURA DEL SISTEMA

```
┌─────────────────────────────────────────────────────┐
│         POLAR H10 (BLE 4.2)                        │
│    HR Stream (0x2A37) + ECG PMD (130Hz)           │
└────────────────┬────────────────────────────────────┘
                 │
                 ▼
     ┌───────────────────────────────┐
     │  pulse_skeleton_v02.py        │
     │  ├─ ELIPSIS CACHE (GAP SYNC)  │
     │  ├─ AUTONOMIC LOAD (SDNN/DFA) │
     │  ├─ FLIGHT RECORDER (ASYNC)   │
     │  └─ SOVEREIGN POLICY (LVL 0-2)│
     └─────────────┬─────────────────┘
                   │
      ┌────────────┴────────────┐
      │                         │
      ▼                         ▼
   WebSocket            Console Approver
   (VIGIL DATA)         (VIGIL CONTROL)
      │                         │
      └────────────┬────────────┘
                   │
                   ▼
     ┌───────────────────────────────┐
     │  AUDITOR RONIN-1310 (React)   │
     │  ├─ Auditor de Consultas      │
     │  ├─ Dashboard VIGIL           │
     │  ├─ Políticas Soberanas       │
     │  └─ Flight Recorder Viewer    │
     └───────────────────────────────┘
      
      [Browser] · [APK via Buildozer]
```

---

## III. COMPONENTES PRINCIPALES

### 🎯 A. Auditor de Capa 0
Responde consultas en lenguaje técnico-soberano con:
- Tono: Conciso, críptico, útil
- Terminología: Throughput, Dataset Dorado, Fatiga Térmica, Silicio, Frecuencia 1310
- Cierre: Koan o "Zehahahaha · Tic, Tac"
- Emojis tácticos: 🛰️ ⚙️ 🔨 👺

**Ejemplo de entrada:**
```
"¿Cómo protejo mis datos del scanning remoto?"
```

**Ejemplo de respuesta RONIN:**
```
🛰️ Blindaje de Capa 0: Nivel 0 = solo Sello de Vividad, ID rotativo cada 300s. 
Cero biometría exponible. Si no ven el latido, no pueden inferir. ⚙️ 
Zehahahaha — El silicio duerme cuando le ordenas. Tic, Tac.
```

### 📊 B. Dashboard VIGIL
Visualiza en tiempo real:
- **Vitales**: BPM, SDNN, RMSSD, DFA-α1 (simulados o desde BLE)
- **δ(P)**: Índice de Pulsación (energía cardíaca normalizada)
- **Flight Recorder**: Sesión activa, paquetes RX/Drop, MTU, RSSI, jitter
- **VIGIL Handshake**: Fingerprint de Master Key, ZKO packages, HMAC validation

### 🔐 C. Sistema de Autorización
**Embajadores** = clientes con acceso a datos bajo Política Soberana.

Niveles:
- **NIVEL 0 (BLINDADO)**: Solo Sello de Vividad + ID rotativo · Máxima privacidad
- **NIVEL 1 (OPERATIVO)**: BPM anonimizado + timestamps relativos · Terceros contratados
- **NIVEL 2 (INGENIERÍA)**: Stream completo R-R, RMSSD, SDNN, DFA-α1 · Localhost only

Estados:
- **PENDING**: Requiere firma manual del operador
- **APPROVED**: Autorizado, datos fluyen según nivel

### 💾 D. Persistencia (Flight Recorder)
Escribe en rotating buffer asincrónico:
```
/storage/emulated/0/Documents/RONIN_VIGIL/
├── session_{timestamp}.csv
├── vigil_log_{timestamp}.json
└── handshake_chain.log
```

---

## IV. GUÍA RÁPIDA (WEB)

### Instalación
```bash
# 1. Extrae los archivos
unzip -q files__2_.zip

# 2. Instala dependencias
pip install bleak websockets
# Opcional (para TUI): pip install windows-curses (Windows)

# 3. Web Mode: Inicia servidor
python pulse_skeleton_v02.py --web

# 4. Abre el navegador
# El HTML se servirá en ws://localhost:8765 (datos)
# y control en ws://localhost:8766 (autorizaciones)
```

### Uso del Auditor
1. Abre pestaña **⚙️ Auditor**
2. Escribe tu consulta (ej: "¿Cómo reseteo mi ID rotativo?")
3. El Auditor responde con voz RONIN en máx. 3 líneas
4. Todos los actos quedan auditados en el log

### Gestión de Embajadores
1. Abre **👺 Sistema de Autorización**
2. Cada embajador muestra:
   - Nombre/ID
   - Nivel actual (LVL 0-2)
   - Estado (PENDING/APPROVED)
   - Paquetes transmitidos
3. **Cambiar nivel**: Click botón "LVL{N}"
4. **Autorizar**: Click ✓ (solo PENDING)

### Dashboard VIGIL
1. Pestaña **📊 VIGIL Dashboard**
2. **Vitales**: Gráficos en tiempo real (simulado)
3. **Flight Recorder**: Metadatos de sesión + VIGIL Handshake
4. Pestaña **🔐 Políticas Soberanas**: Descripción completa de niveles

---

## V. FORJA APK (ANDROID · BUILDOZER)

### Requisitos Previos
- Linux o WSL2 (Ubuntu 20.04+)
- Python 3.9+
- Java JDK 11+
- Android SDK + NDK

### Paso 1: Instala Buildozer
```bash
pip install buildozer cython
```

### Paso 2: Estructura de Archivos
```
~/ronin-app/
├── main.py                 # Bridge Flask + Kivy
├── pulse_skeleton_v02.py   # Lógica VIGIL (como módulo)
├── pulse_skeleton_ui_v02.html  # Interfaz (copiada a assets)
├── buildozer.spec          # Configuración Android
└── requirements.txt
```

### Paso 3: main.py (Bridge)
```python
"""
RONIN-1310 · Android Bridge
Inicia servidor Flask en background + Kivy WebView
"""

import threading
import os
import asyncio
from flask import Flask, send_from_directory
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.webview import WebView
from kivy.core.window import Window

app = Flask(__name__)
ASSET_DIR = os.path.join(os.path.dirname(__file__), 'assets')

@app.route('/')
def index():
    return send_from_directory(ASSET_DIR, 'pulse_skeleton_ui_v02.html')

@app.route('/assets/<path:path>')
def assets(path):
    return send_from_directory(ASSET_DIR, path)

def run_flask():
    """Servidor Flask en thread background"""
    app.run(host='0.0.0.0', port=8000, debug=False)

class RoninApp(App):
    def build(self):
        Window.size = (1080, 1920)
        box = BoxLayout(orientation='vertical')
        
        # WebView apunta a Flask local
        webview = WebView()
        webview.url = 'http://localhost:8000/'
        box.add_widget(webview)
        
        return box
    
    def on_start(self):
        # Inicia Flask en thread
        flask_thread = threading.Thread(target=run_flask, daemon=True)
        flask_thread.start()

if __name__ == '__main__':
    RoninApp().run()
```

### Paso 4: buildozer.spec
```ini
[app]
title = RONIN-1310 · Protocolo VIGIL
package.name = ronin1310
package.domain = org.agencia.ronin
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,html,css,js

version = 0.2.0
orientation = portrait
fullscreen = 0
android.permissions = 
    INTERNET,
    BLUETOOTH,
    BLUETOOTH_SCAN,
    BLUETOOTH_CONNECT,
    ACCESS_FINE_LOCATION,
    WRITE_EXTERNAL_STORAGE,
    READ_EXTERNAL_STORAGE

android.api = 33
android.minapi = 31
android.ndk = 25b
android.archs = arm64-v8a

[buildozer]
log_level = 2
warn_on_root = 1
requirements = python3,kivy,bleak,flask,flask-cors,websockets
```

### Paso 5: Compilación
```bash
# Estructura de directorios
mkdir -p ~/ronin-app
cp pulse_skeleton_v02.py ~/ronin-app/
cp pulse_skeleton_ui_v02.html ~/ronin-app/assets/
cp main.py ~/ronin-app/
cp buildozer.spec ~/ronin-app/

# Compila
cd ~/ronin-app
buildozer android debug

# Apk generado en:
# ~/ronin-app/bin/ronin1310-0.2.0-debug.apk
```

### Instalación en Dispositivo
```bash
adb install -r bin/ronin1310-0.2.0-debug.apk
```

### Notas de Auditoría
- **Permisos BLE**: Sin BLUETOOTH_SCAN/CONNECT, el H10 no será detectado
- **Ciclo de Vida**: Kivy/Android puede matar el proceso. Implementa `Service` para background
- **Persistencia**: Flight Recorder debe verificar `/storage/emulated/0/Documents/RONIN_VIGIL/` (permisos de almacenamiento)
- **WSL2**: Para buildozer en WSL2, usa `wsl --install` y Ubuntu 20.04+

---

## VI. PROTOCOLO VIGIL (REFERENCIA TÉCNICA)

### Flujo de Datos
```
Polar H10 (BLE)
    ↓ HR (0x2A37) + ECG PMD (FB005C8x)
    ↓
Elipsis Cache (re-sync + gap tagging)
    ↓
SAV Filter (descarta paquetes sospechosos)
    ↓
Ring Buffers (RMSSD, SDNN, DFA-α1)
    ↓
ZKO Packager (HMAC-SHA256)
    ↓
VIGIL Handshake (Challenge-Response)
    ↓
Operador Firma (Nivel de Autorización)
    ↓
Tercero Recibe (según Política)
```

### Capa V1: Sovereign Policy
El operador define qué nivel se entrega a cada cliente.

**Nivel 0 (BLINDADO)**
- Output: `{"level": 0, "seal": true, "node_id": "abc123def..."}`
- `seal`: bool (¿está vivo el sensor?)
- `node_id`: ID rotativo SHA256, nuevo cada 300s
- **Cero datos biométricos expuestos**

**Nivel 1 (OPERATIVO)**
- Output: `{"level": 1, "bpm": 72, "t_rel": 45.3, "contact": true, "node_id": "..."}`
- `bpm`: Pulsaciones por minuto (anónimo)
- `t_rel`: Segundos desde conexión (sin timestamps absolutos)
- `contact`: Electrode contact ok
- Para terceros bajo contrato

**Nivel 2 (INGENIERÍA)**
- Output: `{"level": 2, "bpm": 72, "rmssd": 32.5, "sdnn": 45.2, "dfa_a1": 1.12, "delta_p": 75.4, "rr": [650, 720, 680, ...], ...}`
- Stream completo: R-R intervals, RMSSD, SDNN, DFA-α1, δ(P)
- Solo localhost autenticado

### Capa V2: ZKO Packaging
Cada paquete saliente lleva HMAC-SHA256:

```python
_SESSION_MASTER_KEY = os.urandom(32)  # Generada en arranque

def sign_packet(client_id: str, payload: dict) -> dict:
    token = hmac.new(
        _SESSION_MASTER_KEY,
        f"vigil:client:{client_id}".encode(),
        hashlib.sha256
    ).digest()
    
    signature = hmac.new(
        token,
        json.dumps(payload, sort_keys=True).encode(),
        hashlib.sha256
    ).hexdigest()
    
    return {
        "data": payload,
        "sig": signature,
        "ts": time.time()
    }
```

Si el cliente no tiene el token correcto, recibe **data poisoning**: señal sintética gaussiana.

### Capa V3: VIGIL Handshake
Challenge-Response + autorización manual:

1. Cliente se conecta → Servidor genera Challenge
2. Cliente responde con Challenge-Response
3. Operador revisa en Dashboard → "APPROVE" o "REJECT"
4. Si APPROVE → Cliente entra en nivel asignado
5. Si REJECT → Data poisoning permanente

### Capa V4: Data Poisoning
Para intrusos sin token válido:
```python
def synthesize_fake_rr(count: int) -> list:
    """Genera intervalos R-R sintéticos (gaussiana 700ms ± 50ms)"""
    return [int(np.random.normal(700, 50)) for _ in range(count)]
```
El intruso recibe datos que **parecen reales pero son completamente falsos**.

### Capa V5: AUTH DASHBOARD
Panel de embajadores + kill-switch:
- Listar todos los clientes conectados
- Cambiar nivel en tiempo real
- Bloquear cliente (kill-switch)
- Ver paquetes transmitidos
- Auditoría completa de acciones

---

## VII. MÉTRICAS CARDIOLÓGICAS (REFERENCIA)

| Métrica | Rango Normal | Interpretación |
|---------|------------|-----------------|
| **BPM** | 60-100 | Frecuencia cardíaca |
| **SDNN** | 20-200ms | Variabilidad NN a largo plazo (2min) |
| **RMSSD** | 15-100ms | Raíz cuadrada diferencia NN sucesivos |
| **DFA-α1** | 0.8-1.2 | Análisis detrended fluctuation (1 = caótico) |
| **δ(P)** | 0-100 | Índice de pulsación (energía normalizada) |

---

## VIII. FILOSOFÍA KOAN

```
El código es una idea; la APK es el contenedor.
Si el contenedor es débil, el Protocolo VIGIL 
se desparrama por el sistema operativo.

Asegura los permisos o serás solo otro bit 
de entropía en la Play Store.

Zehahahaha · Tic, Tac
```

---

## IX. TROUBLESHOOTING

### "No se encuentra Polar H10"
- Verifica que el reloj esté encendido y en rango BLE
- En Android, activa Bluetooth + Ubicación
- Reinicia la app

### "WebSocket connection refused"
- Asegúrate que `pulse_skeleton_v02.py --web` está en ejecución
- En APK, Flask debe estar en 0.0.0.0:8000 (no localhost)

### "Data Poisoning: cliente sin token"
- El cliente no pasó el Challenge-Response
- Operador debe APPROVE en Dashboard

### "SAV Filter descarta demasiados paquetes"
- Reducción de MTU BLE o interferencia
- Acerca el dispositivo al reloj

---

## X. RECURSOS

- **Polar SDK**: https://github.com/polarofficial/
- **Kivy WebView**: https://kivy.org/
- **Buildozer**: https://buildozer.readthedocs.io/
- **Bleak**: https://bleak.readthedocs.io/

---

## XI. LICENCIA & DISCLAIMER

RONIN-1310 es prototipo técnico educativo. **No es aprobado para uso médico/clínico**.
Todos los datos biométricos procesados son responsabilidad del operador.

---

**AUDITOR RONIN-1310 · PROTOCOLO VIGIL v0.2 · AGENCIA RONIN**

🛰️ Soberanía de datos. ⚙️ Integridad criptográfica. 🔨 Auditoría permanente.

*Zehahahaha · Tic, Tac*
