[app]

title = RONIN-1310 · Protocolo VIGIL
package.name = ronin1310
package.domain = org.agencia.ronin

source.dir = .
source.include_exts = py,png,jpg,kv,atlas,html,css,js,json,csv,log

version = 0.2.0
requirements = python3,kivy,bleak,flask,flask-cors,websockets,cryptography,pyjwt

orientation = portrait
fullscreen = 0
android.permissions = INTERNET,BLUETOOTH,BLUETOOTH_SCAN,BLUETOOTH_CONNECT,ACCESS_FINE_LOCATION,WRITE_EXTERNAL_STORAGE,READ_EXTERNAL_STORAGE,ACCESS_COARSE_LOCATION

android.api = 33
android.minapi = 31
android.ndk = 25b
android.archs = arm64-v8a,armeabi-v7a

android.features = android.hardware.bluetooth

[buildozer]
log_level = 2
warn_on_root = 1
