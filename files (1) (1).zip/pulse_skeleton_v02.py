"""
╔═══════════════════════════════════════════════════════════════════════╗
║       PULSE SKELETON  v0.2  //  RONIN-1310  ·  PROTOCOLO VIGIL       ║
║  Zero-Cloud · GATT Direct · SAV Filter · δ(P) Live Graph             ║
╠═══════════════════════════════════════════════════════════════════════╣
║  MÓDULOS ORIGINALES:                                                  ║
║   [1] ELIPSIS CACHE     — Temporal re-sync + gap tagging              ║
║   [2] AUTONOMIC LOAD    — SDNN/DFA-α1 + Ectopia detection             ║
║   [3] FLIGHT RECORDER   — Async rotating buffer writer                ║
║   [4] TACTICAL OVERLAY  — (see pulse_skeleton_ui.html)                ║
║   [5] SOVEREIGN BRIDGE  — Binary WS + multi-client + attest           ║
╠═══════════════════════════════════════════════════════════════════════╣
║  PROTOCOLO VIGIL — CAPA DE PERMISO INVERSO:                           ║
║   [V1] SOVEREIGN POLICY  — 3 niveles de entrega de datos              ║
║   [V2] ZKO PACKAGING     — Firma de cargamento + hash HMAC-SHA256     ║
║   [V3] VIGIL HANDSHAKE   — Challenge-Response + autorización manual   ║
║   [V4] DATA POISONING     — Señal sintética gaussiana para intrusos   ║
║   [V5] AUTH DASHBOARD    — Panel de embajadores + kill-switch         ║
╠═══════════════════════════════════════════════════════════════════════╣
║  FILOSOFÍA: "No pido permiso para entrar en su red;                   ║
║              les permito asomarse a mi ventana bajo mis condiciones." ║
╚═══════════════════════════════════════════════════════════════════════╝

Niveles de política:
  Nivel 0 (BLINDADO)   — Solo Sello de Vividad (bool) + ID rotativo. Cero datos biométricos.
  Nivel 1 (OPERATIVO)  — BPM anonimizado (timestamps relativos, sin absolutos).
  Nivel 2 (INGENIERÍA) — Stream completo R-R (solo infraestructura local autenticada).

Flujo VIGIL:
  Sensor → ELIPSIS CACHE → SAV Gate → Ring Buffers
       → ZKO Packager → VIGIL Handshake → Operador firma → Tercero recibe

Usage:
  python pulse_skeleton_v02.py          # TUI mode
  python pulse_skeleton_v02.py --web    # WebSocket + browser UI (VIGIL dashboard)
"""

import asyncio
import struct
import csv
import time
import sys
import math
import argparse
import signal
import os
import threading
import queue as _queue_mod
import hashlib
import hmac
import json
import uuid
import random
from datetime import datetime, timezone
from collections import deque

try:
    from bleak import BleakScanner, BleakClient
except ImportError:
    sys.exit("❌  Install bleak:  pip install bleak")

CURSES_OK = False
try:
    import curses
    CURSES_OK = True
except ImportError:
    pass

WS_OK = False
try:
    import websockets
    WS_OK = True
except ImportError:
    pass


# ══════════════════════════════════════════════════════════════════════════════
#  GATT / PMD CONSTANTS
# ══════════════════════════════════════════════════════════════════════════════

HR_MEASUREMENT_UUID = "00002a37-0000-1000-8000-00805f9b34fb"
PMD_CONTROL_UUID    = "fb005c81-02e7-f387-1cad-8d263ba56064"
PMD_DATA_UUID       = "fb005c82-02e7-f387-1cad-8d263ba56064"

ECG_START_CMD = bytes([0x02, 0x00, 0x00, 0x01, 0x82, 0x00, 0x01, 0x01, 0x0e, 0x00])
ECG_STOP_CMD  = bytes([0x03, 0x00])


# ══════════════════════════════════════════════════════════════════════════════
#  [V1] SOVEREIGN POLICY — Manifiesto de Privacidad Dinámico
#  Define qué datos se entregan según el nivel de acceso del cliente.
# ══════════════════════════════════════════════════════════════════════════════

class PolicyLevel:
    BLINDADO   = 0   # Solo Sello de Vividad + ID rotativo
    OPERATIVO  = 1   # BPM anonimizado (timestamps relativos)
    INGENIERIA = 2   # Stream completo R-R (solo local)

POLICY_NAMES = {
    PolicyLevel.BLINDADO:   "NIVEL 0 · BLINDADO",
    PolicyLevel.OPERATIVO:  "NIVEL 1 · OPERATIVO",
    PolicyLevel.INGENIERIA: "NIVEL 2 · INGENIERÍA",
}

class SovereignPolicy:
    """
    Configuración de política soberana de entrega de datos.
    El operador decide qué nivel se concede a cada cliente.

    Nivel 0 — BLINDADO:
        Solo entrega el "Sello de Vividad" (bool vivo=True/False)
        y un ID rotativo que cambia cada 5 minutos. Cero biometría.

    Nivel 1 — OPERATIVO:
        Entrega BPM anonimizado. Sin timestamps absolutos,
        solo tiempo relativo desde la conexión del cliente.
        Adecuado para apps de terceros bajo contrato.

    Nivel 2 — INGENIERÍA:
        Acceso total al stream de intervalos R-R, RMSSD, SDNN, DFA-α1.
        Reservado exclusivamente para infraestructura local autenticada.
        Solo se concede desde localhost o IP explícitamente permitida.
    """
    # IP de confianza total (solo NIVEL 2 disponible desde aquí)
    TRUSTED_LOCAL_IPS = {"127.0.0.1", "::1"}

    # ID rotativo: cambia cada 5 minutos para impedir correlación temporal
    ID_ROTATION_SECS  = 300

    def __init__(self):
        self._rotating_id_base = uuid.uuid4().hex
        self._id_epoch         = time.time()

    def rotating_id(self) -> str:
        """Devuelve un ID anónimo que rota cada ID_ROTATION_SECS."""
        now = time.time()
        if now - self._id_epoch > self.ID_ROTATION_SECS:
            self._rotating_id_base = uuid.uuid4().hex
            self._id_epoch = now
        # Hash del ID base + ventana temporal → irrtraeable entre rotaciones
        window = int(now / self.ID_ROTATION_SECS)
        return hashlib.sha256(
            f"{self._rotating_id_base}:{window}".encode()
        ).hexdigest()[:16]

    def pack_level0(self, alive: bool) -> dict:
        """Nivel 0: Solo el Sello de Vividad y el ID rotativo."""
        return {
            "level":    0,
            "seal":     alive,
            "node_id":  self.rotating_id(),
        }

    def pack_level1(self, bpm: int, elapsed_relative: float, contact: bool) -> dict:
        """Nivel 1: BPM anonimizado. Sin timestamps absolutos."""
        return {
            "level":    1,
            "bpm":      bpm,
            "t_rel":    round(elapsed_relative, 1),   # segundos desde conexión del cliente
            "contact":  contact,
            "node_id":  self.rotating_id(),
        }

    def pack_level2(self, bpm, rmssd, sdnn, dfa, delta_p,
                    rr_intervals, elapsed, contact, ectopic,
                    attest, drop_pct, jitter_ms, ect_total) -> dict:
        """Nivel 2: Stream completo — solo para infraestructura propia."""
        return {
            "level":    2,
            "bpm":      bpm,
            "rmssd":    rmssd,
            "sdnn":     sdnn,
            "dfa_a1":   dfa,
            "delta_p":  delta_p,
            "rr":       list(rr_intervals)[-4:] if rr_intervals else [],
            "elapsed":  round(elapsed, 2),
            "contact":  contact,
            "ectopic":  ectopic,
            "attest":   attest,
            "drop_pct": round(drop_pct, 2),
            "jitter_ms":round(jitter_ms, 2),
            "ect_total":ect_total,
            "node_id":  self.rotating_id(),
        }


POLICY = SovereignPolicy()


# ══════════════════════════════════════════════════════════════════════════════
#  [V2] ZKO PACKAGING — Firma de Cargamento (Zero-Knowledge Objects)
#  Cada paquete saliente lleva un HMAC-SHA256. Si el receptor no tiene
#  el token de sesión firmado, el paquete se auto-destruye (datos sintéticos).
# ══════════════════════════════════════════════════════════════════════════════

# Clave maestra de sesión — generada en arranque, nunca sale del proceso
_SESSION_MASTER_KEY = os.urandom(32)

def _derive_client_token(client_id: str) -> bytes:
    """Deriva un token de cliente desde la clave maestra de sesión."""
    return hmac.new(
        _SESSION_MASTER_KEY,
        f"vigil:client:{client_id}".encode(),
        hashlib.sha256
    ).digest()

def zko_sign(payload: dict, client_token: bytes) -> dict:
    """
    Firma un paquete de datos con HMAC-SHA256.
    El receptor debe tener el token para verificar el paquete.
    """
    canonical = json.dumps(payload, sort_keys=True, separators=(',', ':'))
    sig = hmac.new(client_token, canonical.encode(), hashlib.sha256).hexdigest()
    return {
        "zko":  payload,
        "sig":  sig,
        "seq":  int(time.time() * 1000),  # timestamp de secuencia (ms)
    }

def zko_verify(signed_packet: dict, client_token: bytes) -> bool:
    """Verifica la firma de un paquete ZKO."""
    try:
        payload  = signed_packet["zko"]
        sig_recv = signed_packet["sig"]
        canonical = json.dumps(payload, sort_keys=True, separators=(',', ':'))
        sig_exp  = hmac.new(client_token, canonical.encode(), hashlib.sha256).hexdigest()
        return hmac.compare_digest(sig_recv, sig_exp)
    except Exception:
        return False


# ══════════════════════════════════════════════════════════════════════════════
#  [V4] DATA POISONING — Señal Sintética Gaussiana
#  Si un cliente no autorizado rompe el cifrado, solo obtiene ruido gaussiano
#  calibrado para parecer biométrico real pero inútil para perfilado.
# ══════════════════════════════════════════════════════════════════════════════

class DataPoisoner:
    """
    Genera señales de pulso sintéticas pero biológicamente plausibles.
    El objetivo es "envenenar" bases de datos de perfilado con datos
    inútiles mientras el operador mantiene los datos reales en caché local.

    El ruido gaussiano se calibra para:
    - Parecer biométricamente legítimo (BPM en rango normal)
    - Variar suficientemente para superar detección de datos estáticos
    - Ser imposible de correlacionar con el individuo real
    """
    def __init__(self):
        self._fake_bpm_base  = random.uniform(62, 78)
        self._fake_rmssd_base = random.uniform(30, 55)
        self._t_offset        = random.uniform(0, 1000)

    def _drift(self, t: float, period: float = 120) -> float:
        """Simula deriva fisiológica lenta (ciclos de ~2 min)."""
        return math.sin(2 * math.pi * (t + self._t_offset) / period)

    def fake_level0(self) -> dict:
        """Nivel 0 envenenado: Sello de Vividad siempre True, ID falso."""
        return {
            "level":   0,
            "seal":    True,
            "node_id": uuid.uuid4().hex[:16],
        }

    def fake_level1(self, elapsed: float) -> dict:
        """
        Nivel 1 envenenado: BPM gaussiano plausible pero falso.
        Varía con deriva sinusoidal + ruido blanco gaussiano.
        """
        drift  = self._drift(elapsed) * 8
        noise  = random.gauss(0, 2.5)
        fake_bpm = int(max(48, min(110, self._fake_bpm_base + drift + noise)))
        return {
            "level":   1,
            "bpm":     fake_bpm,
            "t_rel":   round(elapsed + random.gauss(0, 0.3), 1),
            "contact": True,
            "node_id": uuid.uuid4().hex[:16],
        }

    def fake_level2(self, elapsed: float) -> dict:
        """
        Nivel 2 envenenado: Stream completo falso con correlaciones
        fisiológicamente plausibles pero estadísticamente inútiles.
        """
        drift  = self._drift(elapsed) * 8
        noise  = random.gauss(0, 2.5)
        bpm    = int(max(48, min(110, self._fake_bpm_base + drift + noise)))
        rr_base = int(60000 / bpm)
        rmssd  = max(10, self._fake_rmssd_base + random.gauss(0, 5))
        sdnn   = max(15, rmssd * random.uniform(1.2, 1.8))
        dfa    = round(max(0.5, min(1.4, 0.95 + random.gauss(0, 0.15))), 3)
        dp     = round(max(10, min(90, 55 + drift * 2 + random.gauss(0, 5))), 1)
        rr_list = [int(rr_base + random.gauss(0, rmssd * 0.5)) for _ in range(3)]
        return {
            "level":    2,
            "bpm":      bpm,
            "rmssd":    round(rmssd, 1),
            "sdnn":     round(sdnn, 1),
            "dfa_a1":   dfa,
            "delta_p":  dp,
            "rr":       rr_list,
            "elapsed":  round(elapsed, 2),
            "contact":  True,
            "ectopic":  False,
            "attest":   True,
            "drop_pct": round(random.uniform(0, 3), 2),
            "jitter_ms":round(random.uniform(5, 40), 2),
            "ect_total": 0,
            "node_id":  uuid.uuid4().hex[:16],
        }

POISONER = DataPoisoner()


# ══════════════════════════════════════════════════════════════════════════════
#  [V3] VIGIL HANDSHAKE — Registro de Embajadores y Challenge-Response
#  Los clientes deben enviar un "Manifiesto de Intenciones".
#  El operador aprueba o rechaza manualmente.
# ══════════════════════════════════════════════════════════════════════════════

class AmbassadorStatus:
    PENDING   = "PENDING"    # Esperando aprobación del operador
    APPROVED  = "APPROVED"   # Acceso concedido (nivel definido)
    REJECTED  = "REJECTED"   # Acceso denegado
    POISONED  = "POISONED"   # Activo pero recibiendo datos sintéticos
    KILLED    = "KILLED"     # Kill-switch activado (desconexión forzada)

class Ambassador:
    """
    Representa un cliente conectado al Sovereign Bridge.
    Cada embajador tiene su propio nivel de política, token y estado.
    """
    def __init__(self, client_id: str, ip: str, manifest: dict):
        self.client_id   = client_id
        self.ip          = ip
        self.manifest    = manifest          # Manifiesto de Intenciones recibido
        self.status      = AmbassadorStatus.PENDING
        self.level       = PolicyLevel.BLINDADO  # nivel concedido (default: 0)
        self.token       = _derive_client_token(client_id)
        self.connected_at = time.time()
        self.packets_sent = 0
        self.last_seen    = time.time()
        self.ws           = None            # referencia al websocket
        self.connect_time = time.time()     # para timestamps relativos

    def elapsed_since_connect(self) -> float:
        return time.time() - self.connect_time

    def to_dict(self) -> dict:
        return {
            "id":          self.client_id,
            "ip":          self.ip,
            "status":      self.status,
            "level":       self.level,
            "level_name":  POLICY_NAMES.get(self.level, "?"),
            "manifest":    self.manifest,
            "connected_at": datetime.fromtimestamp(self.connected_at).isoformat(),
            "packets_sent": self.packets_sent,
            "last_seen":   datetime.fromtimestamp(self.last_seen).isoformat(),
        }


class VIGILRegistry:
    """
    Registro central de todos los embajadores (clientes conectados).
    Gestiona el ciclo de vida del handshake y las autorizaciones.
    """
    def __init__(self):
        self._ambassadors: dict[str, Ambassador] = {}   # client_id → Ambassador
        self._lock = threading.Lock()
        # Cola de solicitudes pendientes para el TUI/operador
        self.pending_queue: asyncio.Queue = None   # se inicializa en el loop asyncio
        # Cola de notificaciones al dashboard UI
        self.ui_events: asyncio.Queue = None

    def init_queues(self):
        self.pending_queue = asyncio.Queue()
        self.ui_events     = asyncio.Queue(maxsize=128)

    def register(self, client_id: str, ip: str, manifest: dict, ws) -> Ambassador:
        amb = Ambassador(client_id, ip, manifest, )
        amb.ws = ws
        with self._lock:
            self._ambassadors[client_id] = amb
        return amb

    def get(self, client_id: str) -> Ambassador | None:
        return self._ambassadors.get(client_id)

    def all(self) -> list[Ambassador]:
        with self._lock:
            return list(self._ambassadors.values())

    def remove(self, client_id: str):
        with self._lock:
            self._ambassadors.pop(client_id, None)

    def approve(self, client_id: str, level: int) -> bool:
        amb = self.get(client_id)
        if not amb:
            return False
        amb.status = AmbassadorStatus.APPROVED
        amb.level  = level
        self._notify_ui("APPROVED", amb)
        return True

    def reject(self, client_id: str) -> bool:
        amb = self.get(client_id)
        if not amb:
            return False
        amb.status = AmbassadorStatus.REJECTED
        self._notify_ui("REJECTED", amb)
        return True

    def poison(self, client_id: str) -> bool:
        """Activa el modo de datos envenenados para un cliente."""
        amb = self.get(client_id)
        if not amb:
            return False
        amb.status = AmbassadorStatus.POISONED
        self._notify_ui("POISONED", amb)
        return True

    def kill(self, client_id: str) -> bool:
        """Kill-switch: desconecta un cliente de forma forzada."""
        amb = self.get(client_id)
        if not amb:
            return False
        amb.status = AmbassadorStatus.KILLED
        self._notify_ui("KILLED", amb)
        return True

    def _notify_ui(self, event: str, amb: Ambassador):
        if self.ui_events:
            try:
                self.ui_events.put_nowait({
                    "event":     event,
                    "client_id": amb.client_id,
                    "data":      amb.to_dict(),
                })
            except asyncio.QueueFull:
                pass

    def pending_approval(self) -> list[Ambassador]:
        return [a for a in self.all() if a.status == AmbassadorStatus.PENDING]

    def active_count(self) -> int:
        return len([a for a in self.all()
                    if a.status in (AmbassadorStatus.APPROVED, AmbassadorStatus.POISONED)])


VIGIL = VIGILRegistry()


# ══════════════════════════════════════════════════════════════════════════════
#  MODULE 1: ELIPSIS CACHE  (original v0.1)
# ══════════════════════════════════════════════════════════════════════════════

class EllipsisCache:
    CACHE_MS         = 200
    GAP_THRESHOLD_MS = 3000
    ECG_GAP_MS       = 1500

    def __init__(self):
        self._hr_pending  : list = []
        self._ecg_pending : list = []
        self._lock        = threading.Lock()
        self.last_hr_ts   = 0
        self.last_ecg_ts  = 0
        self.jitter_buf   = deque(maxlen=32)
        self.jitter_ms    = 0.0

    def push_hr(self, data: bytearray) -> None:
        now_ns = time.time_ns()
        with self._lock:
            if self.last_hr_ts > 0:
                delta_ms = (now_ns - self.last_hr_ts) / 1_000_000
                self.jitter_buf.append(delta_ms)
                if len(self.jitter_buf) > 1:
                    self.jitter_ms = float(max(self.jitter_buf) - min(self.jitter_buf))
            self.last_hr_ts = now_ns
            self._hr_pending.append((now_ns, data))

    def push_ecg(self, data: bytearray) -> None:
        hw_ts = struct.unpack_from("<Q", data, 1)[0]
        with self._lock:
            self._ecg_pending.append((hw_ts, data))

    def flush_hr(self) -> list:
        cutoff = time.time_ns() - self.CACHE_MS * 1_000_000
        with self._lock:
            ready = [(ts, d) for ts, d in self._hr_pending if ts <= cutoff]
            self._hr_pending = [(ts, d) for ts, d in self._hr_pending if ts > cutoff]
        if not ready:
            return []
        ready.sort(key=lambda x: x[0])
        result = []
        prev_ts = None
        for ts_ns, data in ready:
            if prev_ts is not None:
                gap_ms = (ts_ns - prev_ts) / 1_000_000
                if gap_ms > self.GAP_THRESHOLD_MS:
                    result.append((True, None))
            result.append((False, data))
            prev_ts = ts_ns
        return result

    def flush_ecg(self) -> list:
        with self._lock:
            ready = self._ecg_pending[:]
            self._ecg_pending.clear()
        if not ready:
            return []
        ready.sort(key=lambda x: x[0])
        result = []
        prev_ts = None
        for ts_ns, data in ready:
            if prev_ts is not None:
                gap_ms = (ts_ns - prev_ts) / 1_000_000
                if 0 < gap_ms > self.ECG_GAP_MS:
                    result.append((True, None))
            result.append((False, data))
            prev_ts = ts_ns
        return result


# ══════════════════════════════════════════════════════════════════════════════
#  MODULE 3: FLIGHT RECORDER  (original v0.1)
# ══════════════════════════════════════════════════════════════════════════════

class FlightRecorder:
    MAX_ROWS    = 50_000
    FLUSH_EVERY = 64
    SENTINEL    = object()

    def __init__(self, prefix: str, header: list):
        self.prefix   = prefix
        self.header   = header
        self._q       = _queue_mod.Queue(maxsize=4096)
        self._rows    = 0
        self._path    = None
        self._fh      = None
        self._writer  = None
        self._thread  = threading.Thread(target=self._worker, daemon=True)
        self._thread.start()

    def set_metadata(self, mtu: int, rssi: int, device: str):
        self._q.put({"__meta__": True, "mtu": mtu, "rssi": rssi, "device": device})

    def write(self, row: list):
        try:
            self._q.put_nowait(row)
        except _queue_mod.Full:
            pass

    def close(self):
        self._q.put(self.SENTINEL)
        self._thread.join(timeout=5)

    def _open_file(self):
        ts         = datetime.now().strftime("%Y%m%d_%H%M%S")
        self._path = f"{self.prefix}_{ts}.csv"
        self._fh   = open(self._path + ".tmp", "w", newline="", buffering=8192)
        self._writer = csv.writer(self._fh)
        self._rows = 0

    def _rotate(self):
        if self._fh:
            self._fh.flush()
            os.fsync(self._fh.fileno())
            self._fh.close()
            try:
                os.replace(self._path + ".tmp", self._path)
            except OSError:
                pass

    def _worker(self):
        self._open_file()
        flush_ctr = 0
        while True:
            item = self._q.get()
            if item is self.SENTINEL:
                self._rotate()
                break
            if isinstance(item, dict) and item.get("__meta__"):
                self._writer.writerow(["# PULSE SKELETON v0.2 // RONIN-1310 · VIGIL"])
                self._writer.writerow(["# session_start", datetime.now().isoformat()])
                self._writer.writerow(["# device",    item["device"]])
                self._writer.writerow(["# mtu_bytes", item["mtu"]])
                self._writer.writerow(["# rssi_dbm",  item["rssi"]])
                self._writer.writerow(self.header)
                continue
            self._writer.writerow(item)
            self._rows += 1
            flush_ctr  += 1
            if flush_ctr >= self.FLUSH_EVERY:
                self._fh.flush()
                flush_ctr = 0
            if self._rows >= self.MAX_ROWS:
                self._rotate()
                self._open_file()
                self._writer.writerow(self.header)


# ══════════════════════════════════════════════════════════════════════════════
#  SESSION STATE
# ══════════════════════════════════════════════════════════════════════════════

class Session:
    def __init__(self):
        self.start         = time.time()
        self.rr_buf        = deque(maxlen=128)
        self.rr_clean      = deque(maxlen=128)
        self.delta_p_hist  = deque(maxlen=120)
        self.ecg_buf       = deque(maxlen=1300)
        self.bpm_history   = deque(maxlen=120)
        self.bpm           = 0
        self.last_rr       = []
        self.rmssd         = None
        self.sdnn          = None
        self.dfa_alpha1    = None
        self.contact_ok    = False
        self.ecg_mode      = False
        self.packets_rx    = 0
        self.packets_drop  = 0
        self.last_ts       = None
        self.gap_events    = 0
        self.device_name   = "—"
        self.ectopic_count = 0
        self.ectopic_flag  = False
        self.mtu           = 244
        self.rssi          = -70
        self.sav_streak    = 0
        self.attest_active = False
        self.cache         = EllipsisCache()
        self.fr_hr         = None
        self.fr_ecg        = None
        # VIGIL: cola de broadcast al dashboard (JSON, no binario)
        self.vigil_queue   = asyncio.Queue(maxsize=128)

    def elapsed(self) -> float:
        return time.time() - self.start

    def open_recorders(self):
        self.fr_hr  = FlightRecorder("vigil_hr",  [
            "epoch_ms","bpm","rr_ms","rmssd","sdnn","dfa_alpha1",
            "delta_p","contact","ectopic","gap"
        ])
        self.fr_ecg = FlightRecorder("vigil_ecg", [
            "epoch_ms","sample_i","ecg_uV"
        ])

    def set_link_metadata(self):
        for fr in (self.fr_hr, self.fr_ecg):
            if fr:
                fr.set_metadata(self.mtu, self.rssi, self.device_name)

    def close_recorders(self):
        for fr in (self.fr_hr, self.fr_ecg):
            if fr:
                try:
                    fr.close()
                except Exception:
                    pass


S = Session()


# ══════════════════════════════════════════════════════════════════════════════
#  SAV — SOBERANÍA DE AUTENTICACIÓN DE VALOR (original v0.1)
# ══════════════════════════════════════════════════════════════════════════════

class SAVResult:
    __slots__ = ("ok", "contact", "reason", "ectopic")
    def __init__(self, ok: bool, contact: bool, reason: str = "", ectopic: bool = False):
        self.ok      = ok
        self.contact = contact
        self.reason  = reason
        self.ectopic = ectopic


def sav_audit_hr(flags: int, rr_intervals: list) -> SAVResult:
    contact_supported = bool(flags & 0x04)
    contact_detected  = bool(flags & 0x02)
    contact = contact_detected if contact_supported else True

    if contact_supported and not contact_detected:
        return SAVResult(False, False, "L1:no-contact")

    if not rr_intervals:
        return SAVResult(True, contact, "no-rr")

    for rr in rr_intervals:
        if not (200 <= rr <= 2000):
            return SAVResult(False, contact, f"L2:implausible-rr={rr}ms")

    if len(S.rr_buf) >= 1:
        prev = S.rr_buf[-1]
        for rr in rr_intervals:
            deviation = abs(rr - prev) / prev
            if deviation > 0.40:
                return SAVResult(False, contact, f"L3:incoherent Δ={deviation:.0%}")
            prev = rr

    ectopic = False
    if len(S.rr_buf) >= 4:
        recent_mean = sum(list(S.rr_buf)[-8:]) / min(8, len(S.rr_buf))
        for i, rr in enumerate(rr_intervals):
            if rr < 0.70 * recent_mean:
                next_rr = rr_intervals[i+1] if i+1 < len(rr_intervals) else None
                if next_rr is None or next_rr > 1.30 * recent_mean:
                    ectopic = True
                    S.ectopic_count += 1
                    S.ectopic_flag   = True
                    break
        if not ectopic:
            S.ectopic_flag = False

    return SAVResult(True, contact, "pass", ectopic=ectopic)


def sav_audit_ecg(data: bytearray) -> bool:
    if len(data) < 13:
        return False
    if data[0] != 0x00:
        return False
    if data[9] != 0x00:
        return False
    sample = int.from_bytes(data[10:13], byteorder="little", signed=True)
    MAX_14BIT = (1 << 13) - 1
    if abs(sample) >= MAX_14BIT:
        return False
    return True


# ══════════════════════════════════════════════════════════════════════════════
#  DECODERS (original v0.1)
# ══════════════════════════════════════════════════════════════════════════════

def decode_hr(data: bytearray) -> tuple:
    flags   = data[0]
    hr_u16  = bool(flags & 0x01)
    ee_pres = bool(flags & 0x08)
    rr_pres = bool(flags & 0x10)
    cursor = 1
    if hr_u16:
        bpm = struct.unpack_from("<H", data, cursor)[0]
        cursor += 2
    else:
        bpm = data[cursor]
        cursor += 1
    if ee_pres:
        cursor += 2
    rr_list = []
    if rr_pres:
        while cursor + 1 < len(data):
            raw = struct.unpack_from("<H", data, cursor)[0]
            rr_list.append(int(raw * 1000 / 1024))
            cursor += 2
    return bpm, rr_list


def decode_ecg_frame(data: bytearray) -> tuple:
    ts_ns   = struct.unpack_from("<Q", data, 1)[0]
    epoch   = int(ts_ns / 1_000_000)
    samples = []
    i = 10
    while i + 2 < len(data):
        v = int.from_bytes(data[i:i+3], byteorder="little", signed=True)
        samples.append(v)
        i += 3
    return epoch, samples


# ══════════════════════════════════════════════════════════════════════════════
#  MODULE 2: AUTONOMIC LOAD SPECTRUM (original v0.1)
# ══════════════════════════════════════════════════════════════════════════════

def compute_rmssd() -> float | None:
    b = list(S.rr_clean)
    if len(b) < 4:
        return None
    sq_diffs = [(b[i+1] - b[i]) ** 2 for i in range(len(b) - 1)]
    return math.sqrt(sum(sq_diffs) / len(sq_diffs))


def compute_sdnn(window_s: int = 120) -> float | None:
    b = list(S.rr_clean)
    n = min(len(b), window_s)
    if n < 8:
        return None
    recent  = b[-n:]
    mean    = sum(recent) / len(recent)
    var     = sum((x - mean) ** 2 for x in recent) / len(recent)
    return math.sqrt(var)


def compute_dfa_alpha1() -> float | None:
    rr = list(S.rr_clean)
    if len(rr) < 32:
        return None
    mean_rr = sum(rr) / len(rr)
    y = [0.0]
    for v in rr:
        y.append(y[-1] + (v - mean_rr))
    scales = [4, 6, 8, 10, 12, 16]
    log_n, log_F = [], []
    for n in scales:
        if n > len(y) // 2:
            break
        num_boxes = len(y) // n
        if num_boxes < 2:
            break
        f2_vals = []
        for b in range(num_boxes):
            seg = y[b*n : (b+1)*n]
            xs  = list(range(n))
            sx  = sum(xs); sy = sum(seg)
            sxx = sum(x*x for x in xs)
            sxy = sum(x*v for x, v in zip(xs, seg))
            denom = n * sxx - sx * sx
            if denom == 0:
                continue
            slope = (n * sxy - sx * sy) / denom
            intercept = (sy - slope * sx) / n
            res = [(seg[i] - (slope*i + intercept))**2 for i in range(n)]
            f2_vals.append(sum(res) / n)
        if not f2_vals:
            continue
        F = math.sqrt(sum(f2_vals) / len(f2_vals))
        if F > 0 and n > 0:
            log_n.append(math.log(n))
            log_F.append(math.log(F))
    if len(log_n) < 3:
        return None
    n_pts = len(log_n)
    sx = sum(log_n); sy = sum(log_F)
    sxx = sum(x*x for x in log_n)
    sxy = sum(x*y for x, y in zip(log_n, log_F))
    denom = n_pts * sxx - sx * sx
    if denom == 0:
        return None
    return round((n_pts * sxy - sx * sy) / denom, 3)


def compute_delta_p(bpm: int, rmssd: float | None) -> float | None:
    if rmssd is None:
        return None
    bpm_score = max(0.0, 100.0 - abs(bpm - 60))
    hrv_score = min(100.0, rmssd * 2.0)
    return 0.35 * bpm_score + 0.65 * hrv_score


# ══════════════════════════════════════════════════════════════════════════════
#  MODULE 5: SOVEREIGN BRIDGE — Binary Frame Builder (original v0.1)
# ══════════════════════════════════════════════════════════════════════════════

FRAME_FMT         = "<BfHffffBBHHBh"
FRAME_TYPE_DATA   = 0x01
FRAME_TYPE_ATTEST = 0x02
FRAME_TYPE_GAP    = 0x03
_NaN32 = struct.unpack("<f", b'\x00\x00\xc0\x7f')[0]


def _f32(v) -> float:
    return float(v) if v is not None else _NaN32


def build_binary_frame(elapsed, bpm, rmssd, delta_p, sdnn, dfa_a1,
                       contact, ectopic, drop_pct, jitter_ms,
                       attest, ectopic_total,
                       ftype=FRAME_TYPE_DATA) -> bytes:
    return struct.pack(
        FRAME_FMT,
        ftype, float(elapsed), int(bpm),
        _f32(rmssd), _f32(delta_p), _f32(sdnn), _f32(dfa_a1),
        int(contact), int(ectopic),
        int(drop_pct * 10), int(jitter_ms * 10),
        int(attest), int(ectopic_total),
    )


def build_gap_frame() -> bytes:
    return build_binary_frame(
        S.elapsed(), 0, None, None, None, None,
        False, False, 0.0, 0.0, False, 0,
        ftype=FRAME_TYPE_GAP
    )


def update_attestation(sav_ok: bool):
    if sav_ok:
        S.sav_streak += 1
        if S.sav_streak >= 30:
            S.attest_active = True
    else:
        S.sav_streak    = 0
        S.attest_active = False


# ══════════════════════════════════════════════════════════════════════════════
#  VIGIL DATA DISPATCH — Empaqueta y entrega datos según nivel del embajador
# ══════════════════════════════════════════════════════════════════════════════

def vigil_build_payload(amb: Ambassador, delta_p) -> dict | None:
    """
    Construye el payload para un embajador según su nivel de política.
    Si está envenenado, devuelve datos sintéticos.
    Si está en NIVEL 0, solo el Sello de Vividad.
    """
    if amb.status == AmbassadorStatus.POISONED:
        elapsed = amb.elapsed_since_connect()
        fake = {
            PolicyLevel.BLINDADO:   lambda: POISONER.fake_level0(),
            PolicyLevel.OPERATIVO:  lambda: POISONER.fake_level1(elapsed),
            PolicyLevel.INGENIERIA: lambda: POISONER.fake_level2(elapsed),
        }.get(amb.level, lambda: POISONER.fake_level0())()
        return zko_sign(fake, amb.token)

    if amb.status != AmbassadorStatus.APPROVED:
        return None

    t_rel = amb.elapsed_since_connect()

    if amb.level == PolicyLevel.BLINDADO:
        payload = POLICY.pack_level0(alive=S.attest_active or S.contact_ok)
    elif amb.level == PolicyLevel.OPERATIVO:
        payload = POLICY.pack_level1(S.bpm, t_rel, S.contact_ok)
    else:  # INGENIERIA
        drop_pct = 100 * S.packets_drop / max(1, S.packets_rx)
        payload = POLICY.pack_level2(
            S.bpm, S.rmssd, S.sdnn, S.dfa_alpha1, delta_p,
            S.last_rr, S.elapsed(), S.contact_ok, S.ectopic_flag,
            S.attest_active, drop_pct, S.cache.jitter_ms, S.ectopic_count
        )

    return zko_sign(payload, amb.token)


# ══════════════════════════════════════════════════════════════════════════════
#  BLE NOTIFICATION HANDLERS
# ══════════════════════════════════════════════════════════════════════════════

def hr_handler(_sender, data: bytearray):
    S.packets_rx += 1
    S.cache.push_hr(data)

    for is_gap, pkt in S.cache.flush_hr():
        if is_gap:
            S.gap_events += 1
            epoch = int(time.time() * 1000)
            if S.fr_hr:
                S.fr_hr.write([epoch, "", "", "", "", "", "", "", "", "GAP"])
            # Notificar gap a todos los embajadores autorizados
            _vigil_broadcast_gap()
            continue
        _process_hr_packet(pkt)


def _vigil_broadcast_gap():
    """Notifica un evento GAP a todos los embajadores."""
    for amb in VIGIL.all():
        if amb.status in (AmbassadorStatus.APPROVED, AmbassadorStatus.POISONED):
            gap_pkg = {"zko": {"type": "gap", "t": S.elapsed()}, "sig": "", "seq": int(time.time()*1000)}
            _enqueue_vigil(amb, gap_pkg)


def _enqueue_vigil(amb: Ambassador, pkg: dict):
    """Encola un paquete para envío al embajador."""
    if amb.ws is None:
        return
    try:
        S.vigil_queue.put_nowait((amb.client_id, json.dumps(pkg)))
    except asyncio.QueueFull:
        pass


def _process_hr_packet(data: bytearray):
    t0 = time.monotonic_ns()

    bpm, rr_list = decode_hr(data)
    audit        = sav_audit_hr(data[0], rr_list)

    S.contact_ok = audit.contact
    update_attestation(audit.ok)

    if not audit.ok:
        S.packets_drop += 1
        return

    S.bpm     = bpm
    S.last_rr = rr_list

    for rr in rr_list:
        S.rr_buf.append(rr)
        if not audit.ectopic:
            S.rr_clean.append(rr)

    S.rmssd      = compute_rmssd()
    S.sdnn       = compute_sdnn()
    S.dfa_alpha1 = compute_dfa_alpha1()
    delta_p      = compute_delta_p(bpm, S.rmssd)

    if delta_p is not None:
        S.delta_p_hist.append(delta_p)
    S.bpm_history.append(bpm)

    if S.fr_hr:
        epoch = int(time.time() * 1000)
        for rr in (rr_list or [""]):
            S.fr_hr.write([
                epoch, bpm, rr,
                round(S.rmssd, 2)      if S.rmssd      else "",
                round(S.sdnn, 2)       if S.sdnn       else "",
                S.dfa_alpha1           if S.dfa_alpha1 else "",
                round(delta_p, 2)      if delta_p      else "",
                int(audit.contact),
                int(audit.ectopic),
                "",
            ])

    # [V2] Dispatch VIGIL por nivel de política
    for amb in VIGIL.all():
        if amb.status in (AmbassadorStatus.APPROVED, AmbassadorStatus.POISONED):
            pkg = vigil_build_payload(amb, delta_p)
            if pkg:
                amb.packets_sent += 1
                amb.last_seen = time.time()
                _enqueue_vigil(amb, pkg)

    # Notificar al dashboard VIGIL sobre el estado actual (solo embajadores aprobados)
    _notify_vigil_dashboard()


def _notify_vigil_dashboard():
    """Envía estado actual del registro VIGIL al dashboard del operador."""
    if VIGIL.ui_events is None:
        return
    try:
        VIGIL.ui_events.put_nowait({
            "event":       "HEARTBEAT",
            "ambassadors": [a.to_dict() for a in VIGIL.all()],
            "pending":     len(VIGIL.pending_approval()),
            "active":      VIGIL.active_count(),
        })
    except asyncio.QueueFull:
        pass


def ecg_handler(_sender, data: bytearray):
    S.packets_rx += 1
    S.cache.push_ecg(data)

    for is_gap, pkt in S.cache.flush_ecg():
        if is_gap:
            S.gap_events += 1
            if S.fr_ecg:
                S.fr_ecg.write([int(time.time() * 1000), "GAP", ""])
            continue
        if not sav_audit_ecg(pkt):
            S.packets_drop += 1
            continue
        epoch, samples = decode_ecg_frame(pkt)
        for i, v in enumerate(samples):
            S.ecg_buf.append(v)
            if S.fr_ecg:
                S.fr_ecg.write([epoch, i, v])


# ══════════════════════════════════════════════════════════════════════════════
#  [V3] VIGIL HANDSHAKE WebSocket Server
#  Puerto 8765: canal de datos biomédicos (legacy binario + VIGIL JSON)
#  Puerto 8766: canal de control VIGIL (dashboard del operador)
# ══════════════════════════════════════════════════════════════════════════════

async def vigil_data_server():
    """
    Servidor WebSocket de datos VIGIL (puerto 8765).
    Cada cliente debe enviar un Manifiesto de Intenciones como primer mensaje.
    El flujo de datos no se inicia hasta que el Operador aprueba.
    """
    if not WS_OK:
        print("⚠️  websockets no instalado. pip install websockets")
        return

    async def handler(ws):
        # Obtener IP del cliente
        try:
            client_ip = ws.remote_address[0] if ws.remote_address else "unknown"
        except Exception:
            client_ip = "unknown"

        client_id = uuid.uuid4().hex[:12]
        print(f"\n🔔 [VIGIL] Nueva conexión: {client_id} desde {client_ip}")

        # Esperar el Manifiesto de Intenciones (timeout 30s)
        try:
            raw_manifest = await asyncio.wait_for(ws.recv(), timeout=30.0)
            manifest = json.loads(raw_manifest)
            assert isinstance(manifest, dict), "Manifiesto inválido"
        except (asyncio.TimeoutError, json.JSONDecodeError, AssertionError) as e:
            print(f"  ❌ [VIGIL] {client_id}: Manifiesto inválido ({e}). Desconectando.")
            await ws.close()
            return

        # Registrar embajador
        amb = VIGIL.register(client_id, client_ip, manifest, ws)

        print(f"  📋 [VIGIL] Manifiesto de {client_id}:")
        print(f"     Nombre:     {manifest.get('name', '(sin nombre)')}")
        print(f"     Intención:  {manifest.get('intent', '(sin descripción)')}")
        print(f"     Nivel req:  {manifest.get('requested_level', 0)}")
        print(f"  → Esperando autorización del Operador (dashboard o consola)…")

        # Notificar al dashboard VIGIL
        if VIGIL.ui_events:
            VIGIL.ui_events.put_nowait({
                "event":     "NEW_CONNECTION",
                "client_id": client_id,
                "data":      amb.to_dict(),
            })

        # Encolar solicitud para el TUI si está en modo consola
        if VIGIL.pending_queue:
            await VIGIL.pending_queue.put(amb)

        # Enviar challenge al cliente
        challenge = {
            "type":      "VIGIL_CHALLENGE",
            "client_id": client_id,
            "status":    "PENDING_APPROVAL",
            "message":   "Esperando autorización del Operador.",
        }
        await ws.send(json.dumps(challenge))

        # Esperar aprobación (poll cada 0.5s, timeout 120s)
        approved = False
        for _ in range(240):
            await asyncio.sleep(0.5)
            if amb.status == AmbassadorStatus.KILLED:
                await ws.send(json.dumps({"type": "VIGIL_KILLED", "reason": "Kill-switch activado."}))
                await ws.close()
                VIGIL.remove(client_id)
                return
            if amb.status == AmbassadorStatus.REJECTED:
                await ws.send(json.dumps({"type": "VIGIL_REJECTED", "reason": "Acceso denegado."}))
                await ws.close()
                VIGIL.remove(client_id)
                return
            if amb.status in (AmbassadorStatus.APPROVED, AmbassadorStatus.POISONED):
                approved = True
                break

        if not approved:
            await ws.send(json.dumps({"type": "VIGIL_TIMEOUT", "reason": "Tiempo de espera agotado."}))
            await ws.close()
            VIGIL.remove(client_id)
            return

        # Notificar al cliente que fue aprobado/envenenado
        result_msg = {
            "type":       "VIGIL_AUTHORIZED",
            "client_id":  client_id,
            "level":      amb.level,
            "level_name": POLICY_NAMES.get(amb.level, "?"),
            "poisoned":   amb.status == AmbassadorStatus.POISONED,
            "token_hash": hashlib.sha256(amb.token).hexdigest()[:8],  # fingerprint público
        }
        await ws.send(json.dumps(result_msg))

        print(f"  ✅ [VIGIL] {client_id} autorizado — {POLICY_NAMES.get(amb.level, '?')}")

        # Bucle de envío de datos
        try:
            while True:
                # Comprobar kill-switch
                if amb.status == AmbassadorStatus.KILLED:
                    break
                await asyncio.sleep(0.0)  # yield para no bloquear

                # Draining the VIGIL queue for this client
                while not S.vigil_queue.empty():
                    try:
                        cid, msg = S.vigil_queue.get_nowait()
                        if cid == client_id:
                            await ws.send(msg)
                    except asyncio.QueueEmpty:
                        break

                await asyncio.sleep(0.05)

        except Exception:
            pass
        finally:
            VIGIL.remove(client_id)
            print(f"  🔌 [VIGIL] {client_id} desconectado")

    import websockets as _ws
    async with _ws.serve(handler, "127.0.0.1", 8765):
        print("🌐 VIGIL Data Bridge  → ws://127.0.0.1:8765  [VIGIL Handshake · ZKO]")
        while True:
            await asyncio.sleep(3600)


async def vigil_control_server():
    """
    Servidor WebSocket de control VIGIL (puerto 8766).
    El dashboard del operador se conecta aquí para:
    - Recibir el estado de todos los embajadores en tiempo real.
    - Aprobar/rechazar/envenenar/matar embajadores.
    - Recibir notificaciones de nuevas conexiones.
    """
    if not WS_OK:
        return

    control_clients: set = set()

    async def control_handler(ws):
        control_clients.add(ws)
        print(f"🎛️  [VIGIL] Dashboard operador conectado")

        # Enviar estado inicial
        try:
            init_msg = json.dumps({
                "type":        "VIGIL_INIT",
                "ambassadors": [a.to_dict() for a in VIGIL.all()],
                "policy_key":  hashlib.sha256(_SESSION_MASTER_KEY).hexdigest()[:16],
            })
            await ws.send(init_msg)

            # Leer comandos entrantes del dashboard
            async def receive_commands():
                async for raw in ws:
                    try:
                        cmd = json.loads(raw)
                        action    = cmd.get("action")
                        client_id = cmd.get("client_id", "")
                        level     = int(cmd.get("level", 0))

                        if action == "APPROVE":
                            ok = VIGIL.approve(client_id, level)
                            print(f"  ✅ [VIGIL] Operador aprobó {client_id} → {POLICY_NAMES.get(level,'?')}")
                        elif action == "REJECT":
                            ok = VIGIL.reject(client_id)
                            print(f"  🚫 [VIGIL] Operador rechazó {client_id}")
                        elif action == "POISON":
                            ok = VIGIL.poison(client_id)
                            print(f"  ☠️  [VIGIL] Operador envenenó {client_id}")
                        elif action == "KILL":
                            ok = VIGIL.kill(client_id)
                            print(f"  💀 [VIGIL] Operador mató {client_id}")
                    except Exception as ex:
                        print(f"  ⚠️  [VIGIL] Comando inválido: {ex}")

            # Broadcast de eventos VIGIL al dashboard
            async def broadcast_events():
                while True:
                    try:
                        event = await asyncio.wait_for(VIGIL.ui_events.get(), timeout=1.0)
                        if not ws.closed:
                            await ws.send(json.dumps(event))
                    except asyncio.TimeoutError:
                        # Enviar heartbeat cada segundo
                        if not ws.closed:
                            hb = json.dumps({
                                "type":        "HEARTBEAT",
                                "ambassadors": [a.to_dict() for a in VIGIL.all()],
                                "pending":     len(VIGIL.pending_approval()),
                                "active":      VIGIL.active_count(),
                                "session_s":   round(S.elapsed()),
                                "bpm":         S.bpm,
                                "attest":      S.attest_active,
                            })
                            await ws.send(hb)
                    except Exception:
                        break

            await asyncio.gather(receive_commands(), broadcast_events())

        except Exception:
            pass
        finally:
            control_clients.discard(ws)
            print(f"🎛️  [VIGIL] Dashboard operador desconectado")

    import websockets as _ws
    async with _ws.serve(control_handler, "127.0.0.1", 8766):
        print("🎛️  VIGIL Control Panel → ws://127.0.0.1:8766  [Operador Dashboard]")
        while True:
            await asyncio.sleep(3600)


# ══════════════════════════════════════════════════════════════════════════════
#  CONSOLA DE AUTORIZACIÓN TUI (modo no-web)
#  Muestra solicitudes pendientes y permite al operador aprobar/rechazar.
# ══════════════════════════════════════════════════════════════════════════════

async def vigil_console_approver():
    """
    En modo TUI sin dashboard, el operador puede aprobar/rechazar embajadores
    desde la consola de forma interactiva.
    """
    loop = asyncio.get_event_loop()
    print("\n🔐 [VIGIL] Consola de autorización activa.")
    print("   Formato: APPROVE <id> <nivel>  |  REJECT <id>  |  POISON <id>  |  KILL <id>\n")

    def read_input():
        while True:
            # Mostrar solicitudes pendientes
            pending = VIGIL.pending_approval()
            if pending:
                print(f"\n⚠️  [{len(pending)} solicitud(es) pendiente(s)]")
                for amb in pending:
                    print(f"   ID: {amb.client_id}")
                    print(f"   Nombre:    {amb.manifest.get('name','?')}")
                    print(f"   Intención: {amb.manifest.get('intent','?')}")
                    print(f"   Nivel req: {amb.manifest.get('requested_level',0)}")
                    raw = input("   Comando > ").strip().split()
                    if not raw:
                        continue
                    action = raw[0].upper()
                    cid = raw[1] if len(raw) > 1 else amb.client_id
                    if action == "APPROVE":
                        lvl = int(raw[2]) if len(raw) > 2 else 0
                        VIGIL.approve(cid, lvl)
                    elif action == "REJECT":
                        VIGIL.reject(cid)
                    elif action == "POISON":
                        VIGIL.poison(cid)
                    elif action == "KILL":
                        VIGIL.kill(cid)
            else:
                time.sleep(2.0)

    await loop.run_in_executor(None, read_input)


# ══════════════════════════════════════════════════════════════════════════════
#  TUI — curses dashboard (original v0.1 + indicador VIGIL)
# ══════════════════════════════════════════════════════════════════════════════

def tui_render(stdscr):
    curses.curs_set(0)
    stdscr.nodelay(True)
    curses.start_color()
    curses.use_default_colors()
    curses.init_pair(1, curses.COLOR_GREEN,   -1)
    curses.init_pair(2, curses.COLOR_CYAN,    -1)
    curses.init_pair(3, curses.COLOR_RED,     -1)
    curses.init_pair(4, curses.COLOR_YELLOW,  -1)
    curses.init_pair(5, curses.COLOR_WHITE,   -1)
    curses.init_pair(6, curses.COLOR_MAGENTA, -1)

    GRAPH_W = 60
    GRAPH_H = 8

    while True:
        try:
            key = stdscr.getch()
            if key == ord('q'):
                break

            stdscr.erase()
            h, w = stdscr.getmaxyx()
            row  = 0

            def put(r, c, text, attr=0):
                try:
                    stdscr.addstr(r, c, text, attr)
                except curses.error:
                    pass

            put(row, 0, "─" * min(w-1, 70), curses.color_pair(2)); row += 1
            put(row, 2, "  PULSE SKELETON v0.2  //  RONIN-1310  ·  PROTOCOLO VIGIL  ",
                curses.color_pair(2) | curses.A_BOLD); row += 1
            put(row, 0, "─" * min(w-1, 70), curses.color_pair(2)); row += 2

            put(row, 2, "HEART RATE   ", curses.color_pair(5))
            put(row, 15, f"{S.bpm:>4} BPM", curses.color_pair(1) | curses.A_BOLD); row += 1

            rr_str = "  ".join(f"{r}ms" for r in S.last_rr) if S.last_rr else "—"
            put(row, 2, "R-R INTV     ", curses.color_pair(5))
            put(row, 15, rr_str, curses.color_pair(4)); row += 1

            rmssd_s = f"{S.rmssd:.1f} ms" if S.rmssd else "computing…"
            put(row, 2, "RMSSD        ", curses.color_pair(5))
            put(row, 15, rmssd_s, curses.color_pair(4)); row += 1

            sdnn_s = f"{S.sdnn:.1f} ms" if S.sdnn else "computing…"
            put(row, 2, "SDNN(2min)   ", curses.color_pair(5))
            put(row, 15, sdnn_s, curses.color_pair(4)); row += 1

            dfa_s = f"{S.dfa_alpha1:.3f}" if S.dfa_alpha1 else "computing…"
            put(row, 2, "DFA-α1       ", curses.color_pair(5))
            put(row, 15, dfa_s, curses.color_pair(4)); row += 2

            dp_hist = list(S.delta_p_hist)
            dp_now  = dp_hist[-1] if dp_hist else 0.0
            BAR_W   = 30
            filled  = int(dp_now / 100 * BAR_W)
            bar     = "█" * filled + "░" * (BAR_W - filled)
            dp_col  = curses.color_pair(1) if dp_now >= 50 else curses.color_pair(3)
            put(row, 2, "δ(P)         ", curses.color_pair(5))
            put(row, 15, f"{dp_now:5.1f}  [{bar}]", dp_col); row += 1

            ect_c = curses.color_pair(3) if S.ectopic_count else curses.color_pair(5)
            att_c = curses.color_pair(1) if S.attest_active  else curses.color_pair(5)
            put(row, 2, f"ectopics:{S.ectopic_count}", ect_c)
            att_s = "ATTEST:LIFE ✓" if S.attest_active else f"streak:{S.sav_streak}s"
            put(row, 22, att_s, att_c | curses.A_BOLD); row += 2

            # ─── VIGIL STATUS ───────────────────────────────────────────────
            put(row, 2, "─" * min(w-4, 66), curses.color_pair(6)); row += 1
            put(row, 2, "  PROTOCOLO VIGIL — EMBAJADORES", curses.color_pair(6) | curses.A_BOLD); row += 1
            ambassadors = VIGIL.all()
            pending_n   = len(VIGIL.pending_approval())
            if pending_n:
                put(row, 2, f"⚠  {pending_n} solicitud(es) PENDIENTE(S) — ver dashboard",
                    curses.color_pair(3) | curses.A_BOLD); row += 1
            if not ambassadors:
                put(row, 2, "  (sin embajadores conectados)", curses.color_pair(5) | curses.A_DIM); row += 1
            else:
                for amb in ambassadors[:5]:
                    status_c = {
                        AmbassadorStatus.PENDING:  curses.color_pair(4),
                        AmbassadorStatus.APPROVED: curses.color_pair(1),
                        AmbassadorStatus.REJECTED: curses.color_pair(3),
                        AmbassadorStatus.POISONED: curses.color_pair(6),
                        AmbassadorStatus.KILLED:   curses.color_pair(3),
                    }.get(amb.status, curses.color_pair(5))
                    name = amb.manifest.get("name", amb.client_id[:8])
                    put(row, 2,
                        f"  [{amb.status[:3]}] {name[:16]:<16} "
                        f"Lv{amb.level} · {amb.packets_sent} pkts",
                        status_c); row += 1

            put(row, 2, "─" * min(w-4, 66), curses.color_pair(6)); row += 1

            dp_hist2 = list(S.delta_p_hist)
            if len(dp_hist2) >= 2:
                mn, mx  = min(dp_hist2), max(dp_hist2)
                span    = max(mx - mn, 1.0)
                window  = dp_hist2[-GRAPH_W:] if len(dp_hist2) >= GRAPH_W else dp_hist2
                cols    = [int((v - mn) / span * (GRAPH_H - 1)) for v in window]
                for gh in range(GRAPH_H - 1, -1, -1):
                    line = ""
                    for col_h in cols:
                        if col_h > gh:    line += "█"
                        elif col_h == gh: line += "▄"
                        else:             line += " "
                    put(row, 2, f"{mn + gh * span / (GRAPH_H-1):4.0f} │", curses.color_pair(5))
                    put(row, 9, line, curses.color_pair(1) | curses.A_DIM); row += 1
                put(row, 9, "─" * min(len(window), GRAPH_W), curses.color_pair(5)); row += 1
            else:
                row += GRAPH_H + 1

            row += 1
            contact = "✓ CONTACT" if S.contact_ok else "✗ NO CONTACT"
            c_col   = curses.color_pair(1) if S.contact_ok else curses.color_pair(3)
            put(row, 2, "ELECTRODE  ",  curses.color_pair(5))
            put(row, 13, contact, c_col | curses.A_BOLD); row += 1

            put(row, 2,
                f"BLE jitter:{S.cache.jitter_ms:.1f}ms  RSSI:{S.rssi}dBm  MTU:{S.mtu}B",
                curses.color_pair(5) | curses.A_DIM); row += 1

            drop_p = 100 * S.packets_drop / max(1, S.packets_rx)
            put(row, 2,
                f"PACKETS   rx:{S.packets_rx:<6} drop:{S.packets_drop:<4} ({drop_p:.1f}% SAV)",
                curses.color_pair(5) | curses.A_DIM); row += 1
            put(row, 2,
                f"SESSION   {S.elapsed():>7.1f}s  gaps:{S.gap_events}  {S.device_name}",
                curses.color_pair(5) | curses.A_DIM); row += 1
            put(row+1, 2, "[ q ] salir", curses.color_pair(5) | curses.A_DIM)

            stdscr.refresh()
            time.sleep(0.05)

        except KeyboardInterrupt:
            break


# ══════════════════════════════════════════════════════════════════════════════
#  FALLBACK ASCII DASHBOARD
# ══════════════════════════════════════════════════════════════════════════════

def ascii_render():
    dp_hist = list(S.delta_p_hist)
    dp_now  = dp_hist[-1] if dp_hist else 0.0
    BAR_W   = 30
    filled  = int(dp_now / 100 * BAR_W)
    bar     = "█" * filled + "░" * (BAR_W - filled)
    SPARK   = "▁▂▃▄▅▆▇█"
    mn      = min(dp_hist[-30:], default=0)
    mx      = max(dp_hist[-30:], default=100)
    span    = max(mx - mn, 1)
    spark   = "".join(SPARK[int((v - mn) / span * 7)] for v in dp_hist[-30:])
    drop_p  = 100 * S.packets_drop / max(1, S.packets_rx)
    sys.stdout.write("\033[2J\033[H")
    print("──────────────────────────────────────────────────────")
    print("  PULSE SKELETON v0.2  //  PROTOCOLO VIGIL")
    print("──────────────────────────────────────────────────────")
    print(f"  HR        : {S.bpm:>4} BPM")
    rr_s = "  ".join(f"{r}ms" for r in S.last_rr) if S.last_rr else "—"
    print(f"  R-R       : {rr_s}")
    print(f"  RMSSD     : {f'{S.rmssd:.1f} ms' if S.rmssd else 'computing...'}")
    print(f"  SDNN(2min): {f'{S.sdnn:.1f} ms' if S.sdnn else 'computing...'}")
    print(f"  DFA-α1    : {f'{S.dfa_alpha1:.3f}' if S.dfa_alpha1 else 'computing...'}")
    print(f"  δ(P)      : {dp_now:5.1f}  [{bar}]")
    print(f"  trend     : {spark}")
    print(f"  Electrode : {'✓ CONTACT' if S.contact_ok else '✗ NO CONTACT'}")
    print(f"  Ectopics  : {S.ectopic_count}  | Attest: {'LIFE ✓' if S.attest_active else f'streak {S.sav_streak}s'}")
    print("──────────────── VIGIL ──────────────────────────────")
    ambassadors = VIGIL.all()
    if ambassadors:
        for amb in ambassadors:
            print(f"  [{amb.status:8s}] {amb.manifest.get('name', amb.client_id[:8]):<16} "
                  f"Lv{amb.level} · {amb.packets_sent} pkts")
    else:
        print("  (sin embajadores conectados)")
    print("──────────────────────────────────────────────────────")
    print(f"  Packets   : rx={S.packets_rx}  drop={S.packets_drop} ({drop_p:.1f}%)")
    print(f"  Session   : {S.elapsed():.1f}s  {S.device_name}")
    print("──────────────────────────────────────────────────────")
    sys.stdout.flush()


# ══════════════════════════════════════════════════════════════════════════════
#  BLE CORE
# ══════════════════════════════════════════════════════════════════════════════

async def ble_run(mode: str):
    VIGIL.init_queues()

    print("🔍 Buscando Polar H10…")
    devices = await BleakScanner.discover(timeout=10.0)
    device  = next((d for d in devices
                    if d.name and d.name.startswith("Polar H10")), None)

    if not device:
        print("❌ No se encontró Polar H10. ¿Está encendido y puesto?")
        return

    S.device_name = device.name
    print(f"✅ Encontrado: {device.name}  [{device.address}]")
    S.open_recorders()

    async with BleakClient(device.address) as client:
        print("🔗 Conectado")

        try:
            S.rssi = await client.get_rssi()
        except Exception:
            pass

        try:
            S.mtu = client.mtu_size
        except Exception:
            S.mtu = 244

        S.set_link_metadata()

        await client.start_notify(HR_MEASUREMENT_UUID, hr_handler)
        print("📡 Stream HR activo (0x2A37)")

        try:
            await client.write_gatt_char(PMD_CONTROL_UUID, ECG_START_CMD, response=True)
            await client.start_notify(PMD_DATA_UUID, ecg_handler)
            S.ecg_mode = True
            print("🧠 Stream ECG PMD activo (130 Hz)")
        except Exception as ex:
            print(f"⚠️  ECG no disponible ({ex}) — modo HR únicamente")

        stop_event = asyncio.Event()
        signal.signal(signal.SIGINT,  lambda *_: stop_event.set())
        signal.signal(signal.SIGTERM, lambda *_: stop_event.set())

        if mode == "web":
            while not stop_event.is_set():
                await asyncio.sleep(0.05)
        elif mode == "tui" and CURSES_OK:
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, lambda: curses.wrapper(tui_render))
        else:
            while not stop_event.is_set():
                ascii_render()
                await asyncio.sleep(0.25)

        print("\n🛑 Deteniendo streams…")
        await client.stop_notify(HR_MEASUREMENT_UUID)
        if S.ecg_mode:
            try:
                await client.write_gatt_char(PMD_CONTROL_UUID, ECG_STOP_CMD, response=True)
                await client.stop_notify(PMD_DATA_UUID)
            except Exception:
                pass

    S.close_recorders()
    print(f"\n💾 Sesión guardada ({S.elapsed():.1f}s)")
    drop_p = 100 * S.packets_drop / max(1, S.packets_rx)
    print(f"   SAV filtró {S.packets_drop} paquetes ({drop_p:.1f}%)")
    print(f"   Embajadores atendidos: {len(VIGIL.all())}")


# ══════════════════════════════════════════════════════════════════════════════
#  ENTRY POINT
# ══════════════════════════════════════════════════════════════════════════════

async def main():
    parser = argparse.ArgumentParser(
        description="Pulse Skeleton v0.2 — RONIN-1310 · Protocolo VIGIL")
    parser.add_argument("--web",   action="store_true",
                        help="Iniciar servidor WebSocket VIGIL (abrir pulse_skeleton_ui.html)")
    parser.add_argument("--ascii", action="store_true",
                        help="Forzar dashboard ASCII (sin curses)")
    args = parser.parse_args()

    mode = "web" if args.web else ("ascii" if args.ascii else "tui")

    print("""
╔═══════════════════════════════════════════════════════════════════════╗
║       PULSE SKELETON v0.2  ·  PROTOCOLO VIGIL  ·  RONIN-1310         ║
╠═══════════════════════════════════════════════════════════════════════╣
║  Sovereign Policy Key (fingerprint local):                            ║""")
    fp = hashlib.sha256(_SESSION_MASTER_KEY).hexdigest()[:32]
    print(f"║  {fp}                  ║")
    print("""╠═══════════════════════════════════════════════════════════════╣
║  "No pido permiso para entrar en su red;                      ║
║   les permito asomarse a mi ventana bajo mis condiciones."    ║
╚═══════════════════════════════════════════════════════════════╝
""")

    if mode == "web":
        await asyncio.gather(
            ble_run("web"),
            vigil_data_server(),
            vigil_control_server(),
        )
    else:
        await asyncio.gather(
            ble_run(mode),
            vigil_console_approver(),
        )


if __name__ == "__main__":
    asyncio.run(main())
