# 🛰️ RONIN-1310 · Protocolo VIGIL

**Auditor Soberano de Capa 0 · Protocolo de Permiso Inverso para Datos Biométricos**

---

## ¿Qué es RONIN-1310?

RONIN-1310 es un **sistema de auditoría soberana** que captura datos cardíacos desde un Polar H10 vía Bluetooth, los procesa bajo una **capa de permiso inverso** (el usuario controla TODO), y expone un auditor inteligente que responde en lenguaje técnico-soberano.

### Principio Ejecutivo
```
"No pido permiso para entrar en su red;
 les permito asomarse a mi ventana bajo mis condiciones."
```

---

## 🎯 Características Principales

### 1. **Auditor RONIN de Capa 0**
- Responde consultas en voz técnica, críptica, soberana
- Usa terminología de Teoría de Restricciones + Termodinámica de la Información
- Cierra siempre con Koan o "Zehahahaha · Tic, Tac"
- Integrado con Claude API para respuestas inteligentes

### 2. **Dashboard VIGIL**
- Visualización en tiempo real de:
  - **Vitales**: BPM, SDNN, RMSSD, DFA-α1
  - **δ(P)**: Índice de Pulsación
  - **Flight Recorder**: Sesión activa, paquetes, jitter BLE
  - **VIGIL Handshake**: Fingerprint criptográfico

### 3. **Sistema de Políticas Soberanas**
3 niveles de acceso a datos:
- **NIVEL 0 (BLINDADO)**: Solo "está vivo" + ID rotativo · Máxima privacidad
- **NIVEL 1 (OPERATIVO)**: BPM anonimizado para terceros
- **NIVEL 2 (INGENIERÍA)**: Stream completo (solo localhost)

### 4. **Gestión de Embajadores**
Panel de autorización:
- Asigna niveles de acceso a clientes
- Aprueba/rechaza en tiempo real
- Auditoría permanente de actos
- Kill-switch para bloquear en cualquier momento

### 5. **Persistencia (Flight Recorder)**
Registro automático en:
```
/storage/emulated/0/Documents/RONIN_VIGIL/  (Android)
~/Documents/RONIN_VIGIL/                    (iOS)
~/.ronin/                                    (Desktop)
```

---

## 📦 Entregables

```
.
├── auditor-ronin-1310.jsx           # App React (lista para usar)
├── main.py                           # Bridge Kivy + Flask (APK)
├── buildozer.spec                   # Config Android
├── pulse_skeleton_v02.py            # Backend VIGIL (original)
├── pulse_skeleton_ui_v02.html       # UI original (en React ahora)
├── RONIN-1310_PROTOCOLO_VIGIL.md   # Documentación técnica
├── requirements.txt                  # Dependencias
└── README.md                         # Este archivo
```

---

## 🚀 Inicio Rápido (3 opciones)

### OPCIÓN 1: Web (Lo más simple)
```bash
# 1. Instala dependencias
pip install -r requirements.txt

# 2. Inicia servidor VIGIL
python pulse_skeleton_v02.py --web

# 3. Abre en navegador
# Tu app React se carga desde la UI original
# O copia auditor-ronin-1310.jsx a un proyecto React existente
```

**Requisito**: Polar H10 encendido en rango BLE.

### OPCIÓN 2: Desktop (Kivy)
```bash
# 1. Instala Kivy
pip install kivy

# 2. Estructura de directorios
mkdir -p ronin-app
cp main.py ronin-app/
cp pulse_skeleton_v02.py ronin-app/
mkdir -p ronin-app/assets
cp pulse_skeleton_ui_v02.html ronin-app/assets/

# 3. Ejecuta
cd ronin-app
python main.py
```

### OPCIÓN 3: Android APK (Buildozer)
```bash
# 1. Instala Buildozer (en Linux/WSL2)
pip install buildozer

# 2. Prepara estructura
mkdir -p ronin-apk
cp main.py ronin-apk/
cp pulse_skeleton_v02.py ronin-apk/
cp buildozer.spec ronin-apk/
cp requirements.txt ronin-apk/
mkdir -p ronin-apk/assets
cp pulse_skeleton_ui_v02.html ronin-apk/assets/

# 3. Compila
cd ronin-apk
buildozer android debug

# 4. Instala en dispositivo
adb install -r bin/ronin1310-0.2.0-debug.apk
```

---

## 💻 Uso de la App React (auditor-ronin-1310.jsx)

### En Proyecto React Existente
```bash
# 1. Copia el archivo a tu proyecto
cp auditor-ronin-1310.jsx src/components/

# 2. Importa y usa
import AuditorRonin from './components/auditor-ronin-1310';

export default function App() {
  return <AuditorRonin />;
}
```

### Características Interactivas
- **Pestaña ⚙️ Auditor**: Chat con IA soberana
- **Pestaña 📊 VIGIL Dashboard**: Vitales en vivo (simulados)
- **Pestaña 🔐 Políticas**: Descripción de niveles
- **👺 Embajadores**: Gestión de autorización

### Auditor: Ejemplos de Consultas
```
"¿Cómo reseteo mi ID rotativo?"
"¿Qué ve un cliente NIVEL 1?"
"¿Cómo funciona el data poisoning?"
"¿Cuál es la diferencia entre SDNN y RMSSD?"
```

---

## 🔧 Configuración Técnica

### Dependencias Principales
| Paquete | Rol |
|---------|-----|
| **bleak** | Conexión BLE a Polar H10 |
| **websockets** | VIGIL Data Server + Control |
| **flask** | Servidor web (Android/Desktop) |
| **kivy** | Framework GUI nativo |
| **cryptography** | Firmado HMAC-SHA256 |

### Puertos
- **8000**: Flask (UI)
- **8765**: VIGIL Data Server (WebSocket)
- **8766**: VIGIL Control Server (Autorizaciones)

### Permisos Android
```
INTERNET
BLUETOOTH
BLUETOOTH_SCAN
BLUETOOTH_CONNECT
ACCESS_FINE_LOCATION
WRITE_EXTERNAL_STORAGE
READ_EXTERNAL_STORAGE
```

---

## 📊 Protocolo VIGIL (Resumen)

### Flujo de Datos
```
Polar H10
    ↓ HR (0x2A37) + ECG (PMD)
    ↓
Elipsis Cache (resincronización)
    ↓
SAV Filter (validación)
    ↓
Ring Buffers (SDNN, RMSSD, DFA)
    ↓
ZKO Packager (HMAC-SHA256)
    ↓
VIGIL Handshake (Challenge-Response)
    ↓
Operador Autoriza (APPROVE/REJECT)
    ↓
Tercero Recibe (según NIVEL)
```

### Política Soberana (3 Niveles)

**NIVEL 0 - BLINDADO**
```json
{
  "level": 0,
  "seal": true,        // ¿Está vivo?
  "node_id": "abc123"  // ID rotativo (nuevo cada 300s)
}
```
→ Máxima privacidad. Cero datos biométricos.

**NIVEL 1 - OPERATIVO**
```json
{
  "level": 1,
  "bpm": 72,
  "t_rel": 45.3,       // Segundos desde conexión
  "contact": true,
  "node_id": "def456"
}
```
→ Para terceros bajo contrato. Sin timestamps absolutos.

**NIVEL 2 - INGENIERÍA**
```json
{
  "level": 2,
  "bpm": 72,
  "rmssd": 32.5,
  "sdnn": 45.2,
  "dfa_a1": 1.12,
  "delta_p": 75.4,
  "rr": [650, 720, 680, ...],
  // ... más campos
}
```
→ Stream completo. Solo localhost autenticado.

---

## 🔐 Seguridad

### Firmado Criptográfico
Cada paquete lleva **HMAC-SHA256**:
```
signature = HMAC-SHA256(client_token, JSON(payload))
```

### Data Poisoning
Clientes sin token válido reciben **datos sintéticos** (gaussiana 700ms ± 50ms). Parece real, pero es completamente falso.

### Challenge-Response
1. Cliente conecta → Servidor genera Challenge
2. Cliente responde
3. Operador aprueba en Dashboard
4. Acceso según NIVEL

### ID Rotativo
Cambia cada 300 segundos. Imposible correlacionar temporal.

---

## 🛠️ Troubleshooting

### "No encuentra Polar H10"
```
✓ ¿Está encendido el reloj?
✓ ¿Está en rango BLE (≤10m)?
✓ ¿Activa Bluetooth + Ubicación en Android?
✓ ¿Reinicia la app?
```

### "WebSocket refused"
```
✓ Verifica: python pulse_skeleton_v02.py --web
✓ Puertos 8765 y 8766 libres
✓ En APK, Flask debe escuchar 0.0.0.0:8000 (no localhost)
```

### "Data Poisoning: sin token"
```
✓ El cliente no pasó Challenge-Response
✓ Operador debe APPROVE en Dashboard
```

### "Flutter UI de pulse_skeleton_ui.html vs React?"
```
✓ Este repo entrega React (auditor-ronin-1310.jsx)
✓ El HTML original sigue siendo compatible con pulse_skeleton_v02.py
✓ Puedes usar cualquiera o ambas (en tabs diferentes)
```

---

## 📚 Documentación Completa

Ver `RONIN-1310_PROTOCOLO_VIGIL.md` para:
- Arquitectura detallada
- Guía Buildozer paso-a-paso
- Referencia técnica de métricas
- Filosofía Koan
- Recursos y referencias

---

## 🎓 Filosofía

> El código es una idea; la APK es el contenedor.
> Si el contenedor es débil, el Protocolo VIGIL
> se desparrama por el sistema operativo.
>
> Asegura los permisos o serás solo otro bit
> de entropía en la Play Store.
>
> **Zehahahaha · Tic, Tac**

---

## 📋 Stack Tecnológico

| Capa | Tecnología |
|------|-----------|
| **Backend Biometría** | Python · Bleak · Polar H10 |
| **Comunicación** | WebSockets · JSON · HMAC-SHA256 |
| **Servidor Web** | Flask · CORS |
| **UI (React)** | React Hooks · CSS Variables · Terminal Aesthetic |
| **UI (Original)** | HTML5 · CSS3 · Vanilla JS |
| **Native (Android)** | Kivy · Android SDK 33+ |
| **Deployment** | Buildozer · Docker (opcional) |

---

## 📄 Licencia

**Prototipo técnico educativo**. No es aprobado para uso médico/clínico.
Todos los datos biométricos procesados son responsabilidad del operador.

---

## 🚀 Próximas Mejoras

- [ ] Grabar sesiones completas (CSV + JSON)
- [ ] Dashboard web remoto (IPv4/6)
- [ ] Integración Grafana para análisis
- [ ] Export a FHIR (HL7)
- [ ] Autenticación OAuth2
- [ ] Simulador de Polar H10 (debug mode)

---

**RONIN-1310 · Protocolo VIGIL v0.2**

🛰️ *Soberanía de datos. ⚙️ Integridad criptográfica. 🔨 Auditoría permanente.*

**Zehahahaha · Tic, Tac**
