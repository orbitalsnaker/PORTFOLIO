import React, { useState, useRef, useEffect } from 'react';

const AuditorRonin = () => {
  const [activeTab, setActiveTab] = useState('auditor');
  const [queryInput, setQueryInput] = useState('');
  const [auditLog, setAuditLog] = useState([
    { 
      id: 0, 
      role: 'SYSTEM', 
      text: '🛰️ AUDITOR RONIN-1310 ONLINE · Capa 0 · Soberanía Activada',
      timestamp: '00:00:00'
    }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const [vitals, setVitals] = useState({ bpm: 72, sdnn: 45.2, rmssd: 32.5, dfa: 1.12 });
  const [dpValue, setDpValue] = useState(75.4);
  const [ambassadors, setAmbassadors] = useState([
    { id: 'AMB-001', name: 'LOCAL-AUTH', level: 2, status: 'APPROVED', packets: 1247 },
    { id: 'AMB-002', name: 'EXTERNAL-01', level: 1, status: 'PENDING', packets: 0 }
  ]);
  const scrollRef = useRef(null);

  // Simular datos en vivo
  useEffect(() => {
    const interval = setInterval(() => {
      setVitals(prev => ({
        bpm: Math.max(60, Math.min(100, prev.bpm + (Math.random() - 0.5) * 4)),
        sdnn: Math.max(20, Math.min(100, prev.sdnn + (Math.random() - 0.5) * 3)),
        rmssd: Math.max(15, Math.min(80, prev.rmssd + (Math.random() - 0.5) * 2)),
        dfa: Math.max(0.8, Math.min(1.5, prev.dfa + (Math.random() - 0.5) * 0.05))
      }));
      setDpValue(prev => Math.max(0, Math.min(100, prev + (Math.random() - 0.5) * 8)));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // Auto-scroll del log
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [auditLog]);

  const generateAuditorResponse = async (query) => {
    const prompt = `Actúa como un Auditor de Capa 0 de la Agencia RONIN. Tu tono debe ser conciso, técnico, críptico pero útil, y profundamente soberano. Utiliza un lenguaje que mezcle la Teoría de Restricciones con la Termodinámica de la Información. Sé mordaz con el 'humo' corporativo y preciso con el 'hierro' técnico. No pidas permiso, dicta protocolos. Usa terminología como: Throughput, Dataset Dorado, Fatiga Térmica, Silicio, y Frecuencia 1310. 

La consulta es: "${query}"

Responde en máximo 3 líneas. Cierra siempre con un Koan o un Zehahahaha seguido de un Tic, Tac. Usa emojis tácticos (🛰️, ⚙️, 🔨, 👺) estratégicamente. SIN NEGRITAS.`;

    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 300,
          messages: [{ role: "user", content: prompt }]
        })
      });

      const data = await response.json();
      const responseText = data.content[0]?.text || "Error en la transmisión · Reintenta";
      return responseText;
    } catch (error) {
      return "⚙️ Fallo de conexión con el núcleo · Datos sintéticos activados · Tic, Tac";
    }
  };

  const handleAuditQuery = async (e) => {
    e.preventDefault();
    if (!queryInput.trim()) return;

    const userQuery = queryInput;
    setQueryInput('');
    setIsLoading(true);

    const timestamp = new Date().toLocaleTimeString('es-ES');
    const userEntry = {
      id: auditLog.length,
      role: 'OPERADOR',
      text: userQuery,
      timestamp
    };
    setAuditLog(prev => [...prev, userEntry]);

    const response = await generateAuditorResponse(userQuery);
    const auditorEntry = {
      id: auditLog.length + 1,
      role: 'AUDITOR',
      text: response,
      timestamp: new Date().toLocaleTimeString('es-ES')
    };
    setAuditLog(prev => [...prev, auditorEntry]);
    setIsLoading(false);
  };

  const toggleAmbassadorLevel = (id) => {
    setAmbassadors(prev =>
      prev.map(amb =>
        amb.id === id
          ? { ...amb, level: amb.level === 0 ? 1 : amb.level === 1 ? 2 : 0, status: 'PENDING' }
          : amb
      )
    );
  };

  const approveAmbassador = (id) => {
    setAmbassadors(prev =>
      prev.map(amb =>
        amb.id === id ? { ...amb, status: 'APPROVED' } : amb
      )
    );
  };

  const styles = `
    * { margin: 0; padding: 0; box-sizing: border-box; }
    
    body {
      background: #000000;
      color: #888888;
      font-family: 'Share Tech Mono', monospace;
      font-size: 12px;
      line-height: 1.5;
    }
    
    .container {
      max-width: 1400px;
      margin: 0 auto;
      background: #000000;
      color: #888888;
      min-height: 100vh;
      display: grid;
      grid-template-rows: 50px 1fr 30px;
    }
    
    header {
      background: #060606;
      border-bottom: 1px solid #181818;
      display: flex;
      align-items: center;
      padding: 0 20px;
      justify-content: space-between;
      box-shadow: 0 2px 8px rgba(0,0,0,0.8);
    }
    
    .logo {
      color: #00e5a0;
      font-weight: 700;
      letter-spacing: 2px;
      font-size: 13px;
      text-transform: uppercase;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    
    .logo-badge {
      color: #b44fff;
      border: 1px solid #b44fff;
      padding: 2px 8px;
      font-size: 9px;
      letter-spacing: 1px;
    }
    
    .tabs {
      display: flex;
      gap: 0;
      margin-left: auto;
    }
    
    .tab {
      padding: 12px 20px;
      background: transparent;
      border: none;
      color: #666666;
      cursor: pointer;
      border-bottom: 2px solid transparent;
      font-family: inherit;
      font-size: 11px;
      letter-spacing: 1px;
      text-transform: uppercase;
      transition: all 0.3s;
    }
    
    .tab.active {
      color: #00e5a0;
      border-bottom-color: #00e5a0;
      box-shadow: 0 2px 8px rgba(0,229,160,0.1);
    }
    
    .tab:hover {
      color: #00aaff;
    }
    
    .main {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 0;
      padding: 20px;
    }
    
    .panel {
      background: #060606;
      border: 1px solid #181818;
      border-radius: 2px;
      display: flex;
      flex-direction: column;
      overflow: hidden;
    }
    
    .panel:nth-child(2) {
      margin-left: 20px;
    }
    
    .panel-header {
      background: #0c0c0c;
      border-bottom: 1px solid #202020;
      padding: 12px 16px;
      color: #00e5a0;
      font-weight: 700;
      font-size: 11px;
      letter-spacing: 1px;
      text-transform: uppercase;
    }
    
    .panel-content {
      flex: 1;
      overflow-y: auto;
      padding: 16px;
    }
    
    .audit-log {
      display: flex;
      flex-direction: column;
      gap: 8px;
      max-height: 500px;
      overflow-y: auto;
    }
    
    .audit-entry {
      border-left: 2px solid;
      padding-left: 10px;
      padding-top: 2px;
      padding-bottom: 2px;
      animation: fadeIn 0.3s ease-in;
      word-wrap: break-word;
      font-size: 11px;
      line-height: 1.4;
    }
    
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(-5px); }
      to { opacity: 1; transform: translateY(0); }
    }
    
    .audit-entry.SYSTEM {
      border-left-color: #00aaff;
      color: #00aaff;
    }
    
    .audit-entry.OPERADOR {
      border-left-color: #00e5a0;
      color: #00e5a0;
    }
    
    .audit-entry.AUDITOR {
      border-left-color: #b44fff;
      color: #b44fff;
    }
    
    .timestamp {
      color: #404040;
      font-size: 9px;
    }
    
    .input-area {
      display: flex;
      gap: 8px;
      padding-top: 12px;
      border-top: 1px solid #202020;
    }
    
    .input-area input {
      flex: 1;
      background: #0c0c0c;
      border: 1px solid #202020;
      color: #00e5a0;
      padding: 8px 12px;
      font-family: inherit;
      font-size: 11px;
    }
    
    .input-area button {
      background: transparent;
      border: 1px solid #00e5a0;
      color: #00e5a0;
      padding: 8px 16px;
      cursor: pointer;
      font-family: inherit;
      font-size: 11px;
      transition: all 0.2s;
      letter-spacing: 1px;
    }
    
    .input-area button:hover {
      background: rgba(0,229,160,0.1);
      box-shadow: 0 0 8px rgba(0,229,160,0.2);
    }
    
    .dashboard-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px;
    }
    
    .metric-card {
      background: #0c0c0c;
      border: 1px solid #202020;
      padding: 12px;
      border-radius: 2px;
      text-align: center;
    }
    
    .metric-label {
      color: #404040;
      font-size: 10px;
      text-transform: uppercase;
      letter-spacing: 1px;
      margin-bottom: 4px;
    }
    
    .metric-value {
      color: #00e5a0;
      font-size: 16px;
      font-weight: 700;
      font-family: 'Courier New', monospace;
    }
    
    .trend-indicator {
      color: #ff6b35;
      font-size: 10px;
      margin-top: 4px;
    }
    
    .progress-bar {
      background: #181818;
      height: 3px;
      border-radius: 2px;
      margin: 6px 0;
      overflow: hidden;
    }
    
    .progress-fill {
      background: linear-gradient(90deg, #00e5a0, #00aaff);
      height: 100%;
      animation: pulse 2s ease-in-out infinite;
    }
    
    @keyframes pulse {
      0%, 100% { opacity: 0.8; }
      50% { opacity: 1; }
    }
    
    .ambassador-list {
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
    
    .ambassador-item {
      background: #0c0c0c;
      border: 1px solid #202020;
      padding: 10px;
      border-radius: 2px;
      display: grid;
      grid-template-columns: 1fr auto auto;
      gap: 8px;
      align-items: center;
      font-size: 10px;
    }
    
    .ambassador-item.approved {
      border-left: 3px solid #00e5a0;
    }
    
    .ambassador-item.pending {
      border-left: 3px solid #ffaa00;
    }
    
    .ambi-info {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }
    
    .ambi-name {
      color: #00e5a0;
      font-weight: 700;
    }
    
    .ambi-meta {
      color: #404040;
    }
    
    .ambi-buttons {
      display: flex;
      gap: 4px;
    }
    
    .btn-small {
      background: transparent;
      border: 1px solid #404040;
      color: #888888;
      padding: 4px 8px;
      cursor: pointer;
      font-family: inherit;
      font-size: 9px;
      transition: all 0.2s;
    }
    
    .btn-small:hover {
      border-color: #00e5a0;
      color: #00e5a0;
    }
    
    .footer {
      background: #0c0c0c;
      border-top: 1px solid #181818;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 20px;
      font-size: 9px;
      color: #404040;
    }
    
    .divider {
      color: #202020;
      margin: 0 10px;
    }
    
    ::-webkit-scrollbar {
      width: 8px;
    }
    
    ::-webkit-scrollbar-track {
      background: #0c0c0c;
    }
    
    ::-webkit-scrollbar-thumb {
      background: #202020;
      border-radius: 2px;
    }
    
    ::-webkit-scrollbar-thumb:hover {
      background: #404040;
    }
  `;

  const getPolicyDescription = (level) => {
    const policies = {
      0: 'NIVEL 0 · BLINDADO — Solo Sello de Vividad + ID rotativo',
      1: 'NIVEL 1 · OPERATIVO — BPM anonimizado + timestamps relativos',
      2: 'NIVEL 2 · INGENIERÍA — Stream completo (solo local autenticado)'
    };
    return policies[level] || policies[0];
  };

  return (
    <div style={{ background: '#000000', minHeight: '100vh' }}>
      <style>{styles}</style>
      <div className="container">
        <header>
          <div className="logo">
            🛰️ RONIN-1310
            <span className="logo-badge">AUDITOR CAPA 0</span>
          </div>
          <div className="tabs">
            <button 
              className={`tab ${activeTab === 'auditor' ? 'active' : ''}`}
              onClick={() => setActiveTab('auditor')}
            >
              ⚙️ Auditor
            </button>
            <button 
              className={`tab ${activeTab === 'vigil' ? 'active' : ''}`}
              onClick={() => setActiveTab('vigil')}
            >
              📊 VIGIL Dashboard
            </button>
            <button 
              className={`tab ${activeTab === 'policy' ? 'active' : ''}`}
              onClick={() => setActiveTab('policy')}
            >
              🔐 Políticas Soberanas
            </button>
          </div>
        </header>

        <div className="main">
          {/* Panel Izquierdo */}
          {activeTab === 'auditor' && (
            <>
              <div className="panel">
                <div className="panel-header">⚙️ Auditor de Consultas</div>
                <div className="panel-content">
                  <div className="audit-log" ref={scrollRef}>
                    {auditLog.map(entry => (
                      <div key={entry.id} className={`audit-entry ${entry.role}`}>
                        <span className="timestamp">[{entry.timestamp}]</span>
                        <div style={{ marginTop: '2px' }}>
                          [{entry.role}] {entry.text}
                        </div>
                      </div>
                    ))}
                    {isLoading && (
                      <div className="audit-entry AUDITOR">
                        <span className="timestamp">[PROCESANDO]</span>
                        <div style={{ marginTop: '2px' }}>🔨 Forjando respuesta...</div>
                      </div>
                    )}
                  </div>
                  <div className="input-area">
                    <form onSubmit={handleAuditQuery} style={{ display: 'flex', gap: '8px', width: '100%' }}>
                      <input
                        type="text"
                        value={queryInput}
                        onChange={(e) => setQueryInput(e.target.value)}
                        placeholder="Consulta al Auditor…"
                        disabled={isLoading}
                      />
                      <button type="submit" disabled={isLoading}>
                        {isLoading ? '⏳' : '→'}
                      </button>
                    </form>
                  </div>
                </div>
              </div>

              <div className="panel">
                <div className="panel-header">👺 Sistema de Autorización</div>
                <div className="panel-content">
                  <div className="ambassador-list">
                    {ambassadors.map(amb => (
                      <div 
                        key={amb.id} 
                        className={`ambassador-item ${amb.status.toLowerCase()}`}
                      >
                        <div className="ambi-info">
                          <div className="ambi-name">{amb.name}</div>
                          <div className="ambi-meta">
                            {amb.id} • {getPolicyDescription(amb.level).split('·')[0]} • {amb.packets} pkts
                          </div>
                        </div>
                        <div style={{ textAlign: 'right' }}>
                          <div style={{ color: amb.status === 'APPROVED' ? '#00e5a0' : '#ffaa00', fontSize: '9px' }}>
                            {amb.status}
                          </div>
                        </div>
                        <div className="ambi-buttons">
                          <button 
                            className="btn-small"
                            onClick={() => toggleAmbassadorLevel(amb.id)}
                          >
                            LVL{amb.level}
                          </button>
                          {amb.status === 'PENDING' && (
                            <button 
                              className="btn-small"
                              onClick={() => approveAmbassador(amb.id)}
                            >
                              ✓
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </>
          )}

          {activeTab === 'vigil' && (
            <>
              <div className="panel">
                <div className="panel-header">📈 Vitales Biométricos</div>
                <div className="panel-content">
                  <div className="dashboard-grid">
                    <div className="metric-card">
                      <div className="metric-label">Frecuencia Cardíaca</div>
                      <div className="metric-value">{Math.round(vitals.bpm)}</div>
                      <div className="trend-indicator">BPM ⬆</div>
                      <div className="progress-bar">
                        <div className="progress-fill" style={{ width: `${(vitals.bpm / 120) * 100}%` }}></div>
                      </div>
                    </div>

                    <div className="metric-card">
                      <div className="metric-label">Variabilidad SDNN</div>
                      <div className="metric-value">{vitals.sdnn.toFixed(1)}</div>
                      <div className="trend-indicator">ms</div>
                      <div className="progress-bar">
                        <div className="progress-fill" style={{ width: `${(vitals.sdnn / 100) * 100}%` }}></div>
                      </div>
                    </div>

                    <div className="metric-card">
                      <div className="metric-label">RMSSD</div>
                      <div className="metric-value">{vitals.rmssd.toFixed(1)}</div>
                      <div className="trend-indicator">ms</div>
                      <div className="progress-bar">
                        <div className="progress-fill" style={{ width: `${(vitals.rmssd / 80) * 100}%` }}></div>
                      </div>
                    </div>

                    <div className="metric-card">
                      <div className="metric-label">DFA-α1</div>
                      <div className="metric-value">{vitals.dfa.toFixed(3)}</div>
                      <div className="trend-indicator">Fluc.</div>
                      <div className="progress-bar">
                        <div className="progress-fill" style={{ width: `${(vitals.dfa / 1.5) * 100}%` }}></div>
                      </div>
                    </div>
                  </div>
                  
                  <div style={{ marginTop: '16px', paddingTop: '12px', borderTop: '1px solid #202020' }}>
                    <div style={{ color: '#404040', fontSize: '10px', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: '8px' }}>
                      δ(P) - Índice de Pulsación
                    </div>
                    <div className="metric-value" style={{ fontSize: '24px', color: '#ff6b35' }}>
                      {dpValue.toFixed(1)}
                    </div>
                    <div className="progress-bar">
                      <div className="progress-fill" style={{ 
                        background: dpValue > 80 ? 'linear-gradient(90deg, #ff3366, #ff6b35)' : 'linear-gradient(90deg, #00e5a0, #00aaff)',
                        width: `${dpValue}%` 
                      }}></div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="panel">
                <div className="panel-header">🛰️ Flight Recorder</div>
                <div className="panel-content">
                  <div style={{ 
                    background: '#0c0c0c', 
                    padding: '12px', 
                    border: '1px solid #202020',
                    marginBottom: '12px',
                    fontSize: '10px',
                    lineHeight: '1.6'
                  }}>
                    <div style={{ color: '#00aaff' }}>▶ SESIÓN VIGIL ACTIVA</div>
                    <div style={{ color: '#666666', marginTop: '4px' }}>
                      Duración: 00:12:47<br/>
                      Paquetes RX: 2,847<br/>
                      Drop (SAV): 12 (0.42%)<br/>
                      Jitter BLE: 2.1ms<br/>
                      MTU: 244B · RSSI: -55dBm
                    </div>
                  </div>

                  <div style={{ 
                    background: '#0c0c0c', 
                    padding: '12px', 
                    border: '1px solid #202020',
                    fontSize: '10px',
                    lineHeight: '1.6'
                  }}>
                    <div style={{ color: '#b44fff' }}>🔐 VIGIL HANDSHAKE</div>
                    <div style={{ color: '#666666', marginTop: '4px' }}>
                      Master Key FP:<br/>
                      <span style={{ color: '#404040', fontSize: '8px', fontFamily: 'monospace' }}>
                        8f4c2d91e7a3b5c6d9...
                      </span>
                      <br/><br/>
                      ZKO Packages: 2,847<br/>
                      HMAC-SHA256: ✓ válido<br/>
                      Session TTL: 299s
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}

          {activeTab === 'policy' && (
            <>
              <div className="panel">
                <div className="panel-header">🔐 Política Soberana</div>
                <div className="panel-content">
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                    {[0, 1, 2].map(level => (
                      <div 
                        key={level}
                        style={{
                          background: '#0c0c0c',
                          border: `1px solid ${level === 0 ? '#b44fff' : level === 1 ? '#ff6b35' : '#00e5a0'}`,
                          padding: '12px',
                          borderRadius: '2px'
                        }}
                      >
                        <div style={{ 
                          color: level === 0 ? '#b44fff' : level === 1 ? '#ff6b35' : '#00e5a0',
                          fontSize: '11px',
                          fontWeight: '700',
                          marginBottom: '6px',
                          textTransform: 'uppercase',
                          letterSpacing: '1px'
                        }}>
                          {getPolicyDescription(level).split('·')[0]}
                        </div>
                        <div style={{ color: '#666666', fontSize: '10px', lineHeight: '1.5' }}>
                          {level === 0 && 'Solo Sello de Vividad (bool) + ID rotativo. Cero datos biométricos. Máxima privacidad.'}
                          {level === 1 && 'BPM anonimizado con timestamps relativos. Acceso operativo para terceros de confianza.'}
                          {level === 2 && 'Stream completo: R-R, RMSSD, SDNN, DFA-α1. Reservado exclusivamente para infraestructura local.'}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="panel">
                <div className="panel-header">📋 Manifiesto VIGIL</div>
                <div className="panel-content">
                  <div style={{ 
                    color: '#666666',
                    fontSize: '10px',
                    lineHeight: '1.8',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '10px'
                  }}>
                    <div>
                      <div style={{ color: '#00aaff', marginBottom: '4px' }}>━━ FILOSOFÍA ━━</div>
                      "No pido permiso para entrar en su red; les permito asomarse a mi ventana bajo mis condiciones."
                    </div>

                    <div>
                      <div style={{ color: '#00aaff', marginBottom: '4px' }}>━━ PRINCIPIOS ━━</div>
                      • Soberanía de datos: El operador controla cada bit<br/>
                      • Consentimiento explícito: No hay silencio = no hay acceso<br/>
                      • Auditoría permanente: Todos los actos quedan registrados<br/>
                      • Integridad criptográfica: HMAC-SHA256 en cada paquete
                    </div>

                    <div>
                      <div style={{ color: '#00aaff', marginBottom: '4px' }}>━━ KOAN FINAL ━━</div>
                      El código es una idea; la política es el contenedor. Si el contenedor es débil, la privacidad se desparrama. Asegura los permisos.
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>

        <footer className="footer">
          <div>🛰️ RONIN CENTRAL | FRECUENCIA 1310 | PROTOCOLO VIGIL v0.2</div>
          <span className="divider">│</span>
          <div>SESSION: {Math.random().toString(36).substr(2, 8).toUpperCase()} • STATUS: ONLINE</div>
          <span className="divider">│</span>
          <div>Tic, Tac</div>
        </footer>
      </div>
    </div>
  );
};

export default AuditorRonin;
