# 📑 RONIN-1310 · Índice Maestro

## 🗂️ Estructura del Proyecto

```
RONIN-1310/
├── 📘 DOCUMENTACIÓN
│   ├── README.md                          Guía principal de inicio
│   ├── RONIN-1310_PROTOCOLO_VIGIL.md     Especificación técnica completa
│   ├── INDEX.md                          Este archivo
│   └── quickstart.html                   Guía visual interactiva
│
├── 🚀 INSTALACIÓN
│   ├── setup.sh                          Script de setup automático
│   ├── requirements.txt                  Dependencias Python
│   └── buildozer.spec                   Configuración Android
│
├── 💻 CÓDIGO FUENTE
│   ├── pulse_skeleton_v02.py            Backend VIGIL (1,651 líneas)
│   │   └── Módulos: ELIPSIS CACHE, AUTONOMIC LOAD, FLIGHT RECORDER,
│   │             TACTICAL OVERLAY, SOVEREIGN BRIDGE
│   │
│   ├── main.py                          Bridge Kivy + Flask (366 líneas)
│   │   └── Integración Android: WebView, permiso BLE, persistencia
│   │
│   ├── auditor-ronin-1310.jsx           App React (850 líneas)
│   │   └── 3 pestañas: Auditor IA, Dashboard VIGIL, Políticas
│   │
│   ├── pulse_skeleton_ui_v02.html       UI original (920 líneas)
│   │   └── Dashboard HTML5 + CSS3 + JS vanilla
│   │
│   └── quickstart.html                  Guía visual (HTML5 interactivo)
│
└── 🔧 CONFIGURACIÓN
    └── buildozer.spec                   Android SDK 33+, Permisos BLE

═══════════════════════════════════════════════════════════════════
TOTAL: ~4,869 líneas de código + documentación completa
═══════════════════════════════════════════════════════════════════
```

---

## 📄 Guía Rápida por Archivo

### 📘 DOCUMENTACIÓN

| Archivo | Propósito | Audiencia |
|---------|----------|-----------|
| **README.md** | Overview, características, 3 opciones de instalación | Todos |
| **RONIN-1310_PROTOCOLO_VIGIL.md** | Arquitectura, protocolo, APK step-by-step | Técnicos |
| **quickstart.html** | Guía visual e interactiva (abre en navegador) | Todos |
| **INDEX.md** | Este archivo: tabla de contenidos | Navegación |

**📖 DÓNDE EMPEZAR**: 
- Primero: `quickstart.html` (visual)
- Segundo: `README.md` (técnico)
- Tercero: `RONIN-1310_PROTOCOLO_VIGIL.md` (profundo)

---

### 🚀 INSTALACIÓN

| Archivo | Propósito | Uso |
|---------|----------|-----|
| **setup.sh** | Setup automático (Linux/macOS/WSL2) | `bash setup.sh` |
| **requirements.txt** | Dependencias Python | `pip install -r requirements.txt` |
| **buildozer.spec** | Config Android buildozer | Para APK en Linux |

**⚡ INSTALACIÓN RÁPIDA**:
```bash
bash setup.sh  # Automático
# O manual:
pip install -r requirements.txt
```

---

### 💻 CÓDIGO FUENTE

#### 1. **pulse_skeleton_v02.py** (Backend VIGIL)
- **Líneas**: 1,651
- **Lenguaje**: Python 3.9+
- **Rol**: Core del sistema — captura BLE, procesa biometría, VIGIL protocol
- **Módulos principales**:
  - `ELIPSIS CACHE`: Resincronización de gaps
  - `AUTONOMIC LOAD`: Cálculo SDNN/RMSSD/DFA-α1
  - `FLIGHT RECORDER`: Persistencia async
  - `SOVEREIGN POLICY`: Niveles 0-2 de acceso
  - `ZKO PACKAGING`: Firmado HMAC-SHA256
  - `VIGIL HANDSHAKE`: Challenge-Response
  - `DATA POISONING`: Síntesis de datos falsos
- **Requisitos**: Bleak, WebSockets, Polar H10 (opcional)
- **Uso**: `python pulse_skeleton_v02.py --web`

#### 2. **auditor-ronin-1310.jsx** (App React)
- **Líneas**: ~850 (todo en un componente)
- **Lenguaje**: React 18 + Hooks
- **Rol**: UI moderna cyberpunk + Auditor IA integrado
- **Características**:
  - 3 pestañas: Auditor, Dashboard VIGIL, Políticas
  - Chat con Claude API en vivo
  - Simulación de vitales biométricos
  - Sistema de embajadores (autorización)
  - Tema industrial/cyberpunk
- **Requisitos**: React, API key Claude (env var)
- **Uso**: Copiar a proyecto React o usar en artifact editor

#### 3. **main.py** (Bridge Kivy)
- **Líneas**: ~366
- **Lenguaje**: Python 3.9+
- **Rol**: Integración Kivy + WebView para Desktop/Android
- **Características**:
  - Flask server en thread background
  - WebView local (si disponible)
  - Setup Flight Recorder (persistencia)
  - Integración opcional con pulse_skeleton_v02.py
  - Manejo de ciclo de vida Android
- **Requisitos**: Kivy, Flask, Flask-CORS
- **Uso**: `python main.py` (Desktop) o integrar con buildozer

#### 4. **pulse_skeleton_ui_v02.html** (UI Original)
- **Líneas**: ~920
- **Lenguaje**: HTML5 + CSS3 + Vanilla JS
- **Rol**: Dashboard original (compatible con pulse_skeleton_v02.py)
- **Características**:
  - Aesthetic cyberpunk industrial
  - Grid dinámico de embajadores
  - Panel de autorizaciones (VIGIL AUTH)
  - Flight Recorder viewer
  - Tema oscuro por defecto
- **Requisitos**: Navegador moderno, WebSocket
- **Uso**: Sirve automáticamente vía `python pulse_skeleton_v02.py --web`

#### 5. **quickstart.html** (Guía Visual)
- **Líneas**: ~350
- **Lenguaje**: HTML5 + CSS3
- **Rol**: Guía interactiva visual
- **Características**:
  - 3 opciones de instalación claras
  - Cards interactivas
  - Feature list
  - Filosofía Koan
- **Uso**: Abrir en navegador (`open quickstart.html`)

---

## 🎯 3 VÍAS DE USAR EL PROYECTO

### VÍA 1: WEB (Más fácil)
```bash
pip install -r requirements.txt
python pulse_skeleton_v02.py --web
# Abre http://localhost:8765
```
**Tiempo**: 5 minutos
**Requisito**: Python 3.9+, (opcional: Polar H10)

### VÍA 2: DESKTOP (Kivy)
```bash
pip install kivy
python main.py
```
**Tiempo**: 10 minutos
**Requisito**: Python 3.9+, Kivy

### VÍA 3: ANDROID (APK)
```bash
pip install buildozer
buildozer android debug
adb install bin/ronin1310-*.apk
```
**Tiempo**: 30-60 minutos
**Requisito**: Linux/WSL2, Android SDK/NDK

---

## 🔗 Puntos de Integración

### Claude API (Auditor)
```
auditor-ronin-1310.jsx
  ↓ fetch() a https://api.anthropic.com/v1/messages
  ↓ Prompt soberano + query del usuario
  ↓ Respuesta RONIN (3 líneas máx)
```
**Requiere**: Variable de entorno `ANTHROPIC_API_KEY`

### Polar H10 (BLE)
```
pulse_skeleton_v02.py
  ↓ BleakScanner.discover()
  ↓ HR (0x2A37) + ECG PMD (FB005C8x)
  ↓ ELIPSIS CACHE → AUTONOMIC LOAD
  ↓ Vitales + δ(P)
```
**Requiere**: Reloj encendido, rango BLE

### WebSocket (VIGIL)
```
pulse_skeleton_v02.py
  ↓ ws://localhost:8765 (DATA)
  ↓ ws://localhost:8766 (CONTROL)
  ↓ JSON payloads con HMAC-SHA256
```
**Puertos**: 8765 (datos), 8766 (control)

---

## 🔧 Stack Tecnológico

| Capa | Tecnología |
|------|-----------|
| **Backend Biometría** | Python 3.9+ · Bleak · Polar H10 |
| **Servidor Web** | Flask · CORS |
| **Comunicación** | WebSockets · JSON · HMAC-SHA256 |
| **UI React** | React 18 · Hooks · CSS Variables |
| **UI Original** | HTML5 · CSS3 · Vanilla JS |
| **Native (Desktop)** | Kivy · PyJNI |
| **Native (Android)** | Kivy · Android SDK 33+ |
| **Compilación** | Buildozer · Gradle |
| **IA** | Claude API · Prompt Engineering |

---

## 📊 Estadísticas

| Métrica | Valor |
|---------|-------|
| **Líneas de código Python** | ~2,100 |
| **Líneas de código JavaScript/React** | ~850 |
| **Líneas de HTML/CSS** | ~1,900 |
| **Total de documentación** | ~1,000 |
| **Archivos** | 10 |
| **Tamaño total** | 184 KB |

---

## 🎓 Conceptos Principales

### Protocolo VIGIL (5 Capas)
1. **V1 - SOVEREIGN POLICY**: 3 niveles de acceso
2. **V2 - ZKO PACKAGING**: Firmado HMAC-SHA256
3. **V3 - VIGIL HANDSHAKE**: Challenge-Response
4. **V4 - DATA POISONING**: Síntesis gaussiana
5. **V5 - AUTH DASHBOARD**: Panel de embajadores

### Niveles de Acceso
- **NIVEL 0 (BLINDADO)**: `{"seal": true, "node_id": "..."}` → Máxima privacidad
- **NIVEL 1 (OPERATIVO)**: `{"bpm": 72, "t_rel": 45.3, ...}` → Terceros
- **NIVEL 2 (INGENIERÍA)**: `{stream completo}` → Localhost only

### Métricas Cardíacas
| Métrica | Significado |
|---------|-----------|
| **BPM** | Latidos por minuto (60-100 normal) |
| **SDNN** | Variabilidad NN a largo plazo (20-200ms) |
| **RMSSD** | Raíz cuadrada diferencias NN (15-100ms) |
| **DFA-α1** | Detrended Fluctuation Analysis (0.8-1.2) |
| **δ(P)** | Índice de Pulsación (0-100 normalizado) |

---

## 🚀 Próximas Mejoras

- [ ] Exportar sesiones completas (CSV + JSON)
- [ ] Dashboard web remoto (secure)
- [ ] Integración Grafana
- [ ] Export FHIR/HL7
- [ ] OAuth2 Authentication
- [ ] Simulador Polar H10 (modo debug)
- [ ] Docker container
- [ ] CI/CD (GitHub Actions)

---

## 🔐 Seguridad

### Datos Sensibles
- **Master Key**: Nunca sale del proceso (session scope)
- **Tokens**: Derivados vía HMAC, específicos por cliente
- **ID Rotativo**: Nuevo cada 300 segundos

### Data Poisoning
Si un cliente sin token intenta acceder:
```python
fake_rr = [int(np.random.normal(700, 50)) for _ in range(count)]
# Parece real, es completamente falso
```

### Auditoría
Todos los actos registrados:
- Conexión de cliente
- Cambio de nivel
- Aprobación/rechazo
- Transferencia de datos
- Disconnection

---

## 📞 Soporte & Recursos

### Documentación
- `README.md`: Inicio rápido
- `RONIN-1310_PROTOCOLO_VIGIL.md`: Especificación técnica
- `quickstart.html`: Guía visual

### Troubleshooting
Ver `README.md` sección "Troubleshooting"

### Dependencias Principales
- **Bleak**: https://bleak.readthedocs.io/
- **Kivy**: https://kivy.org/
- **Buildozer**: https://buildozer.readthedocs.io/
- **Flask**: https://flask.palletsprojects.com/
- **Polar SDK**: https://github.com/polarofficial/

---

## 📋 Checklist de Instalación

- [ ] Python 3.9+ instalado
- [ ] `requirements.txt` ejecutado
- [ ] (Opcional) Polar H10 encendido
- [ ] (Para APK) Linux/WSL2 + Android SDK/NDK
- [ ] (Para React) Copiar `auditor-ronin-1310.jsx` a proyecto
- [ ] (Para React) Set `ANTHROPIC_API_KEY` env var

---

## 🎭 Filosofía Auditor

```
"No pido permiso para entrar en su red;
 les permito asomarse a mi ventana bajo mis condiciones."

El código es una idea; la APK es el contenedor.
Si el contenedor es débil, el Protocolo VIGIL
se desparrama por el sistema operativo.

Asegura los permisos o serás solo otro bit
de entropía en la Play Store.

Zehahahaha · Tic, Tac
```

---

## 📄 Licencia

Prototipo técnico educativo. **No es aprobado para uso médico/clínico**.
Responsabilidad del operador sobre datos biométricos procesados.

---

**RONIN-1310 · Protocolo VIGIL v0.2**

🛰️ *Soberanía de datos · ⚙️ Integridad criptográfica · 🔨 Auditoría permanente*

**Zehahahaha · Tic, Tac**
