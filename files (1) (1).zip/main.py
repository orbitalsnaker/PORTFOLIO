"""
╔═══════════════════════════════════════════════════════════════╗
║  RONIN-1310 · MAIN BRIDGE                                    ║
║  Integración Kivy WebView + Flask + Protocolo VIGIL          ║
║  Android/iOS Native Wrapper                                   ║
╚═══════════════════════════════════════════════════════════════╝
"""

import os
import sys
import threading
import asyncio
import logging
import signal
from pathlib import Path

# Logging setup
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] %(levelname)s: %(message)s'
)
logger = logging.getLogger('RONIN')

# ════════════════════════════════════════════════════════════════
#  FLASK SERVER
# ════════════════════════════════════════════════════════════════

def init_flask():
    """Inicializa servidor Flask para servir UI"""
    from flask import Flask, send_from_directory, jsonify
    from flask_cors import CORS
    
    app = Flask(__name__)
    CORS(app)
    
    # Ruta a archivos estáticos
    ASSET_DIR = os.path.join(os.path.dirname(__file__), 'assets')
    os.makedirs(ASSET_DIR, exist_ok=True)
    
    @app.route('/')
    def index():
        """Sirve pulse_skeleton_ui_v02.html"""
        return send_from_directory(ASSET_DIR, 'pulse_skeleton_ui_v02.html')
    
    @app.route('/api/status')
    def status():
        """Estado del sistema VIGIL"""
        return jsonify({
            'status': 'ONLINE',
            'auditor': 'RONIN-1310',
            'protocol': 'VIGIL v0.2',
            'timestamp': asyncio.get_event_loop().time() if asyncio._get_running_loop() else 0
        })
    
    @app.route('/assets/<path:path>')
    def assets(path):
        """Sirve assets (CSS, JS, imágenes)"""
        return send_from_directory(ASSET_DIR, path)
    
    @app.route('/health')
    def health():
        """Heartbeat para verificar que Flask está vivo"""
        return jsonify({'alive': True})
    
    return app

def run_flask_server(app, host='0.0.0.0', port=8000):
    """Ejecuta Flask en thread daemon"""
    logger.info(f"🛰️ Flask iniciando en {host}:{port}")
    try:
        app.run(host=host, port=port, debug=False, use_reloader=False, threaded=True)
    except Exception as e:
        logger.error(f"❌ Flask error: {e}")

# ════════════════════════════════════════════════════════════════
#  KIVY APP
# ════════════════════════════════════════════════════════════════

def init_kivy_app():
    """Inicializa app Kivy con WebView"""
    from kivy.app import App
    from kivy.uix.boxlayout import BoxLayout
    from kivy.core.window import Window
    
    try:
        from kivy.uix.webview import WebView
    except ImportError:
        logger.warning("⚠️ WebView no disponible. Usando navegador externo.")
        WebView = None
    
    class RoninApp(App):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.title = "RONIN-1310 · Protocolo VIGIL"
            self.icon = 'data/ronin-icon.png'
            self.flask_app = None
            self.flask_thread = None
        
        def build(self):
            """Construye interfaz Kivy"""
            logger.info("🔨 Construyendo interfaz Kivy...")
            
            # Ajustar tamaño ventana (simular Android)
            Window.size = (1080, 1920)
            Window.borderless = False
            
            # Layout principal
            main_layout = BoxLayout(orientation='vertical')
            
            # WebView si está disponible
            if WebView is not None:
                try:
                    webview = WebView()
                    webview.url = 'http://127.0.0.1:8000/'
                    main_layout.add_widget(webview)
                    logger.info("✅ WebView inicializado")
                except Exception as e:
                    logger.error(f"❌ WebView error: {e}")
                    self._add_fallback_label(main_layout)
            else:
                self._add_fallback_label(main_layout)
            
            return main_layout
        
        def _add_fallback_label(self, layout):
            """Fallback si WebView no funciona"""
            from kivy.uix.label import Label
            label = Label(
                text='RONIN-1310 Online\nAbre http://127.0.0.1:8000/ en tu navegador',
                font_size='14sp'
            )
            layout.add_widget(label)
        
        def on_start(self):
            """Se ejecuta cuando la app inicia"""
            logger.info("▶️  RONIN-1310 iniciando...")
            
            # Inicia Flask en thread background
            self.flask_app = init_flask()
            self.flask_thread = threading.Thread(
                target=run_flask_server,
                args=(self.flask_app,),
                daemon=True
            )
            self.flask_thread.start()
            
            logger.info("✅ Sistema operacional")
        
        def on_stop(self):
            """Se ejecuta cuando la app se cierra"""
            logger.info("🛑 Cerrando RONIN-1310...")
            if self.flask_thread:
                logger.info("💾 Guardando sesión...")
            return True
    
    return RoninApp()

# ════════════════════════════════════════════════════════════════
#  PULSE SKELETON INTEGRATION (OPCIONAL)
# ════════════════════════════════════════════════════════════════

def init_vigil_bridge():
    """
    Inicializa puente con pulse_skeleton_v02.py (si está disponible)
    Ejecuta en thread asyncio separado para no bloquear Kivy
    """
    try:
        from pulse_skeleton_v02 import (
            ble_run, 
            vigil_data_server, 
            vigil_control_server,
            S
        )
        
        logger.info("✅ Módulo pulse_skeleton_v02 detectado")
        
        def run_vigil_backend():
            """Ejecuta BLE + VIGIL en evento loop asyncio"""
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            
            try:
                # Intenta conectar a Polar H10 en modo web
                loop.run_until_complete(
                    asyncio.gather(
                        ble_run("web"),
                        vigil_data_server(),
                        vigil_control_server()
                    )
                )
            except Exception as e:
                logger.error(f"❌ VIGIL backend error: {e}")
            finally:
                loop.close()
        
        # Lanza VIGIL en thread daemon
        vigil_thread = threading.Thread(target=run_vigil_backend, daemon=True)
        vigil_thread.start()
        logger.info("🛰️ Backend VIGIL iniciado (aguardando Polar H10...)")
        
        return vigil_thread
    
    except ImportError:
        logger.warning("⚠️ pulse_skeleton_v02.py no disponible (modo simulado)")
        return None

# ════════════════════════════════════════════════════════════════
#  FLIGHT RECORDER SETUP (PERSISTENCIA)
# ════════════════════════════════════════════════════════════════

def init_flight_recorder():
    """Configura directorio para almacenamiento persistente"""
    # Android: /storage/emulated/0/Documents/RONIN_VIGIL/
    # iOS: ~/Documents/RONIN_VIGIL/
    # Desktop: ~/.ronin/
    
    if sys.platform == 'android':
        # Android: usar Documents
        from jnius import autoclass
        PythonActivity = autoclass('org.kivy.android.PythonActivity')
        activity = PythonActivity.mPythonActivity
        
        # Obtener ruta Documents
        try:
            Environment = autoclass('android.os.Environment')
            documents_dir = Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DOCUMENTS
            ).getAbsolutePath()
            base_dir = os.path.join(documents_dir, 'RONIN_VIGIL')
        except:
            base_dir = os.path.expanduser('~/.ronin')
    
    elif sys.platform == 'ios':
        base_dir = os.path.expanduser('~/Documents/RONIN_VIGIL')
    
    else:
        # Desktop
        base_dir = os.path.expanduser('~/.ronin')
    
    os.makedirs(base_dir, exist_ok=True)
    logger.info(f"💾 Flight Recorder: {base_dir}")
    
    return base_dir

# ════════════════════════════════════════════════════════════════
#  ENTRY POINT
# ════════════════════════════════════════════════════════════════

def main():
    logger.info("""
    ╔═══════════════════════════════════════════════╗
    ║   RONIN-1310 · PROTOCOLO VIGIL               ║
    ║   Capa de Permiso Inverso                    ║
    ║   Soberanía de Datos                         ║
    ╚═══════════════════════════════════════════════╝
    """)
    
    # Setup persistencia
    flight_recorder_path = init_flight_recorder()
    
    # Setup VIGIL backend (opcional, requiere Polar H10 real)
    vigil_thread = init_vigil_bridge()
    
    # Inicia app Kivy (bloquea hasta cerrar)
    app = init_kivy_app()
    
    # Manejo de señales
    def signal_handler(sig, frame):
        logger.info("🛑 Cerrando app...")
        app.stop()
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Run
    try:
        app.run()
    except KeyboardInterrupt:
        logger.info("⏹️  App cerrada por usuario")
    except Exception as e:
        logger.error(f"❌ Error fatal: {e}", exc_info=True)
    
    logger.info("✅ RONIN-1310 offline · Sesión guardada")

if __name__ == '__main__':
    main()
