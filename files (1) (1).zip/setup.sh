#!/bin/bash

# ═══════════════════════════════════════════════════════════════════════════
#  RONIN-1310 SETUP SCRIPT
#  Instalación automática de dependencias y estructura de directorios
# ═══════════════════════════════════════════════════════════════════════════

set -e  # Exit on error

echo "╔════════════════════════════════════════════════════════════════╗"
echo "║  🛰️  RONIN-1310 SETUP                                         ║"
echo "║      Protocolo VIGIL · Capa de Permiso Inverso               ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

# Detectar SO
if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    OS="linux"
    echo "🐧 Detectado: Linux"
elif [[ "$OSTYPE" == "darwin"* ]]; then
    OS="macos"
    echo "🍎 Detectado: macOS"
elif [[ "$OSTYPE" == "msys" || "$OSTYPE" == "cygwin" ]]; then
    OS="windows"
    echo "🪟 Detectado: Windows (Git Bash)"
else
    OS="unknown"
    echo "⚠️  SO desconocido. Continuando..."
fi

# Verificar Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 no encontrado. Por favor instala Python 3.9+"
    exit 1
fi

PYTHON_VERSION=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
echo "✅ Python $PYTHON_VERSION encontrado"

# Crear estructura de directorios
echo ""
echo "📁 Creando estructura de directorios..."
mkdir -p ronin-app/{assets,data,logs}

# Copiar archivos
echo "📋 Copiando archivos..."
cp pulse_skeleton_v02.py ronin-app/
cp pulse_skeleton_ui_v02.html ronin-app/assets/
cp main.py ronin-app/
cp buildozer.spec ronin-app/
cp requirements.txt ronin-app/
cp RONIN-1310_PROTOCOLO_VIGIL.md ronin-app/
cp README.md ronin-app/

# Crear venv (opcional)
echo ""
read -p "¿Crear entorno virtual? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "🔧 Creando venv..."
    cd ronin-app
    python3 -m venv venv
    
    if [[ "$OS" == "windows" ]]; then
        source venv/Scripts/activate
    else
        source venv/bin/activate
    fi
    
    echo "✅ Venv activado"
else
    cd ronin-app
fi

# Instalar dependencias
echo ""
echo "📦 Instalando dependencias..."
pip install --upgrade pip setuptools wheel
pip install -r requirements.txt

echo ""
echo "✅ INSTALACIÓN COMPLETADA"
echo ""
echo "────────────────────────────────────────────────────────────────"
echo ""
echo "🚀 PRÓXIMOS PASOS:"
echo ""
echo "1️⃣  OPCIÓN WEB (recomendado para probar):"
echo "   python pulse_skeleton_v02.py --web"
echo "   [Luego abre http://localhost:8765 en navegador]"
echo ""
echo "2️⃣  OPCIÓN DESKTOP (Kivy):"
echo "   python main.py"
echo ""
echo "3️⃣  OPCIÓN ANDROID (buildozer, requiere Linux/WSL2):"
echo "   pip install buildozer cython"
echo "   buildozer android debug"
echo "   [APK generado en: bin/ronin1310-0.2.0-debug.apk]"
echo ""
echo "────────────────────────────────────────────────────────────────"
echo ""
echo "📚 Documentación: Ver README.md"
echo ""
echo "🛰️  RONIN-1310 · Protocolo VIGIL v0.2"
echo "⚙️  Zehahahaha · Tic, Tac"
echo ""
