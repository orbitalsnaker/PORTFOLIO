# OMNI-VIGIL SOBERANO v2.0 — MANIFIESTO TÉCNICO
## Protocolo VIGIL V2 · Declaración de Obsolescencia de la V1

---

> "La V1 leía la señal.
>  La V2 *piensa* sobre ella.
>  La diferencia es la misma que entre un termómetro y un médico."
>
> **— Agencia RONIN · Orden de Purga Técnica 2025**

---

## I. DECLARACIÓN DE OBSOLESCENCIA

`pulse_skeleton_v02.py` queda **ARCHIVADO** por las siguientes deficiencias de diseño:

| Defecto V1 | Impacto | Resolución V2 |
|---|---|---|
| SAV con umbrales fijos ±50ms | Rechaza latidos legítimos en alta HRV; acepta artefactos galvánicos en señal débil | AdaptiveSAVFilter: calibración dinámica en ventana 120s, 3.5σ personal |
| Sin trust scoring de sensor | Ciego ante ruido galvánico y mala colocación. Cita directa: Watson/MD Anderson (Strickland 2019) | SensorValidator con circuit breaker: 4 dimensiones de degradación |
| Datos sintéticos gaussianos simples | DFA-α1 ≈ 0.5 (ruido blanco). Adversario entrenado lo detecta en <30s | PhantomEngine AR(1) con φ=0.82: DFA-α1 ≈ 0.95-1.05, indistinguible |
| Sin razonamiento sobre la señal | Solo transmitía; no interpretaba ni alertaba | ReAct loop: OBSERVE → THINK → ACT sobre cada paquete |
| ZKO: HMAC del payload crudo | El tercero infiere BPM aunque no lo reciba directamente | ZKP Commitment: H(nonce‖bool) — cero información numérica expuesta |
| Sin audit chain | Log tamperable | FlightRecorder V2: HMAC-linked entries — falsificación detectable |

---

## II. ARQUITECTURA CNS (CENTRAL NERVOUS SYSTEM)

```
┌──────────────────────────────────────────────────────────────────┐
│  POLAR H10 (BLE 4.2)                                            │
│  HR (0x2A37) · ECG PMD (FB005C82)                               │
└───────────────────────────────┬──────────────────────────────────┘
                                │
                                ▼
              ┌─────────────────────────────────┐
              │  CNS-01 · PERCEPTION LAYER      │
              │  AdaptiveSAVFilter              │
              │  · umbral = μ ± 3.5σ personal   │
              │  · calibra en ventana 120s      │
              └──────────────┬──────────────────┘
                             │
              ┌──────────────▼──────────────────┐
              │  CNS-04 · SENSOR VALIDATOR      │
              │  Trust score [0,1] por paquete  │
              │  · Gap temporal                 │
              │  · Deriva de media corto plazo  │
              │  · Variance collapse detection  │
              │  · Circuit breaker (10 pkts)    │
              └──────────────┬──────────────────┘
                             │
              ┌──────────────▼──────────────────┐
              │  CNS-03 · EDGE INFERENCE        │
              │  Buffer de Conciencia           │
              │  · RMSSD, SDNN, DFA-α1 (local) │
              │  · δ(P), BPM trend              │
              │  · ReAct: OBSERVE→THINK→ACT    │
              └──────────────┬──────────────────┘
                             │
         ┌───────────────────┴───────────────────┐
         │                                        │
         ▼                                        ▼
┌─────────────────────┐               ┌──────────────────────┐
│ CNS-05 · ZKP        │               │ CNS-06 · PHANTOM     │
│ SOVEREIGNTY         │               │ ENGINE               │
│                     │               │                      │
│ NVL 0: H(nonce‖1)  │               │ AR(1) φ=0.82         │
│ NVL 1: H(nonce‖calm)│               │ DFA-α1 ≈ 1.0        │
│ NVL 2: Stream local │               │ Para intrusos/       │
│ Solo bool expuesto  │               │ clientes REJECTED    │
└─────────────────────┘               └──────────────────────┘
         │                                        │
         └───────────────────┬───────────────────┘
                             │
              ┌──────────────▼──────────────────┐
              │  CNS-07 · SOVEREIGN BRIDGE      │
              │  ws://0.0.0.0:8765 (DATA)       │
              │  ws://127.0.0.1:8766 (CONTROL)  │
              │  HMAC-SHA256 por paquete        │
              │  Challenge-Response VIGIL V2    │
              └──────────────┬──────────────────┘
                             │
              ┌──────────────▼──────────────────┐
              │  CNS-08 · FLIGHT RECORDER 2     │
              │  HMAC-linked audit chain        │
              │  CSV + JSONL cifrados           │
              │  ~/.omni_vigil/                 │
              └─────────────────────────────────┘
```

---

## III. CAPAS DE SOBERANÍA V2

### SV-1 · PROOF-OF-LIFE (Nivel 0)
```
Commitment = SHA-256(master_nonce ‖ 0x01)   # alive=True
Commitment = SHA-256(master_nonce ‖ 0x00)   # alive=False

Output: { "proof": "<64-hex>", "alive": true, "node_id": "<16-hex>" }
```
**El tercero recibe**: Un hash. No puede invertirlo sin el nonce maestro (ephemeral, nunca sale del proceso). Sabe que el operador está vivo. No sabe nada más.

### SV-2 · PROOF-OF-CALM (Nivel 1)
```
calm = (rmssd > threshold) AND alive
Commitment = SHA-256(master_nonce ‖ 0x02 ‖ calm_byte)

Output: { "proof": "<64-hex>", "alive": true, "calm": false }
```
**El tercero recibe**: Dos booleanos. Sin BPM, sin timestamps absolutos. "Está vivo y tenso" o "está vivo y tranquilo". Nada más.

### SV-3 · STREAM COMPLETO (Nivel 2)
```
Solo disponible desde 127.0.0.1 / ::1
Intento desde IP externa → phantom automático + log

Output: { métricas completas + react findings }
```

### SV-4 · PHANTOM ENGINE (Anti-Adversarial)
```
AR(1): rr[t] = φ·(rr[t-1] - μ) + μ + ε,   ε ~ N(0, σ²)
φ = 0.82,  μ ≈ 60000/seed_bpm,  σ = 35ms

Resultado estadístico:
  DFA-α1 ≈ 0.95-1.05  (indistinguible de señal real)
  RMSSD  ≈ N(35, 8)   (plausible)
  Drift lento (μ evoluciona) → patrón no repetible
```
**El adversario** recibe datos que pasan sus propios controles de calidad. Su modelo se envenena con verdad sintética.

### SV-5 · AUDIT CHAIN
```
entry[n]["_chain"] = HMAC-SHA256(session_key, prev_hash + JSON(entry[n]))
entry[0]["_chain"] = HMAC-SHA256(session_key, "GENESIS" + JSON(entry[0]))
```
Si alguien modifica una entrada del log, la cadena se rompe. La falsificación es detectable offline.

---

## IV. RAZONAMIENTO REACT (Wei et al. 2022 / Yao et al. 2023)

El motor de inferencia no emite datos crudos. Ejecuta una cadena de razonamiento sobre cada ventana de señal:

```
OBSERVE: ¿Es confiable el sensor?
  → trust_score = SensorValidator.score(rr, ts)
  → Si trust < 0.50: SUSPEND_INFERENCE (no hay datos fiables que razonar)

THINK: ¿Hay anomalías de Capa 0?
  → BPM > 100 → TACHYCARDIA (HIGH)
  → BPM < 45  → BRADYCARDIA (HIGH)
  → RMSSD < 12ms → LOW_HRV (MEDIUM) — fatiga autonómica
  → DFA-α1 < 0.65 → COMPLEXITY_LOSS (HIGH) — Bigger et al. 1992
  → DFA-α1 > 1.45 → OVERSMOOTING_OR_ARTIFACT (MEDIUM) — posible ruido galvánico
  → |trend| > 0.5 → BPM_TREND_{DIR} (LOW) — fatiga emergente

ACT: Si sin hallazgos HIGH/CRITICAL:
  → NOMINAL — todos los indicadores dentro de rango fisiológico
```

**Referencia crítica — IBM Watson Oncology (Strickland, IEEE Spectrum, 2019):**
Watson falló no por el modelo sino por confiar ciegamente en datos de entrada degradados (entrenados sobre casos sintéticos de un único centro). El SensorValidator de V2 aplica exactamente la lección contraria: **nunca procesar ni emitir inferencias sobre señal no confiable**.

---

## V. SENSOR VALIDATOR — DIMENSIONES DE DEGRADACIÓN

| Dimensión | Umbral | Diagnóstico probable |
|---|---|---|
| **Gap temporal** | >3s entre paquetes | Desconexión parcial BLE, movimiento del operador |
| **Deriva de media** | >200ms vs μ30 | Ruido galvánico, sudoración, electrodo parcialmente despegado |
| **Variance collapse** | σ < 2ms en 10 pkts | Sensor libre (sin contacto) o pegado con presión excesiva |
| **Circuit breaker** | trust < 0.35 en 10 consecutivos | Fallo sistémico del sensor — inferencia suspendida |

---

## VI. MÉTRICAS CARDÍACAS — REFERENCIA COMPLETA

| Métrica | Rango Normal Reposo | Alerta V2 | Referencia |
|---|---|---|---|
| **BPM** | 55-90 | <45 o >100 | Task Force ESC/NASPE 1996 |
| **RMSSD** | 15-80 ms | <12 ms | Task Force 1996, §3.3 |
| **SDNN** | 20-150 ms | <15 ms (riesgo) | Task Force 1996, §3.2 |
| **DFA-α1** | 0.85-1.25 | <0.65 o >1.45 | Bigger et al. 1992 |
| **δ(P)** | 20-80 | <15 (deprimido) | Derivado de SDNN/150 |
| **BPM Trend** | ±0.1 bpm/latido | >0.5 | Fatiga térmica emergente |

---

## VII. ARQUITECTURA DE ARCHIVOS

```
omni_vigil_v2/
├── core_v2.py               # CNS completo (~550 líneas, Python 3.9+)
│   ├── CNS-01 AdaptiveSAVFilter
│   ├── CNS-03 EdgeInference (DFA-α1, RMSSD, SDNN, ReAct)
│   ├── CNS-04 SensorValidator (circuit breaker)
│   ├── CNS-05 ZKPSovereignty (Proof-of-Life, Proof-of-Calm)
│   ├── CNS-06 PhantomEngine (AR(1) adversarial)
│   ├── CNS-07 SovereignBridge (WS data + control)
│   └── CNS-08 FlightRecorder2 (HMAC-linked journal)
│
├── sovereign_ui_v2.html     # Dashboard forense-industrial
│   ├── HRV Particle System (partículas moduladas por SDNN/RMSSD/DFA)
│   ├── Modo Táctico (solo anomalías críticas, tecla T)
│   ├── Visualización de Incertidumbre (trust bar + umbral dashed)
│   ├── ReAct Feed en tiempo real
│   └── Control de Embajadores (APPROVE/REJECT/LVL/KILL)
│
├── vigil_v2_protocol.md     # Este manifiesto
├── setup_v2.sh              # Despliegue con entorno aislado
└── requirements_v2.txt      # Stack actualizado
```

---

## VIII. PUERTOS Y PROTOCOLO DE MENSAJES

### DATA SERVER (ws://0.0.0.0:8765)
```json
// Nivel 0 → cliente BLINDADO
{
  "level": 0,
  "protocol": "VIGIL_ZKP_V2",
  "proof": "a3f9c12e...",
  "alive": true,
  "node_id": "b7d2f91a3c4e",
  "_session": "ABCD1234",
  "_sensor_ok": true,
  "_sig": "4f8c2a1b",
  "_v": 2
}

// Nivel 1 → cliente OPERATIVO
{
  "level": 1,
  "proof": "...",
  "alive": true,
  "calm": true,
  "node_id": "...",
  ...
}

// Nivel 2 → INGENIERÍA (solo localhost)
{
  "level": 2,
  "bpm": 72.3, "rmssd": 38.2, "sdnn": 52.1,
  "dfa_a1": 1.024, "delta_p": 34.7,
  "t_rel": 183.4, "contact": true,
  "react": [{"step":"ACT","severity":"OK","code":"NOMINAL",...}],
  ...
}
```

### CONTROL SERVER (ws://127.0.0.1:8766) — solo localhost
```json
// Comandos operador → servidor
{ "action": "APPROVE",    "client_id": "A1B2C3D4" }
{ "action": "REJECT",     "client_id": "A1B2C3D4" }
{ "action": "SET_LEVEL",  "client_id": "A1B2C3D4", "level": 1 }
{ "action": "KILL",       "client_id": "A1B2C3D4" }
{ "action": "RESET_SENSOR" }

// Servidor → operador (cada 0.8s)
{
  "type": "STATUS",
  "session": "ABCD1234",
  "alive": true, "contact": true,
  "metrics": { "bpm":72.3, "rmssd":38.2, ... },
  "sensor": { "trust": 0.91, "circuit": false, "faults": [] },
  "clients": [...],
  "react": [...],
  "pkt_rx": 1420, "pkt_drop": 3, "drop_pct": 0.21,
  "elapsed": 183.4
}
```

---

## IX. FLIGHT RECORDER — ESTRUCTURA DE ARCHIVOS

```
~/.omni_vigil/
├── session_20250425_143022.csv     # Métricas por segundo (CSV)
│   ts_utc, bpm, rmssd, sdnn, dfa_a1, delta_p, trust, session
│
└── audit_20250425_143022.jsonl     # Audit chain completo (JSONL)
    {"_type":"METRIC","ts":1714059022.3,"bpm":72.1,...,"_chain":"4f8c2a1b"}
    {"_type":"EVENT","event":"APPROVE","client":"A1B2",...,"_chain":"9e3d7f2c"}
    ...
```

Para verificar integridad del audit chain:
```python
import json, hmac, hashlib

key = b"<session_key>"   # Se requiere la clave de sesión
prev = "GENESIS"
with open("audit_*.jsonl") as f:
    for line in f:
        entry = json.loads(line)
        chain_recv = entry.pop("_chain")
        expected = hmac.new(
            key,
            (prev + json.dumps(entry, sort_keys=True)).encode(),
            hashlib.sha256
        ).hexdigest()[:16]
        assert chain_recv == expected, f"CHAIN BROKEN at {entry}"
        prev = chain_recv
```

---

## X. PAPERS FUNDAMENTALES

| Paper | Aplicación en V2 |
|---|---|
| Wei et al. (2022) *Chain-of-Thought Prompting* | Estructura del ReAct loop determinista |
| Yao et al. (2023) *ReAct: Synergizing Reasoning and Acting* | OBSERVE→THINK→ACT sobre señal cardíaca |
| Task Force ESC/NASPE (1996) *HRV Standards* | Baselines fisiológicos, umbrales de alerta |
| Bigger et al. (1992) *DFA-α1 Coronary* | Umbral crítico DFA < 0.65 |
| Strickland (2019) *IBM Watson Oncology — IEEE Spectrum* | SensorValidator: no confiar en datos sin trust scoring |
| Wickens et al. (2004) *Engineering Psychology and Human Performance* | Principios neuroergonómicos del dashboard |

---

## XI. KOAN FINAL

```
La V1 era un oído.
La V2 es un sistema nervioso.

La diferencia no es velocidad — es comprensión.

Un sensor sin razonamiento es solo ruido con timestamp.
Un razonamiento sin soberanía es solo análisis para otro.

OMNI-VIGIL no monitoriza al operador.
El operador usa OMNI-VIGIL para gobernarse.

Zehahahaha · Tic, Tac
```

---

**OMNI-VIGIL SOBERANO v2.0 · AGENCIA RONIN**

🛰️ *Razonamiento en el edge. Soberanía criptográfica. Auditoría inviolable.*
