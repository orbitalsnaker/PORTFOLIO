"""
╔══════════════════════════════════════════════════════════════════════════════╗
║   OMNI-VIGIL SOBERANO  v2.0  //  CENTRAL NERVOUS SYSTEM                    ║
║   Arquitectura Agnética de Baja Latencia Extrema                           ║
╠══════════════════════════════════════════════════════════════════════════════╣
║   [MÓDULOS CNS]                                                             ║
║    CNS-01  PERCEPTION LAYER    — BLE async + SAV-2 adaptive filter         ║
║    CNS-02  CONSCIOUSNESS BUF   — ReAct reasoning loop + basal comparison   ║
║    CNS-03  EDGE INFERENCE      — Local ML: HRV anomaly + fatigue index     ║
║    CNS-04  SENSOR VALIDATOR    — IBM-Watson-class sensor trust scoring     ║
║    CNS-05  ZKP SOVEREIGNTY     — Liveness proof without biometric leak     ║
║    CNS-06  PHANTOM ENGINE      — Perfect synthetic adversarial signal      ║
║    CNS-07  SOVEREIGN BRIDGE    — Multi-client async websocket layer        ║
║    CNS-08  FLIGHT RECORDER 2   — Encrypted rotating journal + audit trail  ║
╠══════════════════════════════════════════════════════════════════════════════╣
║   PAPERS FUNDAMENTALES:                                                     ║
║    Wei et al. (2022) Chain-of-Thought Prompting — razón paso a paso        ║
║    Yao et al. (2023) ReAct — razonar + actuar sobre señal en tiempo real   ║
║    Strickland (2019) IBM Watson Oncology — lección: no confiar en sensor   ║
║    Task Force ESC/NASPE (1996) HRV Standards — métricas cardíacas SOTA    ║
║    Bigger et al. (1992) DFA-α1 coronary — baseline fisiológica             ║
╠══════════════════════════════════════════════════════════════════════════════╣
║   DECLARACIÓN DE OBSOLESCENCIA                                              ║
║    pulse_skeleton_v02.py — ARCHIVADO. Incapaz de razonar sobre la señal.   ║
║    Solo leía datos. CNS-V2 PIENSA sobre ellos.                             ║
╚══════════════════════════════════════════════════════════════════════════════╝

VIGIL V2 SOVEREIGNTY LAYERS:
  SV-1  PROOF-OF-LIFE        — Commitment scheme: H(nonce || alive) → no BPM leak
  SV-2  TEMPORAL BLINDNESS   — Relative timestamps only; absolute epoch sealed
  SV-3  PHANTOM INJECTION    — On intrusion: perfect synthetic Gaussian AR(1) signal
  SV-4  SENSOR ATTESTATION   — Trust score per packet; circuit-breaker on drift
  SV-5  AUDIT CHAIN          — HMAC-linked log entries; tampering is detectable

Usage:
  python core_v2.py                   # TUI mode
  python core_v2.py --web             # WebSocket sovereign server
  python core_v2.py --web --simulate  # Simulate Polar H10 (no hardware needed)
"""

from __future__ import annotations

import asyncio
import struct
import csv
import time
import sys
import math
import argparse
import signal
import os
import threading
import hashlib
import hmac
import json
import uuid
import random
import logging
from datetime import datetime, timezone
from collections import deque
from typing import Optional, Dict, List, Tuple, Any
from dataclasses import dataclass, field, asdict
from enum import IntEnum
from pathlib import Path

# ── Optional deps ────────────────────────────────────────────────────────────
try:
    import numpy as np
    NUMPY_OK = True
except ImportError:
    NUMPY_OK = False

try:
    from bleak import BleakScanner, BleakClient
    BLEAK_OK = True
except ImportError:
    BLEAK_OK = False

try:
    import websockets
    WS_OK = True
except ImportError:
    WS_OK = False

try:
    from cryptography.hazmat.primitives.kdf.hkdf import HKDF
    from cryptography.hazmat.primitives import hashes
    CRYPTO_OK = True
except ImportError:
    CRYPTO_OK = False

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(name)s %(levelname)s: %(message)s",
    datefmt="%H:%M:%S.%f"[:-3],
)
log = logging.getLogger("CNS")

# ══════════════════════════════════════════════════════════════════════════════
#  GATT / PMD — Polar H10
# ══════════════════════════════════════════════════════════════════════════════

HR_UUID   = "00002a37-0000-1000-8000-00805f9b34fb"
PMD_CTRL  = "fb005c81-02e7-f387-1cad-8d263ba56064"
PMD_DATA  = "fb005c82-02e7-f387-1cad-8d263ba56064"
ECG_START = bytes([0x02, 0x00, 0x00, 0x01, 0x82, 0x00, 0x01, 0x01, 0x0e, 0x00])
ECG_STOP  = bytes([0x03, 0x00])


# ══════════════════════════════════════════════════════════════════════════════
#  CNS-01 · PERCEPTION LAYER — Adaptive SAV-2 Filter
#  Mejora de V1: umbral adaptativo basado en σ histórica del operador.
#  Un rechazo estático era ciego ante la variabilidad fisiológica individual.
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class PacketMeta:
    """Metadatos de un paquete BLE para scoring de confianza."""
    ts:         float   # wall clock de recepción
    rr_ms:      int     # intervalo R-R en ms
    rssi:       int     = -70   # estimado si no disponible
    trust:      float   = 1.0   # [0,1] — calculado por SensorValidator


class AdaptiveSAVFilter:
    """
    SAV-2: Adaptive Successive-Artifact Validator.
    V1 usaba umbrales fijos (±50 ms). Esto rechazaba latidos legítimos en
    operadores con alta HRV y aceptaba artefactos galvánicos en señal baja.
    V2 calibra los umbrales en ventana deslizante de 120 s.

    Referencia: Task Force ESC/NASPE (1996) — §3.1 ectopic beat rejection.
    """
    # Límites fisiológicos absolutos (Task Force 1996)
    ABSOLUTE_MIN_MS = 250   # >240 bpm — patológico
    ABSOLUTE_MAX_MS = 2500  # <24 bpm  — patológico

    def __init__(self, window: int = 120):
        self._window = window          # segundos para calibración
        self._history: deque[float] = deque()
        self._times:   deque[float] = deque()
        self._mean: float = 750.0
        self._std:  float = 60.0

    def _recalibrate(self):
        now = time.monotonic()
        # Purge fuera de ventana
        while self._times and now - self._times[0] > self._window:
            self._times.popleft()
            self._history.popleft()
        if len(self._history) >= 8:
            vals = list(self._history)
            self._mean = sum(vals) / len(vals)
            variance = sum((v - self._mean)**2 for v in vals) / len(vals)
            self._std  = max(variance**0.5, 20.0)  # σ mín 20 ms

    def validate(self, rr_ms: int) -> Tuple[bool, str]:
        """Retorna (valido, motivo). Motivo vacío si válido."""
        if rr_ms < self.ABSOLUTE_MIN_MS:
            return False, f"ABSOLUTE_MIN ({rr_ms} ms < {self.ABSOLUTE_MIN_MS})"
        if rr_ms > self.ABSOLUTE_MAX_MS:
            return False, f"ABSOLUTE_MAX ({rr_ms} ms > {self.ABSOLUTE_MAX_MS})"

        # Umbral adaptativo: 3σ del histórico personal
        low  = self._mean - 3.5 * self._std
        high = self._mean + 3.5 * self._std
        if not (low <= rr_ms <= high):
            return False, f"ADAPTIVE_SIGMA ({rr_ms:.0f} ms, μ={self._mean:.0f} ±{self._std:.0f})"

        # Acepta y actualiza
        self._history.append(float(rr_ms))
        self._times.append(time.monotonic())
        self._recalibrate()
        return True, ""


# ══════════════════════════════════════════════════════════════════════════════
#  CNS-04 · SENSOR VALIDATOR — Trust Scoring basado en IBM Watson Lección
#  IBM Watson Oncology falló porque confió ciegamente en datos entrenados
#  sobre casos sintéticos. (Strickland, IEEE Spectrum, 2019)
#
#  El SensorValidator asigna un trust_score [0,1] a cada paquete considerando:
#    a) Deriva de la media de corto plazo (galvanic noise / mala colocación)
#    b) Jitter de llegada BLE (latencia de radio)
#    c) Brecha temporal (gap ≥ 3 s = posible desconexión)
#    d) Saturación estadística (varianza colapsa → sensor pegado o libre)
# ══════════════════════════════════════════════════════════════════════════════

class SensorValidator:
    """
    Trust scoring por paquete. Si trust < CIRCUIT_BREAKER_THRESHOLD en
    N paquetes consecutivos, activa el circuit breaker y suspende inferencia.

    Cita: Strickland (2019) — "El fracaso de Watson no fue el modelo;
    fue no cuestionar la calidad de los datos de entrada."
    """
    CIRCUIT_BREAKER_THRESHOLD = 0.35
    CIRCUIT_BREAKER_WINDOW    = 10   # paquetes consecutivos bajo umbral

    def __init__(self):
        self._last_ts:       Optional[float] = None
        self._rr_buf:        deque[float] = deque(maxlen=30)
        self._low_trust_run: int = 0
        self.circuit_open:   bool = False
        self.trust_history:  deque[float] = deque(maxlen=60)
        self.fault_log:      List[str] = []

    def score(self, rr_ms: int, recv_ts: float) -> Tuple[float, List[str]]:
        """Calcula trust score y lista de flags de degradación."""
        flags: List[str] = []
        score = 1.0

        # A) Gap temporal
        if self._last_ts is not None:
            gap = recv_ts - self._last_ts
            if gap > 3.0:
                penalty = min(0.5, (gap - 3.0) / 10.0)
                score -= penalty
                flags.append(f"GAP_{gap:.1f}s")
        self._last_ts = recv_ts

        # B) Deriva de media de corto plazo
        self._rr_buf.append(rr_ms)
        if len(self._rr_buf) >= 8:
            mu  = sum(self._rr_buf) / len(self._rr_buf)
            dev = abs(rr_ms - mu)
            if dev > 200:
                penalty = min(0.4, (dev - 200) / 400.0)
                score -= penalty
                flags.append(f"DRIFT_{dev:.0f}ms")

        # C) Saturación estadística (varianza → 0: sensor libre o pegado)
        if len(self._rr_buf) >= 10:
            vals = list(self._rr_buf)
            mu   = sum(vals) / len(vals)
            var  = sum((v - mu)**2 for v in vals) / len(vals)
            if var < 4.0:   # σ < 2 ms → físicamente imposible en señal real
                score -= 0.5
                flags.append("VARIANCE_COLLAPSE")

        score = max(0.0, min(1.0, score))
        self.trust_history.append(score)

        # Circuit breaker
        if score < self.CIRCUIT_BREAKER_THRESHOLD:
            self._low_trust_run += 1
            if self._low_trust_run >= self.CIRCUIT_BREAKER_WINDOW:
                if not self.circuit_open:
                    log.warning("⚡ CIRCUIT BREAKER OPEN — sensor trust degraded")
                self.circuit_open = True
                msg = f"CIRCUIT_OPEN low_run={self._low_trust_run}"
                flags.append(msg)
                self.fault_log.append(f"{datetime.utcnow().isoformat()} {msg}")
        else:
            self._low_trust_run = 0
            if self.circuit_open:
                log.info("✅ Circuit breaker reset — trust restored")
                self.circuit_open = False

        return score, flags

    def mean_trust(self) -> float:
        if not self.trust_history:
            return 1.0
        return sum(self.trust_history) / len(self.trust_history)


# ══════════════════════════════════════════════════════════════════════════════
#  CNS-03 · EDGE INFERENCE ENGINE — ML local sin nube
#  Implementa 4 modelos ligeros que corren en CPU sin dependencias externas:
#
#  M1: Z-Score Streaming — anomalía instantánea por desviación
#  M2: DFA-α1 Estimator  — complejidad fractal (Bigger et al. 1992)
#  M3: RMSSD/SDNN Ratio  — índice simpato-vagal (tono autonómico)
#  M4: Trend Detector    — pendiente de BPM en ventana 60 s (fatiga térmica)
# ══════════════════════════════════════════════════════════════════════════════

class EdgeInference:
    """
    Buffer de Conciencia — compara señal actual contra basales fisiológicos.
    Sin NumPy: aritmética pura de Python para máxima portabilidad en edge.
    """

    # Basales poblacionales (Task Force ESC/NASPE 1996, adultos en reposo)
    BASAL_BPM_RANGE    = (55, 90)
    BASAL_RMSSD_RANGE  = (15, 80)
    BASAL_SDNN_RANGE   = (20, 150)
    BASAL_DFA_RANGE    = (0.85, 1.25)

    # Umbrales de alerta táctica (Capa 0)
    ALERT_BPM_HIGH  = 100
    ALERT_BPM_LOW   = 45
    ALERT_RMSSD_LOW = 12   # HRV deprimida — estrés o fatiga severa
    ALERT_DFA_LOW   = 0.65  # pérdida de complejidad — riesgo cardíaco
    ALERT_DFA_HIGH  = 1.45  # complejidad excesiva — artefacto o arritmia

    def __init__(self, buf_size: int = 256):
        self._rr:   deque[float] = deque(maxlen=buf_size)
        self._ts:   deque[float] = deque(maxlen=buf_size)
        self._bpm_history: deque[float] = deque(maxlen=120)

    # ── Métricas primarias ────────────────────────────────────────────────
    def push(self, rr_ms: float, ts: float):
        self._rr.append(rr_ms)
        self._ts.append(ts)
        bpm = 60000.0 / rr_ms if rr_ms > 0 else 0
        self._bpm_history.append(bpm)

    def bpm(self) -> float:
        return self._bpm_history[-1] if self._bpm_history else 0.0

    def rmssd(self) -> float:
        rr = list(self._rr)
        if len(rr) < 2:
            return 0.0
        diffs = [(rr[i+1] - rr[i])**2 for i in range(len(rr)-1)]
        return (sum(diffs) / len(diffs))**0.5

    def sdnn(self) -> float:
        rr = list(self._rr)
        if len(rr) < 4:
            return 0.0
        mu = sum(rr) / len(rr)
        return (sum((v - mu)**2 for v in rr) / len(rr))**0.5

    def delta_p(self) -> float:
        """δ(P): Índice de Pulsación normalizado [0-100]. Energía cardíaca relativa."""
        sdnn = self.sdnn()
        return min(100.0, (sdnn / 150.0) * 100.0)

    # ── M2: DFA-α1 (Detrended Fluctuation Analysis) ───────────────────────
    def dfa_alpha1(self) -> float:
        """
        Estimación local de DFA-α1 para escalas 4-16 latidos.
        Implementación sin NumPy. Referencia: Bigger et al. (1992).
        Valor normal en reposo: ~1.0 ± 0.15 (señal con correlaciones)
        DFA → 0.5: ruido blanco (pérdida de complejidad cardíaca)
        DFA → 1.5: ruido marrón (oversmooting — posible fallo sensor)
        """
        rr = list(self._rr)
        if len(rr) < 32:
            return 1.0   # insuficientes datos — retorna nominal

        # Profile (integral de RR) centrado
        mu = sum(rr) / len(rr)
        profile = []
        acc = 0.0
        for v in rr:
            acc += v - mu
            profile.append(acc)

        scales = [4, 8, 12, 16]
        fluctuations = []
        for s in scales:
            segments = len(profile) // s
            if segments < 1:
                continue
            f2_sum = 0.0
            for seg in range(segments):
                chunk = profile[seg*s:(seg+1)*s]
                # Ajuste lineal (mínimos cuadrados)
                n   = len(chunk)
                xi  = list(range(n))
                mx  = sum(xi) / n
                my  = sum(chunk) / n
                num = sum((xi[i] - mx) * (chunk[i] - my) for i in range(n))
                den = sum((xi[i] - mx)**2 for i in range(n))
                b   = num / den if den != 0 else 0
                a   = my - b * mx
                residuals = [(chunk[i] - (a + b*xi[i]))**2 for i in range(n)]
                f2_sum += sum(residuals) / n
            fluctuations.append((s, (f2_sum / segments)**0.5))

        if len(fluctuations) < 2:
            return 1.0

        # Log-log regression
        log_s = [math.log(f[0]) for f in fluctuations]
        log_f = [math.log(max(f[1], 1e-9)) for f in fluctuations]
        n     = len(log_s)
        mx, my = sum(log_s)/n, sum(log_f)/n
        num   = sum((log_s[i]-mx)*(log_f[i]-my) for i in range(n))
        den   = sum((log_s[i]-mx)**2 for i in range(n))
        alpha = num / den if den != 0 else 1.0
        return round(max(0.3, min(2.0, alpha)), 4)

    # ── M4: Trend Detector (fatiga por pendiente BPM) ─────────────────────
    def bpm_trend(self) -> float:
        """
        Pendiente de BPM en últimos 60 valores (bpm/min).
        Positivo = taquicardia emergente. Negativo = bradicardia emergente.
        """
        hist = list(self._bpm_history)
        if len(hist) < 10:
            return 0.0
        n  = len(hist)
        xi = list(range(n))
        mx = sum(xi) / n
        my = sum(hist) / n
        num = sum((xi[i]-mx)*(hist[i]-my) for i in range(n))
        den = sum((xi[i]-mx)**2 for i in range(n))
        return round(num / den if den != 0 else 0.0, 4)

    # ── ReAct Reasoning Loop (Wei et al. 2022 / Yao et al. 2023) ─────────
    def react_reason(self, sensor_trust: float) -> List[Dict]:
        """
        Cadena de razonamiento paso a paso sobre el estado cardíaco.
        Genera una secuencia de (OBSERVE → THINK → ACT) sobre la señal.
        No usa LLM: razonamiento determinista sobre reglas fisiológicas.
        Salida: lista de hallazgos ordenados por severidad.
        """
        bpm   = self.bpm()
        rmssd = self.rmssd()
        sdnn  = self.sdnn()
        dfa   = self.dfa_alpha1()
        trend = self.bpm_trend()
        findings: List[Dict] = []

        # ── Paso 1: OBSERVE — Sensor fiable? ─────────────────────────────
        if sensor_trust < 0.5:
            findings.append({
                "step": "OBSERVE",
                "severity": "CRITICAL",
                "code": "SENSOR_DEGRADED",
                "msg": f"Sensor trust {sensor_trust:.2f} < 0.50. "
                       f"Datos no confiables. Citar: Strickland (2019) "
                       f"IBM Watson — confianza ciega en sensor destruye el modelo.",
                "action": "SUSPEND_INFERENCE",
            })
            return findings   # sin datos fiables, stop

        # ── Paso 2: THINK — Anomalías de Capa 0 ──────────────────────────
        if bpm > self.ALERT_BPM_HIGH:
            findings.append({
                "step": "THINK",
                "severity": "HIGH",
                "code": "TACHYCARDIA",
                "msg": f"BPM={bpm:.0f} > {self.ALERT_BPM_HIGH}. "
                       f"Taquicardia activa. Posible estrés agudo o artefacto.",
                "action": "EMIT_ALERT_L0",
                "value": bpm,
            })
        if bpm > 0 and bpm < self.ALERT_BPM_LOW:
            findings.append({
                "step": "THINK",
                "severity": "HIGH",
                "code": "BRADYCARDIA",
                "msg": f"BPM={bpm:.0f} < {self.ALERT_BPM_LOW}. "
                       f"Bradicardia. Verificar colocación sensor.",
                "action": "EMIT_ALERT_L0",
                "value": bpm,
            })
        if rmssd > 0 and rmssd < self.ALERT_RMSSD_LOW:
            findings.append({
                "step": "THINK",
                "severity": "MEDIUM",
                "code": "LOW_HRV",
                "msg": f"RMSSD={rmssd:.1f} ms < {self.ALERT_RMSSD_LOW} ms. "
                       f"HRV deprimida — fatiga autonómica o estrés crónico.",
                "action": "LOG_FATIGUE",
                "value": rmssd,
            })
        if dfa < self.ALERT_DFA_LOW:
            findings.append({
                "step": "THINK",
                "severity": "HIGH",
                "code": "COMPLEXITY_LOSS",
                "msg": f"DFA-α1={dfa:.3f} < {self.ALERT_DFA_LOW}. "
                       f"Pérdida de complejidad fractal. Referencia: "
                       f"Bigger et al. (1992) — predictor de riesgo cardíaco.",
                "action": "EMIT_ALERT_L0",
                "value": dfa,
            })
        if dfa > self.ALERT_DFA_HIGH:
            findings.append({
                "step": "THINK",
                "severity": "MEDIUM",
                "code": "OVERSMOOTING_OR_ARTIFACT",
                "msg": f"DFA-α1={dfa:.3f} > {self.ALERT_DFA_HIGH}. "
                       f"Señal excesivamente suavizada. "
                       f"Ruido galvánico o presión inadecuada del electrodo.",
                "action": "REQUEST_SENSOR_CHECK",
                "value": dfa,
            })
        if abs(trend) > 0.5:
            direction = "ASCENDENTE" if trend > 0 else "DESCENDENTE"
            findings.append({
                "step": "THINK",
                "severity": "LOW",
                "code": f"BPM_TREND_{direction}",
                "msg": f"Tendencia BPM {direction}: {trend:+.3f} bpm/latido. "
                       f"Fatiga térmica emergente." if trend > 0 else
                       f"Tendencia BPM {direction}: {trend:+.3f} bpm/latido. "
                       f"Recuperación o bradicardia progresiva.",
                "action": "LOG_TREND",
                "value": trend,
            })

        # ── Paso 3: ACT — Estado nominal si sin hallazgos críticos ───────
        if not any(f["severity"] in ("HIGH","CRITICAL") for f in findings):
            findings.append({
                "step": "ACT",
                "severity": "OK",
                "code": "NOMINAL",
                "msg": f"Todos los indicadores dentro de rango fisiológico. "
                       f"BPM={bpm:.0f} RMSSD={rmssd:.1f} SDNN={sdnn:.1f} "
                       f"DFA={dfa:.3f} trust={sensor_trust:.2f}",
                "action": "CONTINUE",
            })

        return sorted(findings, key=lambda x: {
            "CRITICAL":0,"HIGH":1,"MEDIUM":2,"LOW":3,"OK":4
        }.get(x["severity"], 5))

    def summary(self) -> Dict:
        """Resumen de métricas actuales."""
        return {
            "bpm":      round(self.bpm(), 1),
            "rmssd":    round(self.rmssd(), 2),
            "sdnn":     round(self.sdnn(), 2),
            "dfa_a1":   self.dfa_alpha1(),
            "delta_p":  round(self.delta_p(), 2),
            "bpm_trend":self.bpm_trend(),
            "n_samples":len(self._rr),
        }


# ══════════════════════════════════════════════════════════════════════════════
#  CNS-05 · ZKP SOVEREIGNTY — Prueba de Veracidad sin Biometría Expuesta
#
#  El usuario no comparte BPM con nadie. Solo comparte:
#    Proof-of-Life:  Commitment(nonce || alive_bool)
#    Proof-of-Calm:  Commitment(nonce || calm_bool)   [RMSSD > umbral]
#    Proof-of-Cert:  Commitment(nonce || cert_epoch)  [timestamp relativo]
#
#  Basado en esquema de compromiso hash (Pedersen-like simplificado).
#  SIN ZKP criptográfico completo (requeriría zk-SNARKs) pero garantiza
#  que el tercero no puede invertir el hash sin el nonce secreto.
# ══════════════════════════════════════════════════════════════════════════════

class ZKPSovereignty:
    """
    Genera pruebas de propiedades cardíacas sin revelar los datos.
    El nonce maestro es efímero por sesión; rotado cada 300 s.
    """
    NONCE_ROTATION_SEC = 300

    def __init__(self):
        self._master_nonce: bytes = os.urandom(32)
        self._nonce_epoch:  float = time.monotonic()
        self._proof_counter: int  = 0

    def _rotate_if_needed(self):
        if time.monotonic() - self._nonce_epoch > self.NONCE_ROTATION_SEC:
            self._master_nonce = os.urandom(32)
            self._nonce_epoch  = time.monotonic()
            log.debug("🔑 ZKP nonce rotated")

    def _commit(self, value: bytes) -> str:
        """H(nonce || value) — Commitment scheme."""
        self._rotate_if_needed()
        payload = self._master_nonce + value
        return hashlib.sha256(payload).hexdigest()

    def _node_id(self) -> str:
        """ID rotativo correlación-resistente."""
        window = int(time.monotonic() / self.NONCE_ROTATION_SEC)
        return hashlib.sha256(
            self._master_nonce + window.to_bytes(8, 'big')
        ).hexdigest()[:16]

    def proof_of_life(self, alive: bool) -> Dict:
        """Nivel 0: Solo prueba de existencia vital. Cero biometría."""
        self._proof_counter += 1
        commit = self._commit(b'\x01' if alive else b'\x00')
        return {
            "level":    0,
            "protocol": "VIGIL_ZKP_V2",
            "proof":    commit,
            "alive":    alive,         # bool — no BPM
            "node_id":  self._node_id(),
            "seq":      self._proof_counter,
        }

    def proof_of_calm(self, alive: bool, rmssd: float, threshold: float = 20.0) -> Dict:
        """Nivel 1: Prueba de 'calma' (RMSSD > umbral) sin revelar RMSSD."""
        calm = rmssd > threshold and alive
        commit = self._commit(b'\x02' + (b'\x01' if calm else b'\x00'))
        return {
            "level":   1,
            "protocol":"VIGIL_ZKP_V2",
            "proof":   commit,
            "alive":   alive,
            "calm":    calm,           # bool — no RMSSD
            "node_id": self._node_id(),
            "seq":     self._proof_counter,
        }

    def proof_of_engineering(self, metrics: Dict, t_rel: float, contact: bool) -> Dict:
        """Nivel 2: Stream completo — solo localhost autorizado."""
        return {
            "level":    2,
            "protocol": "VIGIL_ZKP_V2",
            **metrics,
            "t_rel":    round(t_rel, 2),
            "contact":  contact,
            "node_id":  self._node_id(),
            "seq":      self._proof_counter,
        }


# ══════════════════════════════════════════════════════════════════════════════
#  CNS-06 · PHANTOM ENGINE — Señal Sintética Adversarial Perfecta
#  V1 usaba gaussiana simple. Un adversario entrenado detectaría la señal
#  sintética por falta de correlaciones temporales (DFA-α1 ≈ 0.5, ruido blanco).
#
#  V2 genera una señal AR(1) calibrada para imitar DFA-α1 ≈ 1.0 y RMSSD
#  plausible. El adversario recibe datos que pasan sus propios test de calidad.
#  "Si detectas un acceso no autorizado, alimenta al intruso con su propia
#  confianza." — Filosofía OMNI-VIGIL
# ══════════════════════════════════════════════════════════════════════════════

class PhantomEngine:
    """
    Genera señales cardíacas sintéticas de alta fidelidad para intrusos.
    AR(1) con φ=0.85 produce autocorrelación realista, DFA-α1 ≈ 0.95-1.05.
    """
    def __init__(self, seed_bpm: float = 68.0):
        self._phi = 0.82          # Coeficiente AR(1) — calibrado para DFA ≈ 1.0
        self._sigma = 35.0        # Ruido base (ms)
        self._mu = 60000.0 / seed_bpm   # RR medio inicial
        self._last_rr = self._mu
        self._counter = 0

    def next_rr(self) -> int:
        """Genera próximo RR sintético con propiedades estadísticas realistas."""
        noise = random.gauss(0, self._sigma)
        self._last_rr = self._phi * (self._last_rr - self._mu) + self._mu + noise
        self._last_rr = max(350.0, min(1800.0, self._last_rr))
        self._counter += 1
        # Drift lento para simular variaciones circadianas (no repite patrón)
        if self._counter % 50 == 0:
            self._mu += random.gauss(0, 5)
            self._mu = max(500.0, min(1100.0, self._mu))
        return int(self._last_rr)

    def generate_packet(self, client_id: str, level: int) -> Dict:
        rr = self.next_rr()
        bpm = round(60000.0 / rr, 1)
        # Métricas plausibles basadas en el RR sintético
        rmssd = round(random.gauss(35, 8), 2)
        sdnn  = round(random.gauss(50, 12), 2)
        dfa   = round(random.gauss(1.02, 0.06), 4)
        return {
            "level":    level,
            "phantom":  True,    # Flag interno — nunca expuesto al intruso
            "bpm":      bpm,
            "rmssd":    rmssd,
            "sdnn":     sdnn,
            "dfa_a1":   dfa,
            "delta_p":  round(min(100, sdnn / 150 * 100), 2),
            "t_rel":    round(time.monotonic() % 3600, 2),
            "contact":  True,
            "node_id":  hashlib.sha256(
                client_id.encode() + os.urandom(4)
            ).hexdigest()[:16],
        }


# ══════════════════════════════════════════════════════════════════════════════
#  CNS-07 · SOVEREIGN BRIDGE — Estado Compartido (Thread-Safe)
# ══════════════════════════════════════════════════════════════════════════════

class PolicyLevel(IntEnum):
    BLINDADO   = 0
    OPERATIVO  = 1
    INGENIERIA = 2

@dataclass
class ClientRecord:
    id:          str
    name:        str
    ip:          str
    level:       int = 0
    status:      str = "PENDING"          # PENDING | APPROVED | REJECTED | PHANTOM
    connected_at:float = field(default_factory=time.monotonic)
    pkts_sent:   int   = 0
    pkts_drop:   int   = 0
    challenge:   str   = ""
    challenge_ts:float = 0.0

class SharedState:
    """Estado global thread-safe del sistema CNS."""
    def __init__(self):
        self._lock        = asyncio.Lock()
        self.alive:  bool = False
        self.contact:bool = False
        self.t_start:float = time.monotonic()

        # Componentes
        self.sav       = AdaptiveSAVFilter()
        self.sensor_v  = SensorValidator()
        self.inference = EdgeInference()
        self.zkp       = ZKPSovereignty()
        self.phantom   = PhantomEngine()

        # Clientes
        self.clients:  Dict[str, ClientRecord] = {}
        self.websockets_data:    set = set()
        self.websockets_control: set = set()

        # Métricas de sesión
        self.pkt_rx:   int   = 0
        self.pkt_drop: int   = 0
        self.last_rr:  float = 0.0
        self.session_id: str = uuid.uuid4().hex[:12].upper()

        # HMAC master key (ephemeral)
        self._master_key: bytes = os.urandom(32)

    async def push_rr(self, rr_ms: int, recv_ts: float):
        async with self._lock:
            valid, reason = self.sav.validate(rr_ms)
            self.pkt_rx += 1
            if not valid:
                self.pkt_drop += 1
                return False, reason
            trust, flags = self.sensor_v.score(rr_ms, recv_ts)
            self.inference.push(float(rr_ms), recv_ts)
            self.alive   = True
            self.last_rr = float(rr_ms)
            return True, trust

    def sign_packet(self, client_id: str, payload: dict) -> dict:
        """Firma HMAC-SHA256 cada paquete saliente."""
        token = hmac.new(
            self._master_key,
            f"vigil:v2:{client_id}".encode(),
            hashlib.sha256
        ).digest()
        sig = hmac.new(
            token,
            json.dumps(payload, sort_keys=True).encode(),
            hashlib.sha256
        ).hexdigest()
        return {**payload, "_sig": sig[:16], "_v": 2}

    def elapsed(self) -> float:
        return time.monotonic() - self.t_start


S = SharedState()


# ══════════════════════════════════════════════════════════════════════════════
#  CNS-08 · FLIGHT RECORDER 2 — Journaling Cifrado con Audit Chain
# ══════════════════════════════════════════════════════════════════════════════

class FlightRecorder:
    """
    Buffer giratorio asíncrono con HMAC-linked entries.
    Cada entrada contiene el hash de la anterior — tampering es detectable.
    """
    def __init__(self, base_dir: str = "~/.omni_vigil"):
        self._dir = Path(base_dir).expanduser()
        self._dir.mkdir(parents=True, exist_ok=True)
        self._session = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        self._csv_path  = self._dir / f"session_{self._session}.csv"
        self._log_path  = self._dir / f"audit_{self._session}.jsonl"
        self._queue: asyncio.Queue = asyncio.Queue(maxsize=2048)
        self._last_hash = "GENESIS"
        self._key = os.urandom(32)

    def _chain_entry(self, data: dict) -> dict:
        """Encadena entrada al audit log con HMAC."""
        raw = json.dumps(data, sort_keys=True).encode()
        link = hmac.new(
            self._key,
            (self._last_hash + json.dumps(data, sort_keys=True)).encode(),
            hashlib.sha256
        ).hexdigest()[:16]
        data["_chain"] = link
        self._last_hash = link
        return data

    async def write_loop(self):
        with open(self._csv_path, 'w', newline='') as csv_f, \
             open(self._log_path, 'a') as log_f:
            writer = csv.writer(csv_f)
            writer.writerow(["ts_utc","bpm","rmssd","sdnn","dfa_a1",
                              "delta_p","trust","session"])
            while True:
                entry = await self._queue.get()
                if entry is None:
                    break
                try:
                    if entry.get("_type") == "METRIC":
                        writer.writerow([
                            entry.get("ts"), entry.get("bpm"),
                            entry.get("rmssd"), entry.get("sdnn"),
                            entry.get("dfa_a1"), entry.get("delta_p"),
                            entry.get("trust"), S.session_id
                        ])
                        csv_f.flush()
                    chained = self._chain_entry(entry)
                    log_f.write(json.dumps(chained) + "\n")
                    log_f.flush()
                except Exception as e:
                    log.error(f"FlightRecorder error: {e}")

    async def log_metric(self, ts: float, bpm: float, rmssd: float,
                         sdnn: float, dfa: float, delta_p: float, trust: float):
        entry = {
            "_type": "METRIC",
            "ts": round(ts, 3), "bpm": round(bpm, 1),
            "rmssd": round(rmssd, 2), "sdnn": round(sdnn, 2),
            "dfa_a1": dfa, "delta_p": round(delta_p, 2),
            "trust": round(trust, 3),
        }
        try:
            self._queue.put_nowait(entry)
        except asyncio.QueueFull:
            pass  # Never block on logging

    async def log_event(self, event_type: str, detail: dict):
        entry = {
            "_type": "EVENT",
            "ts": time.time(),
            "event": event_type,
            **detail,
        }
        try:
            self._queue.put_nowait(entry)
        except asyncio.QueueFull:
            pass


FR = FlightRecorder()


# ══════════════════════════════════════════════════════════════════════════════
#  BLE LAYER — Polar H10 Connection
# ══════════════════════════════════════════════════════════════════════════════

async def _hr_callback(sender, data: bytearray):
    flags  = data[0]
    if flags & 0x01:
        bpm = struct.unpack_from('<H', data, 1)[0]
    else:
        bpm = data[1]
    contact = bool(flags & 0x06)
    S.contact = contact
    if bpm > 0 and 20 < bpm < 250:
        rr_ms = int(60000 / bpm)
        ts = time.monotonic()
        ok, trust = await S.push_rr(rr_ms, ts)
        if ok:
            metrics = S.inference.summary()
            await FR.log_metric(
                ts, metrics["bpm"], metrics["rmssd"], metrics["sdnn"],
                metrics["dfa_a1"], metrics["delta_p"],
                S.sensor_v.mean_trust()
            )


async def ble_run(mode: str = "web"):
    if not BLEAK_OK:
        log.error("bleak not installed — BLE unavailable")
        return

    log.info("🔎 Scanning for Polar H10...")
    devices = await BleakScanner.discover(timeout=8.0)
    polar = next(
        (d for d in devices if d.name and "Polar H10" in d.name), None
    )
    if not polar:
        log.warning("⚠️  Polar H10 not found. Running in simulation mode.")
        await _simulate_ble()
        return

    log.info(f"✅ Found: {polar.name} ({polar.address})")
    async with BleakClient(polar.address) as client:
        await client.start_notify(HR_UUID, _hr_callback)
        try:
            await client.write_gatt_char(PMD_CTRL, ECG_START)
        except Exception:
            pass
        log.info("💓 Streaming HR from Polar H10...")
        await asyncio.sleep(float('inf'))


async def _simulate_ble():
    """Simulador Polar H10 con AR(1) para testing sin hardware."""
    log.info("🛸 Simulation mode active — synthetic AR(1) signal")
    phi, mu, sigma = 0.85, 780.0, 40.0
    last = mu
    while True:
        noise = random.gauss(0, sigma)
        last  = phi * (last - mu) + mu + noise
        last  = max(350, min(1800, last))
        rr_ms = int(last)
        ts    = time.monotonic()
        ok, trust = await S.push_rr(rr_ms, ts)
        if ok:
            metrics = S.inference.summary()
            await FR.log_metric(
                ts, metrics["bpm"], metrics["rmssd"], metrics["sdnn"],
                metrics["dfa_a1"], metrics["delta_p"], trust if isinstance(trust, float) else 0.9
            )
        await asyncio.sleep(random.uniform(0.7, 1.1))


# ══════════════════════════════════════════════════════════════════════════════
#  WEBSOCKET SERVERS
# ══════════════════════════════════════════════════════════════════════════════

async def _vigil_challenge(ws, client_id: str) -> bool:
    """Challenge-Response VIGIL V2."""
    challenge = hashlib.sha256(os.urandom(32)).hexdigest()[:32]
    cr = S.clients.get(client_id)
    if cr:
        cr.challenge    = challenge
        cr.challenge_ts = time.monotonic()
    await ws.send(json.dumps({
        "type":      "CHALLENGE",
        "challenge": challenge,
        "session":   S.session_id,
        "version":   2,
    }))
    return True


async def vigil_data_server(host: str = "0.0.0.0", port: int = 8765):
    if not WS_OK:
        log.error("websockets not installed")
        return

    async def handler(ws):
        client_id = uuid.uuid4().hex[:8].upper()
        ip = ws.remote_address[0] if ws.remote_address else "0.0.0.0"
        name = f"CLIENT_{client_id}"

        record = ClientRecord(id=client_id, name=name, ip=ip)
        S.clients[client_id] = record
        S.websockets_data.add(ws)
        log.info(f"🔌 [{client_id}] connected from {ip}")

        await _vigil_challenge(ws, client_id)

        try:
            while True:
                await asyncio.sleep(1.0)
                async with S._lock:
                    cr = S.clients.get(client_id)
                    if not cr:
                        break

                    metrics = S.inference.summary()
                    trust   = S.sensor_v.mean_trust()
                    t_rel   = S.elapsed()

                    # Determinar payload según nivel y estado
                    if cr.status == "REJECTED":
                        payload = S.phantom.generate_packet(client_id, cr.level)
                    elif cr.status != "APPROVED":
                        payload = {"type": "AWAITING_APPROVAL", "client_id": client_id}
                    elif cr.level == PolicyLevel.BLINDADO:
                        payload = S.zkp.proof_of_life(S.alive)
                    elif cr.level == PolicyLevel.OPERATIVO:
                        payload = S.zkp.proof_of_calm(S.alive, metrics["rmssd"])
                    else:
                        # INGENIERIA — solo localhost
                        if ip not in ("127.0.0.1", "::1", "localhost"):
                            payload = S.phantom.generate_packet(client_id, 1)
                            cr.status = "PHANTOM"
                            log.warning(f"🔴 [{client_id}] L2 from non-local IP → phantom")
                        else:
                            payload = S.zkp.proof_of_engineering(
                                metrics, t_rel, S.contact
                            )
                            # Inyecta hallazgos ReAct
                            findings = S.inference.react_reason(trust)
                            payload["react"] = findings[:3]  # Top 3

                    # Adjuntar metadatos de sesión
                    payload["_session"]   = S.session_id
                    payload["_sensor_ok"] = not S.sensor_v.circuit_open
                    payload = S.sign_packet(client_id, payload)

                    try:
                        await ws.send(json.dumps(payload))
                        cr.pkts_sent += 1
                    except Exception:
                        break

        except Exception as e:
            log.error(f"[{client_id}] error: {e}")
        finally:
            S.websockets_data.discard(ws)
            if client_id in S.clients:
                del S.clients[client_id]
            log.info(f"🔌 [{client_id}] disconnected")

    log.info(f"🛰️  VIGIL DATA SERVER  ws://{host}:{port}")
    async with websockets.serve(handler, host, port):
        await asyncio.Future()


async def vigil_control_server(host: str = "0.0.0.0", port: int = 8766):
    if not WS_OK:
        return

    async def handler(ws):
        ip = ws.remote_address[0] if ws.remote_address else "unknown"
        if ip not in ("127.0.0.1", "::1"):
            log.warning(f"❌ Control attempt from non-local {ip} — rejected")
            await ws.close()
            return

        S.websockets_control.add(ws)
        log.info(f"🎛️  Control panel connected from {ip}")

        async def push_status():
            while True:
                try:
                    metrics = S.inference.summary()
                    trust   = S.sensor_v.mean_trust()
                    findings = S.inference.react_reason(trust)
                    status = {
                        "type":       "STATUS",
                        "session":    S.session_id,
                        "alive":      S.alive,
                        "contact":    S.contact,
                        "metrics":    metrics,
                        "sensor":     {
                            "trust":   round(trust, 3),
                            "circuit": S.sensor_v.circuit_open,
                            "faults":  S.sensor_v.fault_log[-3:],
                        },
                        "clients":    [
                            {
                                "id":     c.id,
                                "name":   c.name,
                                "ip":     c.ip,
                                "level":  c.level,
                                "status": c.status,
                                "pkts":   c.pkts_sent,
                            }
                            for c in S.clients.values()
                        ],
                        "react":      findings[:5],
                        "pkt_rx":     S.pkt_rx,
                        "pkt_drop":   S.pkt_drop,
                        "elapsed":    round(S.elapsed(), 1),
                        "drop_pct":   round(
                            100 * S.pkt_drop / max(1, S.pkt_rx), 2
                        ),
                    }
                    await ws.send(json.dumps(status))
                    await asyncio.sleep(0.8)
                except Exception:
                    break

        asyncio.create_task(push_status())

        try:
            async for raw in ws:
                try:
                    cmd = json.loads(raw)
                    await _handle_control_command(cmd)
                except json.JSONDecodeError:
                    pass
        except Exception:
            pass
        finally:
            S.websockets_control.discard(ws)

    log.info(f"🎛️  VIGIL CONTROL SERVER ws://{host}:{port}")
    async with websockets.serve(handler, host, port):
        await asyncio.Future()


async def _handle_control_command(cmd: dict):
    """Procesa comandos del panel de control."""
    action = cmd.get("action")
    client_id = cmd.get("client_id")

    if action == "APPROVE" and client_id in S.clients:
        S.clients[client_id].status = "APPROVED"
        log.info(f"✅ APPROVED [{client_id}]")
        await FR.log_event("APPROVE", {"client": client_id})

    elif action == "REJECT" and client_id in S.clients:
        S.clients[client_id].status = "REJECTED"
        log.warning(f"🔴 REJECTED [{client_id}] → phantom mode")
        await FR.log_event("REJECT", {"client": client_id})

    elif action == "SET_LEVEL" and client_id in S.clients:
        level = int(cmd.get("level", 0))
        if level in (0, 1, 2):
            S.clients[client_id].level = level
            log.info(f"⚙️  [{client_id}] level → {level}")
            await FR.log_event("SET_LEVEL", {"client": client_id, "level": level})

    elif action == "KILL" and client_id in S.clients:
        del S.clients[client_id]
        log.warning(f"💀 KILLED [{client_id}]")
        await FR.log_event("KILL", {"client": client_id})

    elif action == "RESET_SENSOR":
        S.sensor_v._low_trust_run = 0
        S.sensor_v.circuit_open   = False
        log.info("🔄 Sensor circuit breaker reset by operator")


# ══════════════════════════════════════════════════════════════════════════════
#  ENTRY POINT
# ══════════════════════════════════════════════════════════════════════════════

def parse_args():
    p = argparse.ArgumentParser(description="OMNI-VIGIL SOBERANO v2.0")
    p.add_argument("--web",      action="store_true",
                   help="Start WebSocket servers (VIGIL data + control)")
    p.add_argument("--simulate", action="store_true",
                   help="Simulate Polar H10 (no hardware needed)")
    p.add_argument("--data-port",    type=int, default=8765)
    p.add_argument("--control-port", type=int, default=8766)
    return p.parse_args()


async def _main_web(simulate: bool, data_port: int, control_port: int):
    log.info("""
    ╔══════════════════════════════════════════════════════════╗
    ║   OMNI-VIGIL SOBERANO v2.0                             ║
    ║   Central Nervous System — Online                       ║
    ║   Session: %-12s                              ║
    ╚══════════════════════════════════════════════════════════╝
    """ % S.session_id)

    ble_task = _simulate_ble() if simulate else ble_run("web")

    await asyncio.gather(
        ble_task,
        vigil_data_server(port=data_port),
        vigil_control_server(port=control_port),
        FR.write_loop(),
    )


def main():
    args = parse_args()

    if args.web or args.simulate:
        try:
            asyncio.run(_main_web(
                args.simulate or not BLEAK_OK,
                args.data_port,
                args.control_port,
            ))
        except KeyboardInterrupt:
            log.info("⏹️  CNS shutdown — session archived")
    else:
        print("OMNI-VIGIL SOBERANO v2.0 — use --web or --web --simulate")


if __name__ == "__main__":
    main()
