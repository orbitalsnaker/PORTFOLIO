#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════════════
#  OMNI-VIGIL SOBERANO v2.0 — setup_v2.sh
#  Despliegue con entorno aislado de alta seguridad
#  Compatible: Linux · macOS · WSL2
# ══════════════════════════════════════════════════════════════════════════════

set -euo pipefail

# ── Colores ──────────────────────────────────────────────────────────────────
R="\033[0;31m" G="\033[0;32m" Y="\033[0;33m"
C="\033[0;36m" D="\033[2m"    N="\033[0m"

log()  { echo -e "${C}[CNS]${N} $*"; }
ok()   { echo -e "${G}[OK] ${N} $*"; }
warn() { echo -e "${Y}[WARN]${N} $*"; }
fail() { echo -e "${R}[FAIL]${N} $*"; exit 1; }

echo -e "${C}"
cat << 'EOF'
╔══════════════════════════════════════════════════════════════════╗
║   OMNI-VIGIL SOBERANO v2.0 — SETUP                             ║
║   Entorno Aislado · Alta Seguridad · Sin Nube                  ║
║   pulse_skeleton_v02.py ha sido archivado. Sin piedad.         ║
╚══════════════════════════════════════════════════════════════════╝
EOF
echo -e "${N}"

# ── Detectar SO ───────────────────────────────────────────────────────────────
detect_os() {
  if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    # Distingue WSL2 de Linux nativo
    if grep -qi microsoft /proc/version 2>/dev/null; then
      echo "wsl2"
    else
      echo "linux"
    fi
  elif [[ "$OSTYPE" == "darwin"* ]]; then
    echo "macos"
  elif [[ "$OSTYPE" == "msys" || "$OSTYPE" == "cygwin" ]]; then
    echo "windows"
  else
    echo "unknown"
  fi
}

OS=$(detect_os)
log "Sistema detectado: $OS"

# ── Verificar Python ──────────────────────────────────────────────────────────
if ! command -v python3 &>/dev/null; then
  fail "Python 3 no encontrado. Instala Python 3.9+"
fi

PY_VER=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
PY_MAJOR=$(python3 -c 'import sys; print(sys.version_info.major)')
PY_MINOR=$(python3 -c 'import sys; print(sys.version_info.minor)')

if [[ "$PY_MAJOR" -lt 3 || ("$PY_MAJOR" -eq 3 && "$PY_MINOR" -lt 9) ]]; then
  fail "Python $PY_VER detectado. Se requiere Python 3.9+."
fi
ok "Python $PY_VER"

# ── Directorio de instalación ─────────────────────────────────────────────────
INSTALL_DIR="${HOME}/.omni_vigil_install"
DATA_DIR="${HOME}/.omni_vigil"
log "Directorio de instalación: $INSTALL_DIR"
log "Directorio de datos (Flight Recorder): $DATA_DIR"

mkdir -p "$INSTALL_DIR" "$DATA_DIR"

# Copiar archivos al directorio de instalación
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
log "Copiando archivos desde $SCRIPT_DIR..."
cp "$SCRIPT_DIR/core_v2.py"            "$INSTALL_DIR/"
cp "$SCRIPT_DIR/sovereign_ui_v2.html"  "$INSTALL_DIR/"
cp "$SCRIPT_DIR/requirements_v2.txt"   "$INSTALL_DIR/"
cp "$SCRIPT_DIR/vigil_v2_protocol.md"  "$INSTALL_DIR/"
ok "Archivos copiados"

# ── Entorno Virtual Aislado ───────────────────────────────────────────────────
VENV_DIR="$INSTALL_DIR/venv"

if [[ -d "$VENV_DIR" ]]; then
  warn "Entorno virtual existente detectado en $VENV_DIR"
  read -r -p "  ¿Recrear entorno limpio? [y/N] " REPLY
  if [[ "$REPLY" =~ ^[Yy]$ ]]; then
    log "Eliminando entorno anterior..."
    rm -rf "$VENV_DIR"
  fi
fi

if [[ ! -d "$VENV_DIR" ]]; then
  log "Creando entorno virtual aislado..."
  python3 -m venv "$VENV_DIR"
  ok "Entorno virtual creado"
fi

# Activar venv
if [[ "$OS" == "windows" ]]; then
  ACTIVATE="$VENV_DIR/Scripts/activate"
else
  ACTIVATE="$VENV_DIR/bin/activate"
fi

# shellcheck disable=SC1090
source "$ACTIVATE"
ok "Entorno virtual activado"

# ── Instalar dependencias ─────────────────────────────────────────────────────
log "Actualizando pip..."
pip install --quiet --upgrade pip setuptools wheel

log "Instalando stack mínimo (siempre requerido)..."
pip install --quiet bleak websockets flask flask-cors cryptography

log "Instalando stack de inferencia edge (numpy + scipy)..."
if pip install --quiet numpy scipy; then
  ok "NumPy + SciPy instalados (DFA-α1 acelerado por BLAS)"
else
  warn "NumPy/SciPy no disponibles — usando DFA-α1 en Python puro (más lento)"
fi

ok "Dependencias instaladas"

# ── Permisos BLE (Linux) ──────────────────────────────────────────────────────
if [[ "$OS" == "linux" || "$OS" == "wsl2" ]]; then
  log "Verificando permisos BLE..."
  if python3 -c "import bleak" 2>/dev/null; then
    # Intentar dar capabilities al ejecutable Python para BLE sin root
    PYTHON_BIN="$VENV_DIR/bin/python3"
    if command -v setcap &>/dev/null; then
      if setcap 'cap_net_raw,cap_net_admin+eip' "$PYTHON_BIN" 2>/dev/null; then
        ok "Permisos BLE (cap_net_raw) asignados a Python del venv"
      else
        warn "No se pudieron asignar capabilities BLE."
        warn "Para conectar Polar H10, ejecuta con: sudo python core_v2.py --web"
        warn "O añade tu usuario al grupo 'bluetooth': sudo usermod -aG bluetooth \$USER"
      fi
    else
      warn "setcap no disponible. Puede requerirse sudo para BLE."
    fi
  fi

  if [[ "$OS" == "wsl2" ]]; then
    warn "WSL2 detectado: BLE solo funciona con usbipd-win + Bluetooth USB passthrough."
    warn "Usa --simulate para testing sin hardware: python core_v2.py --web --simulate"
  fi
fi

# ── macOS BLE info ────────────────────────────────────────────────────────────
if [[ "$OS" == "macos" ]]; then
  log "macOS: BLE disponible via CoreBluetooth (bleak). Sin configuración extra."
  # Verifica que Bluetooth esté activo
  if system_profiler SPBluetoothDataType 2>/dev/null | grep -q "State: On"; then
    ok "Bluetooth activo"
  else
    warn "Bluetooth parece inactivo. Actívalo en Preferencias del Sistema."
  fi
fi

# ── Crear launcher ────────────────────────────────────────────────────────────
LAUNCHER="$INSTALL_DIR/start_vigil.sh"
cat > "$LAUNCHER" << LAUNCH
#!/usr/bin/env bash
# OMNI-VIGIL SOBERANO v2.0 — Launcher
set -euo pipefail
cd "${INSTALL_DIR}"
source "${ACTIVATE}"

MODE="\${1:---web --simulate}"
echo "🛰️  Iniciando OMNI-VIGIL SOBERANO v2.0..."
echo "   Modo: \$MODE"
echo "   UI:  http://localhost:8765 (abrir sovereign_ui_v2.html en navegador)"
echo "   Control: ws://localhost:8766"
echo ""

# Servir la UI con Python http.server en background (puerto 9000)
python3 -m http.server 9000 --directory "${INSTALL_DIR}" &
HTTP_PID=\$!
echo "   UI Server: http://localhost:9000/sovereign_ui_v2.html"
echo ""

# Lanzar CNS
python3 "${INSTALL_DIR}/core_v2.py" \$MODE

# Cleanup
kill \$HTTP_PID 2>/dev/null || true
LAUNCH

chmod +x "$LAUNCHER"
ok "Launcher creado: $LAUNCHER"

# ── Crear alias opcional ──────────────────────────────────────────────────────
SHELL_RC=""
if [[ -f "$HOME/.zshrc" ]]; then
  SHELL_RC="$HOME/.zshrc"
elif [[ -f "$HOME/.bashrc" ]]; then
  SHELL_RC="$HOME/.bashrc"
fi

if [[ -n "$SHELL_RC" ]]; then
  if ! grep -q "omni_vigil" "$SHELL_RC"; then
    echo "" >> "$SHELL_RC"
    echo "# OMNI-VIGIL SOBERANO v2.0" >> "$SHELL_RC"
    echo "alias vigil='bash ${LAUNCHER}'" >> "$SHELL_RC"
    echo "alias vigil-sim='bash ${LAUNCHER} --web --simulate'" >> "$SHELL_RC"
    ok "Aliases añadidos a $SHELL_RC (vigil / vigil-sim)"
    warn "Recarga tu shell: source $SHELL_RC"
  fi
fi

# ── Verificación final ────────────────────────────────────────────────────────
log "Verificando instalación..."

python3 -c "import asyncio, hashlib, hmac, json, uuid, math; print('stdlib OK')" && ok "stdlib OK"
python3 -c "import bleak" 2>/dev/null      && ok "bleak OK"     || warn "bleak: no disponible"
python3 -c "import websockets" 2>/dev/null && ok "websockets OK" || warn "websockets: instala manualmente"
python3 -c "import flask" 2>/dev/null      && ok "Flask OK"      || warn "Flask: instala manualmente"
python3 -c "import cryptography" 2>/dev/null && ok "cryptography OK" || warn "cryptography: instala manualmente"
python3 -c "import numpy" 2>/dev/null      && ok "NumPy OK"      || warn "NumPy: edge ML en Python puro"

# ── Resumen ───────────────────────────────────────────────────────────────────
echo ""
echo -e "${C}══════════════════════════════════════════════════════════════${N}"
echo -e "${G}  OMNI-VIGIL SOBERANO v2.0 — INSTALACIÓN COMPLETADA${N}"
echo -e "${C}══════════════════════════════════════════════════════════════${N}"
echo ""
echo -e "  ${D}Directorio:${N}  $INSTALL_DIR"
echo -e "  ${D}Datos:${N}       $DATA_DIR"
echo ""
echo -e "  ${G}OPCIÓN 1 — Con Polar H10 real:${N}"
echo -e "    bash $LAUNCHER --web"
echo ""
echo -e "  ${G}OPCIÓN 2 — Simulación (sin hardware):${N}"
echo -e "    bash $LAUNCHER --web --simulate"
echo ""
echo -e "  ${G}OPCIÓN 3 — Alias (tras recargar shell):${N}"
echo -e "    vigil-sim"
echo ""
echo -e "  ${D}Abre en navegador:${N}"
echo -e "    http://localhost:9000/sovereign_ui_v2.html"
echo ""
echo -e "  ${D}Tecla T${N} = Modo Táctico (solo anomalías críticas)"
echo ""
echo -e "${C}  V1 archivada. CNS online. Soberanía activa.${N}"
echo ""
echo -e "  Zehahahaha · Tic, Tac"
echo ""
