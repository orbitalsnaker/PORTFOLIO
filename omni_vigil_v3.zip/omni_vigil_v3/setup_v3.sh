#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════
#  OMNI-VIGIL SOBERANO v3.0 — setup_v3.sh
#  Despliegue con entorno aislado. Sin nube. Sin dependencias externas.
#  Agencia RONIN · División I+D Capa -1
# ═══════════════════════════════════════════════════════════════

set -euo pipefail

VENV_DIR=".venv_vigil_v3"
PYTHON=python3

echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║   OMNI-VIGIL SOBERANO v3.0 — SETUP                    ║"
echo "║   Agencia RONIN · División I+D Capa -1                 ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""

# ── 1. Python check ──────────────────────────────────────────
if ! command -v $PYTHON &>/dev/null; then
  echo "[ERROR] python3 no encontrado. Instala Python 3.10+"
  exit 1
fi

PY_VER=$($PYTHON -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
echo "[✓] Python $PY_VER detectado"

# ── 2. Entorno virtual ────────────────────────────────────────
if [ ! -d "$VENV_DIR" ]; then
  echo "[*] Creando entorno virtual $VENV_DIR..."
  $PYTHON -m venv "$VENV_DIR"
fi

source "$VENV_DIR/bin/activate"
echo "[✓] Entorno virtual activo: $VENV_DIR"

# ── 3. Dependencias ───────────────────────────────────────────
echo "[*] Instalando dependencias V3..."
pip install --quiet --upgrade pip
pip install --quiet -r requirements_v3.txt
echo "[✓] Dependencias instaladas"

# ── 4. Directorio de datos ────────────────────────────────────
mkdir -p ~/.omni_vigil
echo "[✓] Directorio de datos: ~/.omni_vigil"

# ── 5. Permisos BLE (Linux) ───────────────────────────────────
if [[ "$OSTYPE" == "linux-gnu"* ]]; then
  echo ""
  echo "[*] Linux detectado — configurando permisos BLE..."
  if command -v setcap &>/dev/null; then
    PYTHON_BIN=$(which python3)
    sudo setcap 'cap_net_raw,cap_net_admin+eip' "$PYTHON_BIN" 2>/dev/null || \
      echo "[!] setcap fallido — puede requerirse: sudo setcap 'cap_net_raw,cap_net_admin+eip' $(which python3)"
  else
    echo "[!] setcap no disponible — BLE puede requerir sudo"
  fi
fi

# ── 6. Verificación rápida de módulos V3 ──────────────────────
echo ""
echo "[*] Verificando módulos CNS V3..."
$PYTHON -c "
import sys
mods = ['asyncio','hashlib','hmac','json','math','collections','dataclasses']
v3_new = ['Transfer Entropy (Python puro)', 'RSA Circuit Breaker', 'P-CoT Reasoner']
for m in mods:
    try:
        __import__(m)
        print(f'  [✓] {m}')
    except ImportError:
        print(f'  [✗] {m} FALTANTE', file=sys.stderr)
print()
print('  [★] Módulos V3 (sin deps externas):')
for v in v3_new:
    print(f'      [✓] {v}')

# Opcionales
for m in ['bleak','websockets','numpy','scipy','cryptography']:
    try:
        __import__(m)
        print(f'  [✓] {m} (opcional)')
    except ImportError:
        print(f'  [~] {m} no disponible — funcionalidad reducida')
"

echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║   SETUP COMPLETO                                        ║"
echo "╠══════════════════════════════════════════════════════════╣"
echo "║   MODO HARDWARE:                                        ║"
echo "║     source $VENV_DIR/bin/activate                      ║"
echo "║     python core_v3.py --web                            ║"
echo "║                                                         ║"
echo "║   MODO SIMULACIÓN (sin Polar H10):                     ║"
echo "║     python core_v3.py --web --simulate                 ║"
echo "║                                                         ║"
echo "║   UI: abrir sovereign_ui_v3.html en browser            ║"
echo "║   DATA:    ws://0.0.0.0:8765                          ║"
echo "║   CONTROL: ws://127.0.0.1:8766                        ║"
echo "╠══════════════════════════════════════════════════════════╣"
echo "║   MÓDULOS V3 ACTIVOS:                                  ║"
echo "║   [★] CNS-09 P-CoT: SENSE→DOUBT→WEIGH→COMMIT→ACT     ║"
echo "║   [★] CNS-04 RSA Circuit Breaker (Szymański 2026)     ║"
echo "║   [★] CNS-03 Transfer Entropy Causal (biorxiv 2025)   ║"
echo "║   [★] CNS-05 ZKP Recursive Commitments (arXiv 2025)   ║"
echo "║   [★] CNS-06 Phantom Stego + Lyapunov Chaos           ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""
echo "  Agencia RONIN · División I+D Capa -1"
echo ""
