# OMNI-VIGIL SOBERANO v3.0 — MANIFIESTO TÉCNICO
## Protocolo VIGIL V3 · Declaración de Obsolescencia de la V2

---

> "La V2 *pensaba* sobre la señal.
>  La V3 *duda* de ella.
>  La diferencia es la misma que entre un detective y un juez."
>
> **— Agencia RONIN · Orden de Purga Técnica 2026**

---

## I. DECLARACIÓN DE OBSOLESCENCIA

`core_v2.py` queda **ARCHIVADO** por las siguientes deficiencias de diseño:

| Defecto V2 | Impacto | Resolución V3 |
|---|---|---|
| ReAct Loop determinista (binario) | No modela incertidumbre. Falso positivo = parada total. | P-CoT: razonamiento probabilístico con distribución de creencias y umbral de duda |
| PhantomEngine sin firma | Un adversario inteligente puede destilar el patrón AR(1) y replicarlo limpio | PhantomEngine V3: firma esteganográfica en jitter de ms — la copia lleva tu marca |
| SensorValidator sin RSA | Varianza no colapsa en señal playback de alta calidad | RSA Circuit Breaker: si la señal es "demasiado viva" sin respiración acoplada, es falsa |
| ZKP: commitment simple SHA-256 | Sin prueba de continuidad temporal entre pruebas | ZKP Recursive: cadena de commitments enlazados — cada prueba certifica la anterior |
| Sin análisis de causalidad | No puede distinguir pulso real de inyección sintética sincronizada | Transfer Entropy Causal: TE(RESP→RR) ≠ 0 solo en organismos vivos |
| Phantom sin adversarial hardening | Adversario con 5 min de datos puede entrenar contra el AR(1) | Phantom V3: modulación caótica de φ por Lyapunov local — no convergente |

---

## II. NUEVA ARQUITECTURA CNS V3

```
┌──────────────────────────────────────────────────────────────────┐
│  POLAR H10 (BLE 4.2)                                            │
│  HR (0x2A37) · ECG PMD (FB005C82)                               │
└───────────────────────────────┬──────────────────────────────────┘
                                │
                                ▼
              ┌─────────────────────────────────┐
              │  CNS-01 · PERCEPTION LAYER      │
              │  AdaptiveSAVFilter V3           │
              │  · umbral = μ ± 3.5σ personal   │
              │  · Detecta micro-artefactos BLE  │
              └──────────────┬──────────────────┘
                             │
              ┌──────────────▼──────────────────┐
              │  CNS-04 · SENSOR VALIDATOR V3   │
              │  Trust score [0,1] por paquete  │
              │  · Gap temporal                 │
              │  · Deriva de media corto plazo  │
              │  · Variance collapse detection  │
              │  ★ RSA Circuit Breaker (NUEVO)  │
              │    Si señal es "demasiado        │
              │    perfecta" → BLOQUEAR         │
              │  · Circuit breaker (10 pkts)    │
              └──────────────┬──────────────────┘
                             │
              ┌──────────────▼──────────────────────────────┐
              │  CNS-03 · EDGE INFERENCE V3                 │
              │  Buffer de Conciencia                       │
              │  · RMSSD, SDNN, DFA-α1 (local)             │
              │  ★ Transfer Entropy TE(RESP→RR) (NUEVO)    │
              │    Detecta acoplamiento causal              │
              │    Señal sintética → TE ≈ 0               │
              └──────────────┬──────────────────────────────┘
                             │
              ┌──────────────▼──────────────────────────────┐
              │  ★ CNS-09 · P-CoT COGNITIVO (NUEVO)        │
              │  Probabilistic Chain-of-Thought             │
              │                                             │
              │  SENSE → DOUBT → WEIGH → COMMIT → ACT      │
              │                                             │
              │  Cada paso emite (belief, confidence)       │
              │  Si H(beliefs) > entropy_threshold: DUDA    │
              │  No actúa hasta que P(causa) > 0.72         │
              └──────────────┬──────────────────────────────┘
                             │
         ┌───────────────────┴───────────────────┐
         │                                        │
         ▼                                        ▼
┌─────────────────────┐               ┌──────────────────────┐
│ CNS-05 · ZKP V3     │               │ ★ CNS-06 · PHANTOM   │
│ RECURSIVE COMMIT    │               │  ENGINE V3           │
│                     │               │                      │
│ chain[n] = H(nonce  │               │ AR(1) con φ variable │
│   ‖ proof[n-1]      │               │ Lyapunov modulation  │
│   ‖ bool)           │               │ JITTER STEGO MARK    │
│ Continuidad temporal│               │ Anti-distilación     │
│ verificable         │               │ caótica             │
└─────────────────────┘               └──────────────────────┘
         │                                        │
         └───────────────────┬───────────────────┘
                             │
              ┌──────────────▼──────────────────┐
              │  CNS-07 · SOVEREIGN BRIDGE V3   │
              │  ws://0.0.0.0:8765 (DATA)       │
              │  ws://127.0.0.1:8766 (CONTROL)  │
              │  HMAC-SHA256 por paquete        │
              │  Challenge-Response VIGIL V3    │
              └──────────────┬──────────────────┘
                             │
              ┌──────────────▼──────────────────┐
              │  CNS-08 · FLIGHT RECORDER 3     │
              │  HMAC-linked audit chain        │
              │  + P-CoT belief log             │
              │  + TE causal log                │
              │  ~/.omni_vigil/                 │
              └─────────────────────────────────┘
```

---

## III. MÓDULOS NUEVOS V3

### ★ CNS-09: P-CoT — PROBABILISTIC CHAIN-OF-THOUGHT

**Base teórica:** Adaptación de Physiological Chain-of-Thought al dominio biosensor.
Inspirado en la arquitectura de razonamiento médico probabilístico (Wei et al. 2022 + extensión
fisiológica para señales de alta entropía — Advances in Biosensors for Physiological Monitoring,
MDPI Sensors 2026, DOI: 10.3390/s26020633).

El sistema V2 aplicaba reglas binarias: si `BPM > 100` → TACHYCARDIA. Esto no modelaba
la **incertidumbre** inherente a una señal biológica ruidosa.

V3 emite **distribuciones de creencias**:

```python
# V2 (archivado):
if bpm > 100:
    findings.append({"code": "TACHYCARDIA", "severity": "HIGH"})

# V3:
p_tachycardia = sigmoid((bpm - 100) / 5.0)  # suavizado fisiológico
belief = BeliefState(
    hypothesis="TACHYCARDIA",
    probability=p_tachycardia,
    evidence_entropy=shannon_entropy([p_tachycardia, 1-p_tachycardia]),
    confidence=1.0 - evidence_entropy / math.log2(2)
)
# Solo actúa si P > 0.72 (umbral de compromiso clínico)
# Si 0.45 < P < 0.72 → DOUBT mode → solicitar más evidencia
```

**El DOUBT mode es la innovación crítica**: el sistema no solo actúa, *se detiene* cuando
la entropía de sus propias creencias supera un umbral. Un sistema que nunca duda es un
sistema frágil ante adversarios (lección: IBM Watson Oncology, Strickland 2019).

Cadena P-CoT completa:
```
SENSE:  Extrae métricas en crudo + calcula distribución marginal de BPM
DOUBT:  ¿La entropía de la señal coincide con un organismo vivo?
        H(RR_dist) en rango [1.8, 3.2] bits → biológicamente plausible
        H < 1.5 → señal demasiado regular → SYNTHETIC_FLAG
        H > 3.5 → ruido puro → ARTIFACT_FLAG
WEIGH:  Aplica Transfer Entropy para test causal
        TE(resp_proxy → rr) > 0.05 bits → acoplamiento real → boost confianza
COMMIT: Si P(hipótesis principal) > 0.72 → actuar con alta confianza
        Si P ∈ [0.45, 0.72] → DOUBT → pedir ciclo adicional
        Si P < 0.45 → INSUFFICIENT_EVIDENCE
ACT:    Emite finding con probability + confidence + doubt_flag
```

---

### ★ CNS-06 V3: PHANTOM ENGINE — ANTI-DEEPFAKE ESTEANOGRÁFICO

**Base teórica:** Principio de marca de agua en dominio temporal milisegundos.
Referencia: Transfer Entropy-Based Causal Inference (Electronics 2025, DOI: 10.3390/electronics14204066)
aplicado inversamente — si el adversario puede inferir causalidad en nuestra señal sintética,
tiene suficiente información para destilarla. Solución: rotura de causalidad mediante firma.

**El problema de V2**: El AR(1) con φ=0.82 produce una señal con estadísticas realistas,
pero un adversario con 10 minutos de datos puede ajustar un modelo idéntico y sintetizar
una señal indistinguible SIN la firma.

**Solución V3 — Jitter Steganography**:

```python
# Firma esteganográfica de 4 bits en los últimos dígitos ms del jitter
# Los bits de la firma se inyectan en la residual del AR(1)
# La señal parece idéntica estadísticamente pero lleva una marca verificable

watermark_bit = (session_key_stream[t] >> bit_pos) & 1
jitter_lsb = (residual % 2)  # bit natural del ruido
if jitter_lsb != watermark_bit:
    rr_ms += 1  # ajuste de 1ms — imperceptible, marcado

# Para verificar que una señal es nuestra copia:
extracted = [(rr[t] - ar1_prediction[t]) % 2 for t in range(N)]
match_ratio = sum(1 for b, w in zip(extracted, watermark) if b == w) / N
# match_ratio > 0.75 → es una copia de nuestra señal sintética
```

**Lyapunov Modulation** (anti-distilación): φ no es constante. Varía según el exponente
de Lyapunov local del sistema, calculado sobre la ventana reciente. Esto hace que el
sistema sea caótico a nivel macro pero estocásticamente estable a nivel micro —
exactamente como un corazón real. Un adversario que intente destilar el patrón
encontrará que φ cambia cada 60s de forma impredecible.

---

### ★ CNS-04 V3: RSA CIRCUIT BREAKER

**Base teórica:** Respiratory Sinus Arrhythmia como marcador de vida.
Referencia: Szymański et al. (2026) — Analysis of Respiratory Sinus Arrhythmia with Neural
Networks, ICAISC 2025 (Springer LNCS 15950, DOI: 10.1007/978-3-032-03711-4_26).
También: Janczura & Wyłomańska (2024) — RSA deprimida como predictor de muerte súbita.

**El problema de V2**: La variance collapse detection detectaba señales estáticas, pero
una señal playback de alta calidad (AR(1) bien calibrado) pasaba todos los checks de V2.

**La solución V3**: La RSA es un acoplamiento fisiológico entre el sistema respiratorio
y el cardíaco, mediado por el nervio vago. Opera en la banda 0.15–0.40 Hz.
Una señal sintética SIN modelo respiratorio acoplado tendrá RSA ≈ 0.
Una señal real de un humano vivo tendrá RSA > umbral mínimo.

**Paradoja de la señal perfecta**: Si RSA es exactamente 0, la señal es falsa.
Si RSA está en un rango fisiológico (2-20 ms), es biológicamente plausible.
Si RSA es "demasiado perfecta" (todas las oscilaciones exactamente en fase), también es falsa.

```python
def rsa_liveness_score(rr_buffer: List[float]) -> Tuple[float, str]:
    """
    Calcula score de vivacidad basado en RSA.
    RSA real: amplitud 2-20ms, fase variable ciclo a ciclo
    RSA sintética: ausente (score 0) o perfectamente regular (también falsa)
    """
    hf_power = bandpass_energy(rr_buffer, low=0.15, high=0.40, fs=1.0)
    total_power = variance(rr_buffer)
    rsa_ratio = hf_power / (total_power + 1e-9)

    if rsa_ratio < RSA_DEAD_THRESHOLD:      # 0.08: sin acoplamiento → sintético
        return 0.0, "RSA_ABSENT_SYNTHETIC"
    if rsa_ratio > RSA_PERFECT_THRESHOLD:   # 0.70: demasiado acoplado → replay
        return 0.0, "RSA_TOO_PERFECT_REPLAY"
    # Zona biológicamente plausible
    return min(1.0, rsa_ratio / 0.35), "RSA_BIOLOGICAL"
```

---

### ★ TRANSFER ENTROPY CAUSAL (CNS-03 V3)

**Base teórica:** Entropía de Transferencia como test de causalidad.
Referencia: biorxiv 2025.03.17.643643 — Non-invasive assessment of integrated
cardiorespiratory network dynamics. TE(RESP→HR) como marcador de integración
neurovegetativa. En organismos vivos: TE > 0.05 bits. En señal sintética: TE ≈ 0.

```
TE(X→Y) = I(Y_t ; X_{t-1} | Y_{t-1})
         = H(Y_t | Y_{t-1}) - H(Y_t | Y_{t-1}, X_{t-1})

Donde:
  X = proxy respiratorio (derivado de la modulación HF del RR)
  Y = intervalos RR

En un ser humano vivo:
  TE(RESP → RR) > 0.05 bits    ← COUPLING_REAL
  TE(RR → RESP) > 0.03 bits    ← bidireccional (feedback baroceptor)

En señal sintética AR(1) sin modelo respiratorio:
  TE(RESP_proxy → RR) ≈ 0.01 bits   ← COUPLING_ABSENT
```

La entropía de transferencia se calcula con histogramas 2D discretizados para
mantener coste computacional O(n) sin dependencias de ML.

---

## IV. CAPAS DE SOBERANÍA V3

### SV-1 · PROOF-OF-LIFE RECURSIVE (Nivel 0)
```
proof[n] = SHA-256(master_nonce ‖ proof[n-1] ‖ alive_byte)
proof[0] = SHA-256(master_nonce ‖ "GENESIS" ‖ alive_byte)

Output: {
  "proof": "<64-hex>",
  "proof_index": 847,       ← Número de ciclos de vida certificados
  "alive": true,
  "node_id": "<16-hex>"
}
```
El tercero ahora puede verificar **continuidad**: si la cadena salta de 847 a 849,
alguien detuvo el sistema y lo reinició. La liveness no es solo binaria, tiene historia.

### SV-4 · PHANTOM ENGINE V3 (Anti-Adversarial + Anti-Deepfake)
```
# AR(1) con φ variable por Lyapunov local
φ[t] = φ_base + 0.08 * lyapunov_sign(rr_window) * cos(2π·t/T_chaos)

# Jitter steganográfico (4 bits/segundo, imperceptible)
rr[t] = ar1_predict(rr[t-1], φ[t]) + noise + stego_bit(t, session_key)

Resultado:
  DFA-α1 ≈ 0.95-1.05    ← indistinguible de señal real
  RSA_proxy ≈ 0.12       ← fisiológicamente plausible (no cero, no perfecto)
  Stego mark: 4 bits/s   ← verifiable, imperceptible para adversario
  φ chaos period: ~90s   ← no extrapolable
```

---

## V. TABLA DE PAPERS — HIERRO V3

| Paper / Referencia | Año | Módulo V3 | Aplicación |
|---|---|---|---|
| Szymański et al. *RSA with Neural Networks* (ICAISC 2025, Springer LNCS 15950) | 2026 | CNS-04 RSA Breaker | RSA como marcador de vida: ausencia → señal falsa |
| biorxiv 2025.03.17.643643 — *Cardiorespiratory Network Dynamics* | 2025 | CNS-03 TE Causal | TE(RESP→RR) > 0.05 bits en organismos vivos |
| CGAD — *Entropy Causal Graphs for Anomaly Detection* (arXiv 2312.09478v2) | 2025 | CNS-03 TE | Transfer entropy para detectar inyección adversarial |
| arXiv 2512.10020 — *Comparative Analysis zk-SNARKs vs zk-STARKs* | 2025 | CNS-05 ZKP V3 | Base para recursive commitment: STARKs transparentes sin trusted setup |
| Electronics 2025, 14(20), 4066 — *Transfer Entropy Industrial Alarm* | 2025 | CNS-03 TE | Uso de TE para detectar propagación de disturbios — aplicado a señal cardíaca |
| MDPI Sensors 26(2), 633 — *Advances in Biosensors Physiological Monitoring* | 2026 | CNS-09 P-CoT | Trend: AI + biosensor, razonamiento multi-etapa sobre señales continuas |
| Wei et al. (2022) *Chain-of-Thought Prompting* | 2022 | CNS-09 P-CoT | Base del razonamiento en cadena — extendido a dominio probabilístico |
| Yao et al. (2023) *ReAct* | 2023 | CNS-09 P-CoT | OBSERVE→THINK→ACT → extendido a SENSE→DOUBT→WEIGH→COMMIT→ACT |
| Strickland (2019) *IBM Watson IEEE Spectrum* | 2019 | Todos | Ley fundamental: no actuar sobre señal no validada causalmente |
| Task Force ESC/NASPE (1996) *HRV Standards* | 1996 | CNS-03 | Baselines fisiológicos inamovibles |
| Bigger et al. (1992) *DFA-α1 Coronary* | 1992 | CNS-03 | Umbral crítico DFA < 0.65 |

---

## VI. SENSOR VALIDATOR V3 — DIMENSIONES AMPLIADAS

| Dimensión | Umbral | Diagnóstico | Novedad |
|---|---|---|---|
| Gap temporal | >3s | Desconexión BLE | V2 |
| Deriva de media | >200ms vs μ30 | Ruido galvánico | V2 |
| Variance collapse | σ < 2ms en 10 pkts | Sin contacto | V2 |
| Circuit breaker | trust < 0.35 / 10 pkts | Fallo sistémico | V2 |
| **RSA ausente** | **rsa_ratio < 0.08** | **Señal sintética sin modelo respiratorio** | **★ V3** |
| **RSA perfecta** | **rsa_ratio > 0.70** | **Replay de alta fidelidad** | **★ V3** |
| **TE causal** | **TE(resp→rr) < 0.02 bits** | **Sin acoplamiento neuro-vegetativo** | **★ V3** |
| **H(RR) anómala** | **< 1.5 o > 3.5 bits** | **Señal fuera de rango biológico** | **★ V3** |

---

## VII. METRICAS CARDÍACAS — TABLA ACTUALIZADA V3

| Métrica | Rango Normal | Alerta V3 | Referencia |
|---|---|---|---|
| BPM | 55-90 | <45 o >100 | Task Force ESC/NASPE 1996 |
| RMSSD | 15-80 ms | <12 ms | Task Force 1996 |
| SDNN | 20-150 ms | <15 ms | Task Force 1996 |
| DFA-α1 | 0.85-1.25 | <0.65 o >1.45 | Bigger et al. 1992 |
| **RSA ratio** | **0.08-0.55** | **<0.08 → sintético; >0.70 → replay** | **Szymański et al. 2026** |
| **TE(resp→rr)** | **0.05-0.30 bits** | **<0.02 → sin acoplamiento causal** | **biorxiv 2025.03.17** |
| **H(RR)** | **1.8-3.2 bits** | **<1.5 → regular; >3.5 → ruido** | **P-CoT V3** |
| **P-CoT conf.** | **>0.72** | **[0.45-0.72] → DOUBT mode** | **P-CoT V3** |

---

## VIII. ARQUITECTURA DE ARCHIVOS V3

```
omni_vigil_v3/
├── core_v3.py               # CNS completo V3 (~750 líneas, Python 3.10+)
│   ├── CNS-01 AdaptiveSAVFilter V3
│   ├── CNS-03 EdgeInference V3 (+ Transfer Entropy causal)
│   ├── CNS-04 SensorValidator V3 (+ RSA Circuit Breaker)
│   ├── CNS-05 ZKP Recursive (cadena de commitments)
│   ├── CNS-06 PhantomEngine V3 (Lyapunov + Stego Jitter)
│   ├── CNS-07 SovereignBridge V3
│   ├── CNS-08 FlightRecorder V3 (+ P-CoT belief log)
│   └── CNS-09 PCoTReasoner (Probabilistic Chain-of-Thought)
│
├── sovereign_ui_v3.html     # Dashboard forense-industrial V3
│   ├── P-CoT Belief Bars (visualización de incertidumbre)
│   ├── RSA Liveness Gauge
│   ├── Transfer Entropy Indicator
│   ├── Phantom Stego Verifier
│   └── Todo lo de V2 +
│
├── vigil_v3_protocol.md     # Este manifiesto
├── setup_v3.sh              # Despliegue con entorno aislado
└── requirements_v3.txt      # Stack actualizado
```

---

## IX. PUERTOS Y PROTOCOLO V3

### DATA SERVER — Nivel 2 (localhost solo) — NUEVO CAMPO V3
```json
{
  "level": 2,
  "bpm": 72.3,
  "rmssd": 38.2,
  "sdnn": 52.1,
  "dfa_a1": 1.024,
  "delta_p": 34.7,
  "rsa_ratio": 0.21,
  "te_causal": 0.083,
  "rr_entropy": 2.41,
  "pcot": {
    "primary_belief": "NOMINAL",
    "p_nominal": 0.847,
    "p_tachycardia": 0.031,
    "p_artifact": 0.122,
    "doubt_active": false,
    "confidence": 0.89,
    "chain_step": "COMMIT"
  },
  "liveness": {
    "rsa_ok": true,
    "te_ok": true,
    "entropy_ok": true,
    "stego_clean": true,
    "score": 0.94
  },
  "react": [...],
  "t_rel": 183.4,
  "contact": true
}
```

---

## X. KOAN FINAL

```
La V1 era un oído.
La V2 era un sistema nervioso.
La V3 es un sistema inmune.

El sistema nervioso reacciona a lo que detecta.
El sistema inmune distingue lo propio de lo extraño.

OMNI-VIGIL V3 no solo mide vida.
Verifica que la vida es auténtica.

Una señal perfecta es la señal de una mentira.
El ruido correcto es la firma de lo real.

Zehahahaha · Tic, Tac

— Agencia RONIN · División I+D Capa -1
```

---

**OMNI-VIGIL SOBERANO v3.0 · AGENCIA RONIN**

🛰️ *Duda probabilística. Causalidad verificada. Soberanía recursiva.*
