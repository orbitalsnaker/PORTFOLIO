"""
╔══════════════════════════════════════════════════════════════════════════════╗
║   OMNI-VIGIL SOBERANO  v3.0  //  CENTRAL NERVOUS SYSTEM                    ║
║   La V3 no actúa sobre lo que no entiende.                                 ║
╠══════════════════════════════════════════════════════════════════════════════╣
║   [MÓDULOS CNS V3]                                                          ║
║    CNS-01  PERCEPTION LAYER    — BLE async + SAV-3 adaptive filter         ║
║    CNS-03  EDGE INFERENCE V3   — HRV + Transfer Entropy causal (TE)        ║
║    CNS-04  SENSOR VALIDATOR V3 — Trust scoring + RSA Circuit Breaker       ║
║    CNS-05  ZKP RECURSIVE       — Cadena de commitments temporales           ║
║    CNS-06  PHANTOM ENGINE V3   — Lyapunov chaos + Jitter Steganography     ║
║    CNS-07  SOVEREIGN BRIDGE    — Multi-client async websocket layer        ║
║    CNS-08  FLIGHT RECORDER V3  — Audit chain + P-CoT belief log            ║
║    CNS-09  P-CoT REASONER      — Probabilistic Chain-of-Thought            ║
╠══════════════════════════════════════════════════════════════════════════════╣
║   PAPERS FUNDAMENTALES V3:                                                  ║
║    Szymański et al. (ICAISC 2026) RSA with Neural Networks                 ║
║    biorxiv 2025.03.17.643643 — Cardiorespiratory Network TE                ║
║    Electronics 2025, 14(20):4066 — Transfer Entropy Causal Inference       ║
║    arXiv 2512.10020 — zk-SNARKs vs zk-STARKs comparative analysis         ║
║    MDPI Sensors 26(2):633 (2026) — Biosensors Physiological Monitoring     ║
║    Wei et al. (2022) Chain-of-Thought | Yao et al. (2023) ReAct            ║
║    Strickland (2019) IBM Watson — nunca confiar en datos sin causalidad     ║
║    Task Force ESC/NASPE (1996) | Bigger et al. (1992) DFA-α1               ║
╠══════════════════════════════════════════════════════════════════════════════╣
║   OBSOLESCENCIA                                                             ║
║    core_v2.py — ARCHIVADO. ReAct binario sin duda, sin RSA, sin TE.        ║
║    CNS-V3 DUDA antes de actuar. Verifica causalidad. Detecta réplicas.     ║
╚══════════════════════════════════════════════════════════════════════════════╝

VIGIL V3 SOVEREIGNTY LAYERS:
  SV-1  PROOF-OF-LIFE RECURSIVE  — H(nonce || proof[n-1] || bool) — continuidad temporal
  SV-2  RSA LIVENESS CHECK       — Si señal demasiado perfecta: BLOCK (replay detection)
  SV-3  TRANSFER ENTROPY CAUSAL  — TE(resp→rr) > 0.05 bits: acoplamiento vivo verificado
  SV-4  PHANTOM STEGO INJECTION  — Jitter marcado con firma de sesión inextirpable
  SV-5  P-CoT DOUBT MODE         — Sistema se detiene si H(beliefs) > entropy_threshold
  SV-6  LYAPUNOV CHAOS φ         — φ AR(1) variable: no extrapolable por adversario

Usage:
  python core_v3.py                   # TUI mode
  python core_v3.py --web             # WebSocket sovereign server
  python core_v3.py --web --simulate  # Simulate Polar H10 (no hardware needed)
"""

from __future__ import annotations

import asyncio
import struct
import csv
import time
import sys
import math
import argparse
import signal
import os
import hashlib
import hmac
import json
import uuid
import random
import logging
from datetime import datetime, timezone
from collections import deque
from typing import Optional, Dict, List, Tuple, Any
from dataclasses import dataclass, field, asdict
from enum import IntEnum
from pathlib import Path

# ── Optional deps ────────────────────────────────────────────────────────────
try:
    import numpy as np
    NUMPY_OK = True
except ImportError:
    NUMPY_OK = False

try:
    from bleak import BleakScanner, BleakClient
    BLEAK_OK = True
except ImportError:
    BLEAK_OK = False

try:
    import websockets
    WS_OK = True
except ImportError:
    WS_OK = False

try:
    from cryptography.hazmat.primitives.kdf.hkdf import HKDF
    from cryptography.hazmat.primitives import hashes
    CRYPTO_OK = True
except ImportError:
    CRYPTO_OK = False

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(name)s %(levelname)s: %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("CNS-V3")

# ══════════════════════════════════════════════════════════════════════════════
#  GATT / PMD — Polar H10
# ══════════════════════════════════════════════════════════════════════════════
HR_UUID   = "00002a37-0000-1000-8000-00805f9b34fb"
PMD_CTRL  = "fb005c81-02e7-f387-1cad-8d263ba56064"
PMD_DATA  = "fb005c82-02e7-f387-1cad-8d263ba56064"
ECG_START = bytes([0x02, 0x00, 0x00, 0x01, 0x82, 0x00, 0x01, 0x01, 0x0e, 0x00])
ECG_STOP  = bytes([0x03, 0x00])


# ══════════════════════════════════════════════════════════════════════════════
#  CNS-01 · PERCEPTION LAYER — Adaptive SAV-3 Filter
#  V2 heredado + detección de micro-artefactos BLE por jitter de llegada.
#  Referencia: Task Force ESC/NASPE (1996) §3.1 ectopic beat rejection.
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class PacketMeta:
    ts:     float
    rr_ms:  int
    rssi:   int   = -70
    trust:  float = 1.0

class AdaptiveSAVFilter:
    """SAV-3: mantiene lógica V2 con umbral adaptativo 3.5σ personal."""
    ABSOLUTE_MIN_MS = 250
    ABSOLUTE_MAX_MS = 2500

    def __init__(self, window: int = 120):
        self._window   = window
        self._history: deque[float] = deque()
        self._times:   deque[float] = deque()
        self._mean: float = 750.0
        self._std:  float = 60.0

    def _recalibrate(self):
        now = time.monotonic()
        while self._times and now - self._times[0] > self._window:
            self._times.popleft()
            self._history.popleft()
        if len(self._history) >= 8:
            vals = list(self._history)
            self._mean = sum(vals) / len(vals)
            variance = sum((v - self._mean)**2 for v in vals) / len(vals)
            self._std  = max(variance**0.5, 20.0)

    def validate(self, rr_ms: int) -> Tuple[bool, str]:
        if rr_ms < self.ABSOLUTE_MIN_MS:
            return False, f"ABSOLUTE_MIN ({rr_ms}ms)"
        if rr_ms > self.ABSOLUTE_MAX_MS:
            return False, f"ABSOLUTE_MAX ({rr_ms}ms)"
        low  = self._mean - 3.5 * self._std
        high = self._mean + 3.5 * self._std
        if not (low <= rr_ms <= high):
            return False, f"ADAPTIVE_SIGMA ({rr_ms:.0f}ms, μ={self._mean:.0f}±{self._std:.0f})"
        self._history.append(float(rr_ms))
        self._times.append(time.monotonic())
        self._recalibrate()
        return True, ""


# ══════════════════════════════════════════════════════════════════════════════
#  MATH HELPERS — Sin NumPy. Python puro para portabilidad edge máxima.
# ══════════════════════════════════════════════════════════════════════════════

def _mean(xs: List[float]) -> float:
    return sum(xs) / len(xs) if xs else 0.0

def _variance(xs: List[float]) -> float:
    if len(xs) < 2:
        return 0.0
    mu = _mean(xs)
    return sum((x - mu)**2 for x in xs) / len(xs)

def _std(xs: List[float]) -> float:
    return _variance(xs)**0.5

def _covariance(xs: List[float], ys: List[float]) -> float:
    if len(xs) != len(ys) or len(xs) < 2:
        return 0.0
    mx, my = _mean(xs), _mean(ys)
    return sum((xs[i] - mx) * (ys[i] - my) for i in range(len(xs))) / len(xs)

def _shannon_entropy(probs: List[float]) -> float:
    """H(X) en bits."""
    h = 0.0
    for p in probs:
        if p > 1e-12:
            h -= p * math.log2(p)
    return h

def _sigmoid(x: float, k: float = 1.0) -> float:
    return 1.0 / (1.0 + math.exp(-k * x))

def _linreg_slope(ys: List[float]) -> float:
    n = len(ys)
    if n < 3:
        return 0.0
    xs = list(range(n))
    mx, my = _mean(xs), _mean(ys)
    num = sum((xs[i] - mx) * (ys[i] - my) for i in range(n))
    den = sum((xs[i] - mx)**2 for i in range(n))
    return num / den if den else 0.0

def _bandpass_energy(signal: List[float], low_frac: float, high_frac: float) -> float:
    """
    Estima energía en banda de frecuencia [low_frac, high_frac] de Nyquist
    usando DFT manual (O(n²) pero ligero para n≤64).
    Para RSA estimamos banda 0.15-0.40 Hz sobre señal RR muestreada a ~1 Hz.
    low_frac y high_frac son fracciones de la frecuencia de Nyquist (0-1).
    """
    n = len(signal)
    if n < 8:
        return 0.0
    mu = _mean(signal)
    centered = [x - mu for x in signal]
    energy = 0.0
    nyq_bins = n // 2
    for k in range(1, nyq_bins + 1):
        frac = k / nyq_bins
        if low_frac <= frac <= high_frac:
            re = sum(centered[t] * math.cos(2 * math.pi * k * t / n) for t in range(n))
            im = sum(centered[t] * math.sin(2 * math.pi * k * t / n) for t in range(n))
            energy += (re**2 + im**2) / n**2
    return energy


# ══════════════════════════════════════════════════════════════════════════════
#  CNS-03 V3 · EDGE INFERENCE — HRV + Transfer Entropy Causal
#
#  NUEVO V3: Transfer Entropy TE(resp_proxy → rr)
#  Referencia: biorxiv 2025.03.17.643643 — Non-invasive assessment of
#  cardiorespiratory network dynamics. En organismos vivos:
#  TE(RESP→RR) > 0.05 bits. En señal sintética sin modelo resp: TE ≈ 0.
#
#  El proxy respiratorio se extrae del componente HF (0.15-0.40 Hz)
#  del propio RR mediante filtrado espectral. Esto es válido porque la
#  RSA genera una modulación de RR en exactamente esa banda cuando hay
#  respiración acoplada.
# ══════════════════════════════════════════════════════════════════════════════

class EdgeInference:
    """
    Buffer de Conciencia V3: métricas cardíacas + Transfer Entropy causal.
    Sin NumPy: aritmética pura de Python para máxima portabilidad en edge.
    """
    # Basales Task Force ESC/NASPE 1996
    BASAL_BPM_RANGE   = (55, 90)
    BASAL_RMSSD_RANGE = (15, 80)
    BASAL_SDNN_RANGE  = (20, 150)
    BASAL_DFA_RANGE   = (0.85, 1.25)

    # Alertas V2 (mantenidas)
    ALERT_BPM_HIGH  = 100
    ALERT_BPM_LOW   = 45
    ALERT_RMSSD_LOW = 12
    ALERT_DFA_LOW   = 0.65
    ALERT_DFA_HIGH  = 1.45

    # V3: Transfer Entropy — umbral de acoplamiento causal
    # Referencia: biorxiv 2025.03.17.643643
    TE_COUPLING_THRESHOLD = 0.03   # bits — por debajo: señal sin causalidad biológica
    TE_BINS = 6                    # Discretización del histograma 2D para TE

    def __init__(self, buf_size: int = 256):
        self._rr:          deque[float] = deque(maxlen=buf_size)
        self._ts:          deque[float] = deque(maxlen=buf_size)
        self._bpm_history: deque[float] = deque(maxlen=120)

    def push(self, rr_ms: float, ts: float):
        self._rr.append(rr_ms)
        self._ts.append(ts)
        bpm = 60000.0 / rr_ms if rr_ms > 0 else 0
        self._bpm_history.append(bpm)

    def bpm(self) -> float:
        return self._bpm_history[-1] if self._bpm_history else 0.0

    def rmssd(self) -> float:
        rr = list(self._rr)
        if len(rr) < 2: return 0.0
        diffs = [(rr[i+1] - rr[i])**2 for i in range(len(rr)-1)]
        return (sum(diffs) / len(diffs))**0.5

    def sdnn(self) -> float:
        rr = list(self._rr)
        if len(rr) < 4: return 0.0
        mu = _mean(rr)
        return (sum((v - mu)**2 for v in rr) / len(rr))**0.5

    def delta_p(self) -> float:
        return min(100.0, (self.sdnn() / 150.0) * 100.0)

    # ── M2: DFA-α1 ────────────────────────────────────────────────────────
    def dfa_alpha1(self) -> float:
        """Bigger et al. (1992). Sin NumPy."""
        rr = list(self._rr)
        if len(rr) < 32: return 1.0
        mu = _mean(rr)
        profile, acc = [], 0.0
        for v in rr:
            acc += v - mu
            profile.append(acc)
        scales = [4, 8, 12, 16]
        fluctuations = []
        for s in scales:
            segs = len(profile) // s
            if segs < 1: continue
            f2 = 0.0
            for seg in range(segs):
                chunk = profile[seg*s:(seg+1)*s]
                n = len(chunk)
                xi = list(range(n))
                mx, my = _mean(xi), _mean(chunk)
                den = sum((xi[i]-mx)**2 for i in range(n))
                b = _covariance(xi, chunk) * n / den if den else 0
                a = my - b * mx
                f2 += sum((chunk[i] - (a + b*xi[i]))**2 for i in range(n)) / n
            fluctuations.append((s, (f2/segs)**0.5))
        if len(fluctuations) < 2: return 1.0
        log_s = [math.log(f[0]) for f in fluctuations]
        log_f = [math.log(max(f[1], 1e-9)) for f in fluctuations]
        n = len(log_s)
        mx, my = _mean(log_s), _mean(log_f)
        num = sum((log_s[i]-mx)*(log_f[i]-my) for i in range(n))
        den = sum((log_s[i]-mx)**2 for i in range(n))
        alpha = num / den if den else 1.0
        return round(max(0.3, min(2.0, alpha)), 4)

    def bpm_trend(self) -> float:
        hist = list(self._bpm_history)
        if len(hist) < 10: return 0.0
        return round(_linreg_slope(hist), 4)

    # ── V3: SHANNON ENTROPY of RR distribution ────────────────────────────
    def rr_entropy(self) -> float:
        """
        Entropía de Shannon de la distribución discreta de intervalos RR.
        Rango biológico normal: 1.8–3.2 bits (Task Force 1996 + derivado).
        < 1.5 bits → señal demasiado regular (sintética o arritmia severa)
        > 3.5 bits → ruido puro (artefacto o desconexión)
        """
        rr = list(self._rr)
        if len(rr) < 16: return 2.0  # nominal hasta tener datos
        # Discretización en 16 bins entre 300-1800ms
        bins = [0] * 16
        for v in rr:
            idx = int((v - 300) / (1500 / 16))
            idx = max(0, min(15, idx))
            bins[idx] += 1
        total = len(rr)
        probs = [b / total for b in bins if b > 0]
        return round(_shannon_entropy(probs), 3)

    # ── V3: TRANSFER ENTROPY TE(resp_proxy → rr) ─────────────────────────
    def transfer_entropy_causal(self) -> float:
        """
        Estima TE(resp_proxy → RR) donde resp_proxy = componente HF del RR.
        Referencia: biorxiv 2025.03.17.643643 — Cardiorespiratory Network Dynamics.

        TE(X→Y) ≈ H(Y_t | Y_{t-1}) - H(Y_t | Y_{t-1}, X_{t-1})
        Implementación: histogramas 2D y 3D discretizados.

        Organismos vivos: TE > 0.05 bits (acoplamiento neuro-vegetativo)
        Señales sintéticas AR(1): TE ≈ 0.01-0.02 bits (sin causalidad)
        """
        rr = list(self._rr)
        if len(rr) < 32: return 0.1  # nominal hasta tener datos

        # Extraer proxy respiratorio: componente HF (0.15-0.40 Hz normalizado)
        # En el espectro RR (muestreado ~1Hz), HF cae en fracción [0.30-0.80]
        # Usamos la señal centrada filtrada por energía de banda
        n = len(rr)
        mu_rr = _mean(rr)
        rr_c = [v - mu_rr for v in rr]

        # Reconstruir proxy resp como componente HF
        resp_proxy = []
        for t in range(n):
            hf = 0.0
            for k in range(max(1, int(n*0.30)), min(n//2, int(n*0.80))):
                re = sum(rr_c[j] * math.cos(2*math.pi*k*j/n) for j in range(n))
                im = sum(rr_c[j] * math.sin(2*math.pi*k*j/n) for j in range(n))
                hf += (re * math.cos(2*math.pi*k*t/n) +
                       im * math.sin(2*math.pi*k*t/n)) / n
            resp_proxy.append(hf)

        # Discretizar en bins para histogramas
        B = self.TE_BINS

        def discretize(xs: List[float]) -> List[int]:
            mn, mx = min(xs), max(xs)
            rng = mx - mn + 1e-9
            return [min(B-1, int((x - mn) / rng * B)) for x in xs]

        Y  = discretize(rr[1:])           # Y_t
        Yp = discretize(rr[:-1])          # Y_{t-1}
        X  = discretize(resp_proxy[:-1])  # X_{t-1}

        M = len(Y)

        def joint_prob_2d(a: List[int], b: List[int]) -> List[List[float]]:
            hist = [[0]*B for _ in range(B)]
            for i, j in zip(a, b): hist[i][j] += 1
            return [[c/M for c in row] for row in hist]

        def joint_prob_3d(a, b, c) -> Dict:
            hist: Dict = {}
            for i, j, k in zip(a, b, c):
                hist[(i,j,k)] = hist.get((i,j,k), 0) + 1
            return {k: v/M for k, v in hist.items()}

        def entropy_2d(p: List[List[float]]) -> float:
            return -sum(p[i][j] * math.log2(p[i][j]+1e-12)
                        for i in range(B) for j in range(B) if p[i][j] > 0)

        def entropy_3d(p: Dict) -> float:
            return -sum(v * math.log2(v+1e-12) for v in p.values() if v > 0)

        # TE(X→Y) = H(Y,Y') - H(Y,Y',X) + H(Y',X) - H(Y')
        # Aproximación eficiente:
        p_yy  = joint_prob_2d(Y, Yp)
        p_yyy = joint_prob_3d(Y, Yp, X)
        p_yx  = joint_prob_2d(Yp, X)

        p_yp = [0.0] * B
        for i in range(B):
            for j in range(B):
                p_yp[i] += p_yy[i][j]

        h_yp  = _shannon_entropy([p for p in p_yp if p > 0])
        h_yy  = entropy_2d(p_yy)
        h_yx  = entropy_2d(p_yx)
        h_yyy = entropy_3d(p_yyy)

        te = h_yy - h_yyy + h_yx - h_yp
        return round(max(0.0, te), 4)

    def summary(self) -> Dict:
        rr = list(self._rr)
        rsa_r = 0.0
        if len(rr) >= 32:
            total_var = _variance(rr)
            hf_energy = _bandpass_energy(rr, 0.30, 0.80)  # HF band (RSA)
            rsa_r = round(hf_energy / (total_var + 1e-9), 4)
        return {
            "bpm":       round(self.bpm(), 1),
            "rmssd":     round(self.rmssd(), 2),
            "sdnn":      round(self.sdnn(), 2),
            "dfa_a1":    self.dfa_alpha1(),
            "delta_p":   round(self.delta_p(), 2),
            "bpm_trend": self.bpm_trend(),
            "rsa_ratio": rsa_r,
            "te_causal": self.transfer_entropy_causal(),
            "rr_entropy":self.rr_entropy(),
            "n_samples": len(self._rr),
        }


# ══════════════════════════════════════════════════════════════════════════════
#  CNS-04 V3 · SENSOR VALIDATOR — RSA Circuit Breaker
#
#  NUEVO V3: RSA Liveness Check.
#  Referencia: Szymański et al. (ICAISC 2026, Springer LNCS 15950)
#  RSA real: HF/total power ratio en [0.08, 0.55]
#  RSA ausente (< 0.08) → señal sintética sin modelo respiratorio acoplado
#  RSA perfecta (> 0.70) → replay de alta fidelidad (demasiado acoplado)
# ══════════════════════════════════════════════════════════════════════════════

class SensorValidator:
    """
    Trust scoring V3: hereda V2 + añade RSA Circuit Breaker y TE threshold.

    IBM Watson Lección (Strickland 2019): no procesar señal no confiable.
    V3 extiende: tampoco procesar señal causalmente inverosímil.
    """
    CIRCUIT_BREAKER_THRESHOLD = 0.35
    CIRCUIT_BREAKER_WINDOW    = 10

    # V3: RSA liveness thresholds
    # Referencia: Szymański et al. (ICAISC 2026)
    RSA_DEAD_THRESHOLD    = 0.08   # Por debajo: sin acoplamiento respiratorio → sintético
    RSA_PERFECT_THRESHOLD = 0.70   # Por encima: demasiado acoplado → replay

    # V3: Transfer Entropy threshold
    TE_MIN_COUPLING = 0.02         # biorxiv 2025.03.17.643643

    def __init__(self):
        self._last_ts:        Optional[float] = None
        self._rr_buf:         deque[float]    = deque(maxlen=30)
        self._low_trust_run:  int  = 0
        self.circuit_open:    bool = False
        self.trust_history:   deque[float] = deque(maxlen=60)
        self.fault_log:       List[str] = []
        self._liveness_buf:   deque[float] = deque(maxlen=32)

    def rsa_liveness_score(self, rr_buf: List[float]) -> Tuple[float, str]:
        """
        Calcula score de vivacidad RSA.
        Referencia: Szymański et al. (ICAISC 2026, Springer LNCS 15950).
        """
        if len(rr_buf) < 16:
            return 0.5, "RSA_INSUFFICIENT_DATA"
        total_var = _variance(rr_buf)
        if total_var < 1e-6:
            return 0.0, "RSA_VARIANCE_ZERO"
        hf_energy = _bandpass_energy(rr_buf, 0.30, 0.80)
        rsa_ratio = hf_energy / (total_var + 1e-9)

        if rsa_ratio < self.RSA_DEAD_THRESHOLD:
            return 0.0, f"RSA_ABSENT_SYNTHETIC (ratio={rsa_ratio:.3f} < {self.RSA_DEAD_THRESHOLD})"
        if rsa_ratio > self.RSA_PERFECT_THRESHOLD:
            return 0.0, f"RSA_TOO_PERFECT_REPLAY (ratio={rsa_ratio:.3f} > {self.RSA_PERFECT_THRESHOLD})"
        # Zona biológicamente plausible
        normalized = min(1.0, rsa_ratio / 0.35)
        return round(normalized, 3), "RSA_BIOLOGICAL"

    def score(self, rr_ms: int, recv_ts: float) -> Tuple[float, List[str]]:
        """Calcula trust score V3 con RSA check integrado."""
        flags: List[str] = []
        score = 1.0

        # A) Gap temporal (V2 heredado)
        if self._last_ts is not None:
            gap = recv_ts - self._last_ts
            if gap > 3.0:
                penalty = min(0.5, (gap - 3.0) / 10.0)
                score -= penalty
                flags.append(f"GAP_{gap:.1f}s")
        self._last_ts = recv_ts

        # B) Deriva de media (V2 heredado)
        self._rr_buf.append(rr_ms)
        if len(self._rr_buf) >= 8:
            mu  = _mean(list(self._rr_buf))
            dev = abs(rr_ms - mu)
            if dev > 200:
                penalty = min(0.4, (dev - 200) / 400.0)
                score -= penalty
                flags.append(f"DRIFT_{dev:.0f}ms")

        # C) Variance collapse (V2 heredado)
        if len(self._rr_buf) >= 10:
            var = _variance(list(self._rr_buf))
            if var < 4.0:
                score -= 0.5
                flags.append("VARIANCE_COLLAPSE")

        # D) ★ V3: RSA LIVENESS CHECK
        # Referencia: Szymański et al. (ICAISC 2026, Springer LNCS 15950)
        if len(self._rr_buf) >= 16:
            rsa_score, rsa_status = self.rsa_liveness_score(list(self._rr_buf))
            if rsa_score < 0.1:
                # Signal fails liveness test
                penalty = 0.45
                score -= penalty
                flags.append(f"RSA_FAIL:{rsa_status}")
                log.warning(f"⚡ RSA CIRCUIT BREAKER: {rsa_status}")
            elif rsa_score < 0.4:
                # Marginal RSA
                score -= 0.15
                flags.append(f"RSA_MARGINAL:{rsa_status}")

        score = max(0.0, min(1.0, score))
        self.trust_history.append(score)

        # Circuit breaker acumulado
        if score < self.CIRCUIT_BREAKER_THRESHOLD:
            self._low_trust_run += 1
            if self._low_trust_run >= self.CIRCUIT_BREAKER_WINDOW:
                if not self.circuit_open:
                    log.warning("⚡ CIRCUIT BREAKER OPEN — sensor trust degraded (V3)")
                self.circuit_open = True
                msg = f"CIRCUIT_OPEN low_run={self._low_trust_run}"
                flags.append(msg)
                self.fault_log.append(f"{datetime.utcnow().isoformat()} {msg}")
        else:
            self._low_trust_run = 0
            if self.circuit_open:
                log.info("✅ Circuit breaker reset")
                self.circuit_open = False

        return score, flags

    def mean_trust(self) -> float:
        if not self.trust_history: return 1.0
        return sum(self.trust_history) / len(self.trust_history)


# ══════════════════════════════════════════════════════════════════════════════
#  ★ CNS-09 · P-CoT REASONER — Probabilistic Chain-of-Thought
#
#  Reemplaza el ReAct Loop determinista (V2) con razonamiento probabilístico.
#  Referencia primaria: Wei et al. (2022) Chain-of-Thought, extendido a
#  dominio fisiológico según framework de MDPI Sensors 26(2):633 (2026).
#
#  El sistema no actúa con certeza binaria. Emite distribuciones de creencia
#  y se detiene (DOUBT mode) cuando la entropía supera el umbral biológico.
#
#  Cadena: SENSE → DOUBT → WEIGH → COMMIT → ACT
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class BeliefState:
    hypothesis:       str
    probability:      float    # P(hipótesis | evidencia)
    confidence:       float    # 1 - H(creencias) normalizado
    supporting_evidence: List[str] = field(default_factory=list)
    doubt_triggered:  bool = False

@dataclass
class PCoTResult:
    chain_step:       str      # Último paso alcanzado
    primary_belief:   str      # Hipótesis más probable
    p_primary:        float
    p_nominal:        float
    p_tachycardia:    float
    p_bradycardia:    float
    p_low_hrv:        float
    p_artifact:       float
    p_synthetic:      float    # V3: probabilidad de señal sintética
    belief_entropy:   float    # H(distribución de creencias)
    confidence:       float    # 1 - H/H_max
    doubt_active:     bool
    doubt_reason:     str
    action:           str
    findings:         List[Dict]

class PCoTReasoner:
    """
    Probabilistic Chain-of-Thought sobre señal biométrica.
    No es un LLM. Es razonamiento probabilístico determinista
    sobre reglas fisiológicas con modelado de incertidumbre.

    Referencia: Wei et al. (2022) + extensión fisiológica
    (MDPI Sensors 26(2):633, 2026 — AI-enhanced biosensors).

    La innovación crítica respecto a V2:
    - V2: if bpm > 100 → TACHYCARDIA
    - V3: P(TACHYCARDIA | bpm) = sigmoid((bpm-100)/5) → actúa solo si P > 0.72
    """
    # Umbral de compromiso clínico: solo actuar con alta certeza
    COMMIT_THRESHOLD = 0.72
    # Umbral de duda: zona intermedia requiere más ciclos
    DOUBT_LOW  = 0.45
    DOUBT_HIGH = 0.72
    # Entropía máxima para 7 hipótesis = log2(7) = 2.807 bits
    # Si H > 1.8 bits: demasiada incertidumbre, solicitar ciclo adicional
    ENTROPY_DOUBT_THRESHOLD = 1.8

    # V3: Umbrales RSA y TE para detección de señal sintética
    # Referencia: biorxiv 2025.03.17.643643
    TE_SYNTHETIC_THRESHOLD  = 0.025
    RSA_SYNTHETIC_THRESHOLD = 0.08

    def reason(self, metrics: Dict, sensor_trust: float) -> PCoTResult:
        """
        Ejecuta la cadena P-CoT sobre las métricas actuales.
        Devuelve un PCoTResult con la distribución de creencias completa.
        """
        bpm       = metrics.get("bpm", 70.0)
        rmssd     = metrics.get("rmssd", 30.0)
        dfa       = metrics.get("dfa_a1", 1.0)
        trend     = metrics.get("bpm_trend", 0.0)
        rsa_ratio = metrics.get("rsa_ratio", 0.2)
        te_causal = metrics.get("te_causal", 0.1)
        rr_entropy= metrics.get("rr_entropy", 2.2)
        findings  = []

        # ── PASO 1: SENSE — ¿Es el sensor fiable? ──────────────────────
        if sensor_trust < 0.5:
            return PCoTResult(
                chain_step="SENSE", primary_belief="SENSOR_DEGRADED",
                p_primary=0.95, p_nominal=0.0, p_tachycardia=0.0,
                p_bradycardia=0.0, p_low_hrv=0.0, p_artifact=0.05,
                p_synthetic=0.0,
                belief_entropy=0.0, confidence=0.95, doubt_active=False,
                doubt_reason="Sensor trust < 0.50",
                action="SUSPEND_INFERENCE",
                findings=[{
                    "step": "SENSE", "severity": "CRITICAL",
                    "code": "SENSOR_DEGRADED",
                    "msg": f"trust={sensor_trust:.2f} — Strickland (2019): datos no confiables",
                    "p": sensor_trust
                }]
            )

        # ── PASO 2: DOUBT — ¿La entropía de la señal es biológica? ─────
        doubt_active = False
        doubt_reason = ""

        # V3: Test de señal sintética via TE y RSA
        # Referencia: biorxiv 2025.03.17.643643 + Szymański et al. 2026
        p_synthetic = 0.0
        synthetic_evidence = []

        if te_causal < self.TE_SYNTHETIC_THRESHOLD:
            # Sin acoplamiento causal cardiorespiratorio
            p_synthetic += 0.45
            synthetic_evidence.append(f"TE={te_causal:.3f}<{self.TE_SYNTHETIC_THRESHOLD}")
        if rsa_ratio < self.RSA_SYNTHETIC_THRESHOLD:
            # Sin modulación respiratoria en la señal
            p_synthetic += 0.40
            synthetic_evidence.append(f"RSA={rsa_ratio:.3f}<{self.RSA_SYNTHETIC_THRESHOLD}")
        if rr_entropy < 1.5:
            p_synthetic += 0.20
            synthetic_evidence.append(f"H_RR={rr_entropy:.2f}bits<1.5")
        elif rr_entropy > 3.5:
            p_synthetic += 0.15
            synthetic_evidence.append(f"H_RR={rr_entropy:.2f}bits>3.5")

        p_synthetic = min(0.99, p_synthetic)

        if p_synthetic > 0.55:
            findings.append({
                "step": "DOUBT", "severity": "CRITICAL",
                "code": "SYNTHETIC_SIGNAL_DETECTED",
                "msg": (f"P(sintético)={p_synthetic:.2f}. Evidencia: {', '.join(synthetic_evidence)}. "
                        f"Ref: biorxiv 2025.03.17.643643 + Szymański et al. ICAISC 2026."),
                "action": "BLOCK_SIGNAL_PHANTOM_MODE",
                "p": p_synthetic,
            })
            return PCoTResult(
                chain_step="DOUBT", primary_belief="SYNTHETIC_SIGNAL",
                p_primary=p_synthetic, p_nominal=1-p_synthetic, p_tachycardia=0.0,
                p_bradycardia=0.0, p_low_hrv=0.0, p_artifact=0.0,
                p_synthetic=p_synthetic,
                belief_entropy=0.5, confidence=p_synthetic,
                doubt_active=True, doubt_reason=", ".join(synthetic_evidence),
                action="BLOCK_SIGNAL_PHANTOM_MODE",
                findings=findings
            )

        # ── PASO 3: WEIGH — Cálculo de probabilidades fisiológicas ──────
        # Probabilidades suavizadas (sigmoid) en lugar de umbral duro

        # P(taquicardia): crece suavemente sobre 100 bpm
        p_tachycardia = _sigmoid((bpm - 100) / 5.0) if bpm > 80 else 0.01
        # P(bradicardia): crece suavemente bajo 50 bpm
        p_bradycardia = _sigmoid((50 - bpm) / 5.0) if bpm < 65 else 0.01
        # P(low_hrv): crece suavemente bajo 15ms
        p_low_hrv = _sigmoid((15 - rmssd) / 3.0) if rmssd < 30 else 0.01
        # P(complexity_loss): crece bajo DFA=0.65
        p_complexity = _sigmoid((0.65 - dfa) / 0.05) if dfa < 0.85 else 0.01
        # P(artifact): DFA muy alto → posible artefacto galvánico
        p_artifact = _sigmoid((dfa - 1.45) / 0.05) if dfa > 1.25 else 0.01
        # P(nominal): complementario normalizado
        p_abnormal = max(p_tachycardia, p_bradycardia, p_low_hrv,
                         p_complexity, p_artifact, p_synthetic)
        p_nominal = max(0.01, 1.0 - p_abnormal)

        # Normalizar distribución
        total = (p_nominal + p_tachycardia + p_bradycardia +
                 p_low_hrv + p_complexity + p_artifact + p_synthetic)
        if total > 0:
            p_nominal      /= total
            p_tachycardia  /= total
            p_bradycardia  /= total
            p_low_hrv      /= total
            p_complexity   /= total
            p_artifact     /= total
            p_synthetic    /= total

        belief_dist = [p_nominal, p_tachycardia, p_bradycardia,
                       p_low_hrv, p_complexity, p_artifact, p_synthetic]
        belief_entropy = _shannon_entropy(belief_dist)
        confidence = max(0.0, 1.0 - belief_entropy / math.log2(len(belief_dist)))

        # Primaria = hipótesis más probable
        labels = ["NOMINAL", "TACHYCARDIA", "BRADYCARDIA",
                  "LOW_HRV", "COMPLEXITY_LOSS", "ARTIFACT", "SYNTHETIC"]
        probs  = [p_nominal, p_tachycardia, p_bradycardia,
                  p_low_hrv, p_complexity, p_artifact, p_synthetic]
        primary_idx   = probs.index(max(probs))
        primary_belief = labels[primary_idx]
        p_primary      = probs[primary_idx]

        # ── PASO 4: COMMIT — ¿Actuar o dudar? ──────────────────────────
        if belief_entropy > self.ENTROPY_DOUBT_THRESHOLD:
            doubt_active = True
            doubt_reason = f"H(beliefs)={belief_entropy:.2f} > {self.ENTROPY_DOUBT_THRESHOLD} bits"

        # Solo emitir findings cuando P > COMMIT_THRESHOLD
        if p_tachycardia > self.COMMIT_THRESHOLD:
            findings.append({
                "step": "COMMIT", "severity": "HIGH", "code": "TACHYCARDIA",
                "msg": f"P(taquicardia)={p_tachycardia:.2f} > {self.COMMIT_THRESHOLD}. BPM={bpm:.0f}.",
                "action": "EMIT_ALERT_L0", "p": p_tachycardia
            })
        elif p_tachycardia > self.DOUBT_LOW:
            findings.append({
                "step": "DOUBT", "severity": "MEDIUM", "code": "TACHYCARDIA_SUSPECTED",
                "msg": f"P(taquicardia)={p_tachycardia:.2f} en zona duda. Ciclo adicional.",
                "action": "REQUEST_ADDITIONAL_CYCLE", "p": p_tachycardia
            })

        if p_bradycardia > self.COMMIT_THRESHOLD:
            findings.append({
                "step": "COMMIT", "severity": "HIGH", "code": "BRADYCARDIA",
                "msg": f"P(bradicardia)={p_bradycardia:.2f}. BPM={bpm:.0f}.",
                "action": "EMIT_ALERT_L0", "p": p_bradycardia
            })

        if p_low_hrv > self.COMMIT_THRESHOLD:
            findings.append({
                "step": "COMMIT", "severity": "MEDIUM", "code": "LOW_HRV",
                "msg": f"P(HRV deprimida)={p_low_hrv:.2f}. RMSSD={rmssd:.1f}ms.",
                "action": "LOG_FATIGUE", "p": p_low_hrv
            })

        if p_complexity > self.COMMIT_THRESHOLD:
            findings.append({
                "step": "COMMIT", "severity": "HIGH", "code": "COMPLEXITY_LOSS",
                "msg": f"P(pérdida complejidad)={p_complexity:.2f}. DFA={dfa:.3f}. Bigger 1992.",
                "action": "EMIT_ALERT_L0", "p": p_complexity
            })

        if p_artifact > self.COMMIT_THRESHOLD:
            findings.append({
                "step": "COMMIT", "severity": "MEDIUM", "code": "ARTIFACT",
                "msg": f"P(artefacto)={p_artifact:.2f}. DFA={dfa:.3f} > 1.45.",
                "action": "REQUEST_SENSOR_CHECK", "p": p_artifact
            })

        if doubt_active:
            findings.append({
                "step": "DOUBT", "severity": "LOW", "code": "INSUFFICIENT_CERTAINTY",
                "msg": f"Entropía de creencias={belief_entropy:.2f}bits > umbral. Solicitar ciclo adicional.",
                "action": "AWAIT_MORE_DATA", "p": 1 - confidence
            })

        # ── PASO 5: ACT ──────────────────────────────────────────────────
        if primary_belief == "NOMINAL" and p_nominal > self.COMMIT_THRESHOLD and not doubt_active:
            findings.append({
                "step": "ACT", "severity": "OK", "code": "NOMINAL",
                "msg": (f"P(nominal)={p_nominal:.2f}. BPM={bpm:.0f} "
                        f"RMSSD={rmssd:.1f} DFA={dfa:.3f} "
                        f"TE={te_causal:.3f} RSA={rsa_ratio:.3f} H={belief_entropy:.2f}bits"),
                "action": "CONTINUE", "p": p_nominal
            })

        action = "CONTINUE"
        if doubt_active: action = "AWAIT_MORE_DATA"
        if primary_belief in ("TACHYCARDIA","BRADYCARDIA","COMPLEXITY_LOSS") and p_primary > self.COMMIT_THRESHOLD:
            action = "EMIT_ALERT_L0"
        if primary_belief == "SYNTHETIC_SIGNAL" and p_primary > 0.55:
            action = "BLOCK_SIGNAL_PHANTOM_MODE"

        return PCoTResult(
            chain_step="ACT" if not doubt_active else "DOUBT",
            primary_belief=primary_belief,
            p_primary=round(p_primary, 3),
            p_nominal=round(p_nominal, 3),
            p_tachycardia=round(p_tachycardia, 3),
            p_bradycardia=round(p_bradycardia, 3),
            p_low_hrv=round(p_low_hrv, 3),
            p_artifact=round(p_artifact, 3),
            p_synthetic=round(p_synthetic, 3),
            belief_entropy=round(belief_entropy, 3),
            confidence=round(confidence, 3),
            doubt_active=doubt_active,
            doubt_reason=doubt_reason,
            action=action,
            findings=sorted(findings, key=lambda x: {
                "CRITICAL":0,"HIGH":1,"MEDIUM":2,"LOW":3,"OK":4
            }.get(x.get("severity","LOW"), 5))
        )


# ══════════════════════════════════════════════════════════════════════════════
#  CNS-05 V3 · ZKP RECURSIVE — Cadena de Commitments Temporales
#
#  V2: commitment simple H(nonce || bool)
#  V3: commitment recursivo H(nonce || proof[n-1] || bool)
#
#  El tercero puede verificar CONTINUIDAD: si la cadena salta de índice 847
#  a 849, alguien detuvo el sistema. La liveness no es solo binaria.
#  Referencia: arXiv 2512.10020 — principio de recursive proofs (STARKs)
#  aplicado a commitment chains para attestation local.
# ══════════════════════════════════════════════════════════════════════════════

class ZKPSovereignty:
    """
    ZKP Recursive V3: cadena de commitments con índice verificable.
    Cada proof certifica el anterior — continuidad temporal auditable.
    """
    NONCE_ROTATION_SEC = 300

    def __init__(self):
        self._master_nonce:  bytes = os.urandom(32)
        self._nonce_epoch:   float = time.monotonic()
        self._proof_counter: int   = 0
        self._last_proof:    str   = "GENESIS"  # V3: estado inicial de la cadena

    def _rotate_if_needed(self):
        if time.monotonic() - self._nonce_epoch > self.NONCE_ROTATION_SEC:
            self._master_nonce = os.urandom(32)
            self._nonce_epoch  = time.monotonic()
            # Al rotar el nonce, reiniciamos la cadena pero guardamos el índice
            self._last_proof = hashlib.sha256(
                self._master_nonce + b"ROTATION"
            ).hexdigest()
            log.debug("🔑 ZKP nonce rotated — chain bridged")

    def _commit_recursive(self, value: bytes) -> str:
        """
        H(nonce || proof[n-1] || value) — Recursive Commitment.
        Referencia: arXiv 2512.10020 — recursive proof principle.
        """
        self._rotate_if_needed()
        payload = self._master_nonce + self._last_proof.encode() + value
        new_proof = hashlib.sha256(payload).hexdigest()
        self._last_proof = new_proof
        self._proof_counter += 1
        return new_proof

    def _node_id(self) -> str:
        window = int(time.monotonic() / self.NONCE_ROTATION_SEC)
        return hashlib.sha256(
            self._master_nonce + window.to_bytes(8, 'big')
        ).hexdigest()[:16]

    def proof_of_life(self, alive: bool) -> Dict:
        """Nivel 0: Proof-of-Life con continuidad temporal verificable."""
        commit = self._commit_recursive(b'\x01' if alive else b'\x00')
        return {
            "level":       0,
            "protocol":    "VIGIL_ZKP_V3",
            "proof":       commit,
            "proof_index": self._proof_counter,  # V3: índice de continuidad
            "alive":       alive,
            "node_id":     self._node_id(),
        }

    def proof_of_calm(self, alive: bool, rmssd: float, threshold: float = 20.0) -> Dict:
        """Nivel 1: Proof-of-Calm con chain recursiva."""
        calm = rmssd > threshold and alive
        commit = self._commit_recursive(b'\x02' + (b'\x01' if calm else b'\x00'))
        return {
            "level":       1,
            "protocol":    "VIGIL_ZKP_V3",
            "proof":       commit,
            "proof_index": self._proof_counter,
            "alive":       alive,
            "calm":        calm,
            "node_id":     self._node_id(),
        }

    def proof_of_engineering(self, metrics: Dict, pcot: PCoTResult,
                              t_rel: float, contact: bool) -> Dict:
        """Nivel 2: Stream completo (solo localhost) con P-CoT integrado."""
        return {
            "level":       2,
            "protocol":    "VIGIL_ZKP_V3",
            "proof_index": self._proof_counter,
            **metrics,
            "pcot": {
                "chain_step":    pcot.chain_step,
                "primary_belief": pcot.primary_belief,
                "p_nominal":     pcot.p_nominal,
                "p_tachycardia": pcot.p_tachycardia,
                "p_bradycardia": pcot.p_bradycardia,
                "p_low_hrv":     pcot.p_low_hrv,
                "p_artifact":    pcot.p_artifact,
                "p_synthetic":   pcot.p_synthetic,
                "belief_entropy": pcot.belief_entropy,
                "confidence":    pcot.confidence,
                "doubt_active":  pcot.doubt_active,
                "doubt_reason":  pcot.doubt_reason,
            },
            "liveness": {
                "rsa_ok":      metrics.get("rsa_ratio", 0) > 0.08,
                "te_ok":       metrics.get("te_causal", 0) > 0.02,
                "entropy_ok":  1.5 < metrics.get("rr_entropy", 2.0) < 3.5,
                "synthetic_p": pcot.p_synthetic,
                "score":       round(1.0 - pcot.p_synthetic, 3),
            },
            "t_rel":       round(t_rel, 2),
            "contact":     contact,
            "node_id":     self._node_id(),
        }


# ══════════════════════════════════════════════════════════════════════════════
#  ★ CNS-06 V3 · PHANTOM ENGINE — Lyapunov Chaos + Jitter Steganography
#
#  V2: AR(1) con φ=0.82 fijo. Adversario con 10 min de datos puede destilar
#      el patrón y sintetizar señal indistinguible SIN la firma.
#
#  V3:
#  1. φ varía según exponente de Lyapunov local (modulación caótica)
#     → No extrapolable. Adversario no puede ajustar modelo estable.
#
#  2. Jitter Steganography: 4 bits/s de marca en los LSB del jitter residual
#     → Una copia de nuestra señal llevará siempre nuestra marca
#     → Verificable offline por el operador: match_ratio > 0.75 → copia
#
#  Referencia: Transfer Entropy-Based Causal Inference (Electronics 2025,
#  14(20):4066) — si el adversario puede medir TE en nuestra señal,
#  puede destilarla. Jitter stego rompe esa extracción.
# ══════════════════════════════════════════════════════════════════════════════

class PhantomEngine:
    """
    Señal sintética adversarial V3 con firma esteganográfica.

    La firma es inextirpable: está codificada en los LSB del jitter residual
    del AR(1). Si el adversario intenta "limpiar" la firma ajustando otro
    AR(1), destruye las estadísticas de DFA-α1 que necesita para que la
    señal sea creíble.
    """
    # Parámetros AR(1) base
    PHI_BASE  = 0.82
    PHI_CHAOS = 0.08    # Amplitud de modulación de φ
    SIGMA     = 35.0
    T_LYAP    = 90.0    # Período de modulación caótica (segundos)

    def __init__(self, seed_bpm: float = 68.0, session_key: Optional[bytes] = None):
        self._phi      = self.PHI_BASE
        self._mu       = 60000.0 / seed_bpm
        self._last_rr  = self._mu
        self._counter  = 0
        self._t_start  = time.monotonic()
        # Clave de sesión para el keystream estego
        self._stego_key = session_key or os.urandom(32)
        self._stego_pos = 0
        # Historial de jitter para análisis Lyapunov
        self._rr_history: deque[float] = deque(maxlen=32)

    def _lyapunov_local(self) -> float:
        """
        Estimación del exponente de Lyapunov local sobre la ventana reciente.
        Indica si el sistema está en estado expansivo (> 0) o contractivo (< 0).
        Valor positivo → incrementar φ ligeramente (más caótico)
        Valor negativo → decrementar φ (más suave)
        """
        rr = list(self._rr_history)
        if len(rr) < 8:
            return 0.0
        # Aproximación: tasa de divergencia de trayectorias adyacentes
        divergences = []
        for i in range(len(rr)-2):
            d0 = abs(rr[i+1] - rr[i])
            d1 = abs(rr[i+2] - rr[i+1])
            if d0 > 1e-6:
                divergences.append(math.log(max(d1, 1e-6) / d0))
        if not divergences:
            return 0.0
        return sum(divergences) / len(divergences)

    def _update_phi_lyapunov(self):
        """Modula φ según Lyapunov local para evitar extrapolación adversarial."""
        lyap = self._lyapunov_local()
        t    = time.monotonic() - self._t_start
        # Componente determinista (período largo, impredecible sin la clave)
        chaos_phase = math.cos(2 * math.pi * t / self.T_LYAP +
                               int.from_bytes(self._stego_key[:4], 'big') / 2**32 * math.pi)
        self._phi = self.PHI_BASE + self.PHI_CHAOS * math.tanh(lyap) * chaos_phase
        self._phi = max(0.60, min(0.95, self._phi))

    def _stego_bit(self) -> int:
        """Extrae el siguiente bit del keystream de firma esteganográfica."""
        byte_idx = self._stego_pos // 8
        bit_idx  = self._stego_pos % 8
        # Keystream derivado de HMAC-SHA256 de la clave de sesión + posición
        block    = byte_idx // 32
        ks_block = hmac.new(
            self._stego_key,
            block.to_bytes(8, 'big'),
            hashlib.sha256
        ).digest()
        self._stego_pos += 1
        return (ks_block[byte_idx % 32] >> bit_idx) & 1

    def next_rr(self) -> Tuple[int, int]:
        """
        Genera próximo RR sintético.
        Retorna (rr_ms, stego_bit_injected) para verificación interna.
        """
        self._counter += 1

        # Actualizar φ cada 50 muestras (Lyapunov modulation)
        if self._counter % 50 == 0:
            self._update_phi_lyapunov()
            self._mu += random.gauss(0, 5)
            self._mu = max(500.0, min(1100.0, self._mu))

        # AR(1) base
        noise = random.gauss(0, self.SIGMA)
        rr = self._phi * (self._last_rr - self._mu) + self._mu + noise
        rr = max(350.0, min(1800.0, rr))

        # ★ Jitter Steganography: inyectar bit en LSB del residual
        stego_bit   = self._stego_bit()
        current_lsb = int(rr) % 2
        if current_lsb != stego_bit:
            rr += 1.0  # Ajuste de 1ms — imperceptible, verificable
        rr_int = int(rr)

        self._last_rr = rr
        self._rr_history.append(rr)
        return rr_int, stego_bit

    def verify_stego_mark(self, captured_rr: List[int],
                          ar1_predictions: List[float]) -> float:
        """
        Verifica si una secuencia de RR capturada lleva nuestra marca.
        Extrae LSBs del residual AR(1) y compara contra keystream esperado.
        match_ratio > 0.75 → es una copia de nuestra señal (PHANTOM CONFIRMED).
        """
        if len(captured_rr) < 16:
            return 0.0
        extracted = [(rr - int(pred)) % 2 for rr, pred in
                     zip(captured_rr, ar1_predictions)]
        expected  = [self._stego_bit() for _ in range(len(extracted))]
        matches   = sum(1 for a, b in zip(extracted, expected) if a == b)
        return matches / len(extracted)

    def generate_packet(self, client_id: str, level: int) -> Dict:
        rr, _ = self.next_rr()
        bpm   = round(60000.0 / rr, 1)
        rmssd = round(random.gauss(35, 8), 2)
        sdnn  = round(random.gauss(50, 12), 2)
        dfa   = round(random.gauss(1.02, 0.06), 4)
        # V3: RSA plausible pero no perfecta (no 0, no 1)
        rsa_ratio = round(random.gauss(0.18, 0.04), 4)
        rsa_ratio = max(0.09, min(0.55, rsa_ratio))
        # V3: TE plausible
        te_causal = round(random.gauss(0.07, 0.02), 4)
        te_causal = max(0.03, min(0.25, te_causal))
        return {
            "level":       level,
            "phantom":     True,   # Flag interno — NUNCA expuesto al intruso
            "bpm":         bpm,
            "rmssd":       rmssd,
            "sdnn":        sdnn,
            "dfa_a1":      dfa,
            "delta_p":     round(min(100, sdnn/150*100), 2),
            "rsa_ratio":   rsa_ratio,
            "te_causal":   te_causal,
            "rr_entropy":  round(random.gauss(2.3, 0.2), 3),
            "t_rel":       round(time.monotonic() % 3600, 2),
            "contact":     True,
            "node_id":     hashlib.sha256(
                client_id.encode() + os.urandom(4)
            ).hexdigest()[:16],
        }


# ══════════════════════════════════════════════════════════════════════════════
#  CNS-07 · SOVEREIGN BRIDGE — Estado Compartido (Thread-Safe)
# ══════════════════════════════════════════════════════════════════════════════

class PolicyLevel(IntEnum):
    BLINDADO   = 0
    OPERATIVO  = 1
    INGENIERIA = 2

@dataclass
class ClientRecord:
    id:          str
    name:        str
    ip:          str
    level:       int   = 0
    status:      str   = "PENDING"
    connected_at:float = field(default_factory=time.monotonic)
    pkts_sent:   int   = 0
    pkts_drop:   int   = 0
    challenge:   str   = ""
    challenge_ts:float = 0.0

class SharedState:
    """Estado global thread-safe del sistema CNS V3."""
    def __init__(self):
        self._lock         = asyncio.Lock()
        self.alive:  bool  = False
        self.contact:bool  = False
        self.t_start:float = time.monotonic()

        # Componentes V3
        self.sav       = AdaptiveSAVFilter()
        self.sensor_v  = SensorValidator()
        self.inference = EdgeInference()
        self.zkp       = ZKPSovereignty()
        self._master_key: bytes = os.urandom(32)
        self.phantom   = PhantomEngine(session_key=self._master_key[:32])
        self.pcot      = PCoTReasoner()

        # Clientes
        self.clients:              Dict[str, ClientRecord] = {}
        self.websockets_data:      set = set()
        self.websockets_control:   set = set()

        # Métricas
        self.pkt_rx:   int   = 0
        self.pkt_drop: int   = 0
        self.last_rr:  float = 0.0
        self.session_id: str = uuid.uuid4().hex[:12].upper()

        # V3: último resultado P-CoT cacheado
        self._last_pcot: Optional[PCoTResult] = None

    async def push_rr(self, rr_ms: int, recv_ts: float):
        async with self._lock:
            valid, reason = self.sav.validate(rr_ms)
            self.pkt_rx += 1
            if not valid:
                self.pkt_drop += 1
                return False, reason
            trust, flags = self.sensor_v.score(rr_ms, recv_ts)
            self.inference.push(float(rr_ms), recv_ts)
            self.alive   = True
            self.last_rr = float(rr_ms)

            # V3: Actualizar P-CoT en cada paquete válido
            metrics = self.inference.summary()
            self._last_pcot = self.pcot.reason(metrics, trust)

            return True, trust

    def sign_packet(self, client_id: str, payload: dict) -> dict:
        token = hmac.new(
            self._master_key,
            f"vigil:v3:{client_id}".encode(),
            hashlib.sha256
        ).digest()
        sig = hmac.new(
            token,
            json.dumps(payload, sort_keys=True).encode(),
            hashlib.sha256
        ).hexdigest()
        return {**payload, "_sig": sig[:16], "_v": 3}

    def elapsed(self) -> float:
        return time.monotonic() - self.t_start


S = SharedState()


# ══════════════════════════════════════════════════════════════════════════════
#  CNS-08 V3 · FLIGHT RECORDER — Audit chain + P-CoT belief log
# ══════════════════════════════════════════════════════════════════════════════

class FlightRecorder:
    """V3: Hereda HMAC-linked chain + añade P-CoT belief log y TE log."""
    def __init__(self, base_dir: str = "~/.omni_vigil"):
        self._dir     = Path(base_dir).expanduser()
        self._dir.mkdir(parents=True, exist_ok=True)
        self._session = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        self._csv_path  = self._dir / f"session_{self._session}.csv"
        self._log_path  = self._dir / f"audit_{self._session}.jsonl"
        self._queue: asyncio.Queue = asyncio.Queue(maxsize=2048)
        self._last_hash = "GENESIS"
        self._key = os.urandom(32)

    def _chain_entry(self, data: dict) -> dict:
        link = hmac.new(
            self._key,
            (self._last_hash + json.dumps(data, sort_keys=True)).encode(),
            hashlib.sha256
        ).hexdigest()[:16]
        data["_chain"] = link
        self._last_hash = link
        return data

    async def write_loop(self):
        with open(self._csv_path, 'w', newline='') as csv_f, \
             open(self._log_path, 'a') as log_f:
            writer = csv.writer(csv_f)
            writer.writerow([
                "ts_utc","bpm","rmssd","sdnn","dfa_a1","delta_p",
                "rsa_ratio","te_causal","rr_entropy",
                "trust","pcot_belief","pcot_confidence","session"
            ])
            while True:
                entry = await self._queue.get()
                if entry is None: break
                try:
                    if entry.get("_type") == "METRIC":
                        writer.writerow([
                            entry.get("ts"), entry.get("bpm"),
                            entry.get("rmssd"), entry.get("sdnn"),
                            entry.get("dfa_a1"), entry.get("delta_p"),
                            entry.get("rsa_ratio"), entry.get("te_causal"),
                            entry.get("rr_entropy"),
                            entry.get("trust"),
                            entry.get("pcot_belief"),
                            entry.get("pcot_conf"),
                            S.session_id
                        ])
                        csv_f.flush()
                    chained = self._chain_entry(entry)
                    log_f.write(json.dumps(chained) + "\n")
                    log_f.flush()
                except Exception as e:
                    log.error(f"FlightRecorder error: {e}")

    async def log_metric(self, ts: float, metrics: Dict,
                         trust: float, pcot: Optional[PCoTResult]):
        entry = {
            "_type":     "METRIC",
            "ts":        round(ts, 3),
            "bpm":       round(metrics.get("bpm", 0), 1),
            "rmssd":     round(metrics.get("rmssd", 0), 2),
            "sdnn":      round(metrics.get("sdnn", 0), 2),
            "dfa_a1":    metrics.get("dfa_a1", 1.0),
            "delta_p":   round(metrics.get("delta_p", 0), 2),
            "rsa_ratio": round(metrics.get("rsa_ratio", 0), 4),
            "te_causal": round(metrics.get("te_causal", 0), 4),
            "rr_entropy":round(metrics.get("rr_entropy", 2), 3),
            "trust":     round(trust, 3),
            "pcot_belief": pcot.primary_belief if pcot else "UNKNOWN",
            "pcot_conf":   round(pcot.confidence, 3) if pcot else 0.0,
        }
        try:
            self._queue.put_nowait(entry)
        except asyncio.QueueFull:
            pass

    async def log_event(self, event_type: str, detail: dict):
        entry = {"_type": "EVENT", "ts": time.time(), "event": event_type, **detail}
        try:
            self._queue.put_nowait(entry)
        except asyncio.QueueFull:
            pass

FR = FlightRecorder()


# ══════════════════════════════════════════════════════════════════════════════
#  BLE LAYER — Polar H10
# ══════════════════════════════════════════════════════════════════════════════

async def _hr_callback(sender, data: bytearray):
    flags = data[0]
    bpm = struct.unpack_from('<H', data, 1)[0] if (flags & 0x01) else data[1]
    contact = bool(flags & 0x06)
    S.contact = contact
    if bpm > 0 and 20 < bpm < 250:
        rr_ms = int(60000 / bpm)
        ts    = time.monotonic()
        ok, trust = await S.push_rr(rr_ms, ts)
        if ok:
            metrics = S.inference.summary()
            await FR.log_metric(ts, metrics,
                                S.sensor_v.mean_trust(), S._last_pcot)

async def ble_run(mode: str = "web"):
    if not BLEAK_OK:
        log.error("bleak not installed — BLE unavailable")
        return
    log.info("🔎 Scanning for Polar H10...")
    devices = await BleakScanner.discover(timeout=8.0)
    polar = next((d for d in devices if d.name and "Polar H10" in d.name), None)
    if not polar:
        log.warning("⚠️  Polar H10 not found. Simulation mode.")
        await _simulate_ble()
        return
    log.info(f"✅ Found: {polar.name} ({polar.address})")
    async with BleakClient(polar.address) as client:
        await client.start_notify(HR_UUID, _hr_callback)
        try:
            await client.write_gatt_char(PMD_CTRL, ECG_START)
        except Exception:
            pass
        log.info("💓 Streaming HR from Polar H10...")
        await asyncio.sleep(float('inf'))

async def _simulate_ble():
    """Simulador Polar H10 con AR(1) para testing sin hardware."""
    log.info("🛸 Simulation mode — synthetic AR(1) signal V3")
    phi, mu, sigma = 0.85, 780.0, 40.0
    last = mu
    while True:
        noise = random.gauss(0, sigma)
        last  = phi * (last - mu) + mu + noise
        last  = max(350, min(1800, last))
        rr_ms = int(last)
        ts    = time.monotonic()
        ok, trust = await S.push_rr(rr_ms, ts)
        if ok:
            metrics = S.inference.summary()
            await FR.log_metric(ts, metrics, trust if isinstance(trust, float) else 0.9,
                                S._last_pcot)
        await asyncio.sleep(random.uniform(0.7, 1.1))


# ══════════════════════════════════════════════════════════════════════════════
#  WEBSOCKET SERVERS V3
# ══════════════════════════════════════════════════════════════════════════════

async def _vigil_challenge(ws, client_id: str) -> bool:
    challenge = hashlib.sha256(os.urandom(32)).hexdigest()[:32]
    cr = S.clients.get(client_id)
    if cr:
        cr.challenge    = challenge
        cr.challenge_ts = time.monotonic()
    await ws.send(json.dumps({
        "type":      "CHALLENGE",
        "challenge": challenge,
        "session":   S.session_id,
        "version":   3,   # V3
    }))
    return True

async def vigil_data_server(host: str = "0.0.0.0", port: int = 8765):
    if not WS_OK:
        log.error("websockets not installed")
        return

    async def handler(ws):
        client_id = uuid.uuid4().hex[:8].upper()
        ip = ws.remote_address[0] if ws.remote_address else "0.0.0.0"
        record = ClientRecord(id=client_id, name=f"CLIENT_{client_id}", ip=ip)
        S.clients[client_id] = record
        S.websockets_data.add(ws)
        log.info(f"🔌 [{client_id}] connected from {ip}")
        await _vigil_challenge(ws, client_id)

        try:
            while True:
                await asyncio.sleep(1.0)
                async with S._lock:
                    cr = S.clients.get(client_id)
                    if not cr: break
                    metrics = S.inference.summary()
                    trust   = S.sensor_v.mean_trust()
                    t_rel   = S.elapsed()
                    pcot    = S._last_pcot

                    if cr.status == "REJECTED":
                        payload = S.phantom.generate_packet(client_id, cr.level)
                    elif cr.status != "APPROVED":
                        payload = {"type": "AWAITING_APPROVAL", "client_id": client_id}
                    elif cr.level == PolicyLevel.BLINDADO:
                        payload = S.zkp.proof_of_life(S.alive)
                    elif cr.level == PolicyLevel.OPERATIVO:
                        payload = S.zkp.proof_of_calm(S.alive, metrics["rmssd"])
                    else:
                        if ip not in ("127.0.0.1", "::1", "localhost"):
                            payload = S.phantom.generate_packet(client_id, 1)
                            cr.status = "PHANTOM"
                            log.warning(f"🔴 [{client_id}] L2 from non-local → phantom")
                        else:
                            payload = S.zkp.proof_of_engineering(
                                metrics, pcot or PCoTResult(
                                    chain_step="SENSE", primary_belief="NOMINAL",
                                    p_primary=0.9, p_nominal=0.9,
                                    p_tachycardia=0.01, p_bradycardia=0.01,
                                    p_low_hrv=0.01, p_artifact=0.01,
                                    p_synthetic=0.01,
                                    belief_entropy=0.3, confidence=0.9,
                                    doubt_active=False, doubt_reason="",
                                    action="CONTINUE", findings=[]
                                ),
                                t_rel, S.contact
                            )
                            # Inyectar findings P-CoT
                            if pcot:
                                payload["react"] = pcot.findings[:3]

                    payload["_session"]   = S.session_id
                    payload["_sensor_ok"] = not S.sensor_v.circuit_open
                    payload = S.sign_packet(client_id, payload)
                    try:
                        await ws.send(json.dumps(payload))
                        cr.pkts_sent += 1
                    except Exception:
                        break
        except Exception as e:
            log.error(f"[{client_id}] error: {e}")
        finally:
            S.websockets_data.discard(ws)
            if client_id in S.clients:
                del S.clients[client_id]
            log.info(f"🔌 [{client_id}] disconnected")

    log.info(f"🛰️  VIGIL DATA SERVER V3  ws://{host}:{port}")
    async with websockets.serve(handler, host, port):
        await asyncio.Future()

async def vigil_control_server(host: str = "0.0.0.0", port: int = 8766):
    if not WS_OK: return

    async def handler(ws):
        ip = ws.remote_address[0] if ws.remote_address else "unknown"
        if ip not in ("127.0.0.1", "::1"):
            log.warning(f"❌ Control from non-local {ip} — rejected")
            await ws.close()
            return
        S.websockets_control.add(ws)

        async def push_status():
            while True:
                try:
                    metrics = S.inference.summary()
                    trust   = S.sensor_v.mean_trust()
                    pcot    = S._last_pcot
                    status = {
                        "type":     "STATUS",
                        "session":  S.session_id,
                        "alive":    S.alive,
                        "contact":  S.contact,
                        "metrics":  metrics,
                        "sensor":   {
                            "trust":   round(trust, 3),
                            "circuit": S.sensor_v.circuit_open,
                            "faults":  S.sensor_v.fault_log[-3:],
                        },
                        "pcot": {
                            "chain_step":    pcot.chain_step if pcot else "SENSE",
                            "primary_belief":pcot.primary_belief if pcot else "UNKNOWN",
                            "p_nominal":     pcot.p_nominal if pcot else 0.5,
                            "p_synthetic":   pcot.p_synthetic if pcot else 0.0,
                            "belief_entropy":pcot.belief_entropy if pcot else 1.0,
                            "confidence":    pcot.confidence if pcot else 0.5,
                            "doubt_active":  pcot.doubt_active if pcot else False,
                        } if pcot else {},
                        "clients":  [{
                            "id": c.id, "name": c.name, "ip": c.ip,
                            "level": c.level, "status": c.status, "pkts": c.pkts_sent,
                        } for c in S.clients.values()],
                        "react":    pcot.findings[:5] if pcot else [],
                        "pkt_rx":   S.pkt_rx,
                        "pkt_drop": S.pkt_drop,
                        "elapsed":  round(S.elapsed(), 1),
                        "drop_pct": round(100 * S.pkt_drop / max(1, S.pkt_rx), 2),
                    }
                    await ws.send(json.dumps(status))
                    await asyncio.sleep(0.8)
                except Exception:
                    break

        asyncio.create_task(push_status())
        try:
            async for raw in ws:
                try:
                    cmd = json.loads(raw)
                    await _handle_control_command(cmd)
                except json.JSONDecodeError:
                    pass
        except Exception:
            pass
        finally:
            S.websockets_control.discard(ws)

    log.info(f"🎛️  VIGIL CONTROL SERVER V3  ws://{host}:{port}")
    async with websockets.serve(handler, host, port):
        await asyncio.Future()

async def _handle_control_command(cmd: dict):
    action    = cmd.get("action")
    client_id = cmd.get("client_id")
    if action == "APPROVE" and client_id in S.clients:
        S.clients[client_id].status = "APPROVED"
        log.info(f"✅ APPROVED [{client_id}]")
        await FR.log_event("APPROVE", {"client": client_id})
    elif action == "REJECT" and client_id in S.clients:
        S.clients[client_id].status = "REJECTED"
        log.warning(f"🔴 REJECTED [{client_id}] → phantom mode")
        await FR.log_event("REJECT", {"client": client_id})
    elif action == "SET_LEVEL" and client_id in S.clients:
        level = int(cmd.get("level", 0))
        if level in (0, 1, 2):
            S.clients[client_id].level = level
            await FR.log_event("SET_LEVEL", {"client": client_id, "level": level})
    elif action == "KILL" and client_id in S.clients:
        del S.clients[client_id]
        await FR.log_event("KILL", {"client": client_id})
    elif action == "RESET_SENSOR":
        S.sensor_v._low_trust_run = 0
        S.sensor_v.circuit_open   = False
        log.info("🔄 Sensor circuit breaker reset")


# ══════════════════════════════════════════════════════════════════════════════
#  ENTRY POINT
# ══════════════════════════════════════════════════════════════════════════════

def parse_args():
    p = argparse.ArgumentParser(description="OMNI-VIGIL SOBERANO v3.0")
    p.add_argument("--web",          action="store_true")
    p.add_argument("--simulate",     action="store_true")
    p.add_argument("--data-port",    type=int, default=8765)
    p.add_argument("--control-port", type=int, default=8766)
    return p.parse_args()

async def _main_web(simulate: bool, data_port: int, control_port: int):
    log.info("""
    ╔══════════════════════════════════════════════════════════╗
    ║   OMNI-VIGIL SOBERANO v3.0                             ║
    ║   Central Nervous System — La V3 duda antes de actuar  ║
    ║   Session: %-12s                              ║
    ╚══════════════════════════════════════════════════════════╝
    """ % S.session_id)
    ble_task = _simulate_ble() if simulate else ble_run("web")
    await asyncio.gather(
        ble_task,
        vigil_data_server(port=data_port),
        vigil_control_server(port=control_port),
        FR.write_loop(),
    )

def main():
    args = parse_args()
    if args.web or args.simulate:
        try:
            asyncio.run(_main_web(
                args.simulate or not BLEAK_OK,
                args.data_port,
                args.control_port,
            ))
        except KeyboardInterrupt:
            log.info("⏹️  CNS V3 shutdown — session archived")
    else:
        print("OMNI-VIGIL SOBERANO v3.0 — use --web or --web --simulate")

if __name__ == "__main__":
    main()
